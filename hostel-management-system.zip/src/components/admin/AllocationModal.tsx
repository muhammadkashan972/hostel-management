import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { useData } from '../../context/DataContext';
import type { Student, Room } from '../../types';

interface AllocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode?: 'allocate' | 'change';
  preSelectedStudent?: Student | null;
}

export const AllocationModal: React.FC<AllocationModalProps> = ({
  isOpen,
  onClose,
  mode = 'allocate',
  preSelectedStudent,
}) => {
  const { students, rooms, allocateRoom, changeRoom } = useData();

  const [studentId, setStudentId] = useState('');
  const [roomId, setRoomId] = useState('');
  const [bedNumber, setBedNumber] = useState('Bed 1');
  const [remarks, setRemarks] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Available rooms for assignment
  const availableRooms = rooms.filter(r => r.availableBeds > 0 && r.status === 'Available');

  // Filter students based on mode
  const eligibleStudents = mode === 'allocate'
    ? students.filter(s => !s.roomNumber || s.roomNumber === '')
    : students.filter(s => s.roomNumber && s.roomNumber !== '');

  useEffect(() => {
    if (preSelectedStudent) {
      setStudentId(preSelectedStudent.studentId);
    } else if (eligibleStudents.length > 0) {
      setStudentId(eligibleStudents[0].studentId);
    } else {
      setStudentId('');
    }

    if (availableRooms.length > 0) {
      setRoomId(availableRooms[0].id);
    } else {
      setRoomId('');
    }

    setBedNumber('Bed 1');
    setRemarks('');
    setError('');
  }, [isOpen, mode, preSelectedStudent]);

  const selectedRoom = rooms.find(r => r.id === roomId);
  const selectedStudent = students.find(s => s.studentId === studentId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId) {
      setError('Please select a student');
      return;
    }
    if (!roomId) {
      setError('Please select an available room');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      if (mode === 'allocate') {
        const res = await allocateRoom(studentId, roomId, bedNumber, remarks);
        if (!res.success) {
          setError(res.error || 'Allocation failed');
          setSubmitting(false);
          return;
        }
      } else {
        const res = await changeRoom(studentId, roomId, bedNumber, remarks);
        if (!res.success) {
          setError(res.error || 'Room relocation failed');
          setSubmitting(false);
          return;
        }
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Action failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={mode === 'allocate' ? 'Allocate Student to Room' : 'Transfer / Change Student Room'}
      subtitle="Select student and assign an available bed with instant occupancy synchronization"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 text-xs bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
            {error}
          </div>
        )}

        {/* Student Selection */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Select Student * {mode === 'allocate' ? '(Unassigned)' : '(Currently Assigned)'}
          </label>
          <select
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
            disabled={Boolean(preSelectedStudent)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
          >
            {eligibleStudents.length === 0 ? (
              <option value="">No eligible students found</option>
            ) : (
              eligibleStudents.map(s => (
                <option key={s.id} value={s.studentId}>
                  {s.fullName} ({s.studentId}) - {s.course} {s.roomNumber ? `[Cur: ${s.roomNumber}]` : ''}
                </option>
              ))
            )}
          </select>
        </div>

        {/* Target Room Selection */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Target Room *</label>
          <select
            value={roomId}
            onChange={(e) => setRoomId(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
          >
            {availableRooms.length === 0 ? (
              <option value="">No rooms with available beds</option>
            ) : (
              availableRooms.map(r => (
                <option key={r.id} value={r.id}>
                  {r.roomNumber} ({r.type} - {r.block}) • {r.availableBeds} beds left (Rs. {r.feePerSemester.toLocaleString()}/sem)
                </option>
              ))
            )}
          </select>
        </div>

        {/* Bed Number Selection */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Bed Designation *</label>
            <select
              value={bedNumber}
              onChange={(e) => setBedNumber(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
            >
              <option value="Bed 1">Bed 1 (Window Side)</option>
              <option value="Bed 2">Bed 2 (Door Side)</option>
              <option value="Bed 3">Bed 3 (Balcony Side)</option>
              <option value="Bed 4">Bed 4 (Corner)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Effective Date</label>
            <input
              type="text"
              readOnly
              value={new Date().toISOString().split('T')[0]}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-600"
            />
          </div>
        </div>

        {/* Room Spec Summary Box */}
        {selectedRoom && (
          <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-blue-900 space-y-1">
            <div className="flex justify-between font-semibold">
              <span>Room {selectedRoom.roomNumber} ({selectedRoom.type})</span>
              <span>Rs. {selectedRoom.feePerSemester.toLocaleString()} / semester</span>
            </div>
            <p className="text-[11px] text-blue-700">
              Location: {selectedRoom.floor}, {selectedRoom.block} • Capacity: {selectedRoom.capacity} beds ({selectedRoom.currentOccupants} filled)
            </p>
          </div>
        )}

        {/* Remarks */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Allocation Notes / Remarks</label>
          <input
            type="text"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="e.g. Allocated per semester application"
          />
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting || availableRooms.length === 0 || !studentId}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {submitting ? 'Processing...' : mode === 'allocate' ? 'Assign Bed' : 'Transfer Student'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
