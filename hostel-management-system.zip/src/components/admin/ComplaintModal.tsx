import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { Badge } from '../common/Badge';
import type { Complaint, ComplaintStatus } from '../../types';

interface ComplaintModalProps {
  isOpen: boolean;
  onClose: () => void;
  complaint: Complaint | null;
  onUpdate: (id: string, status: ComplaintStatus, adminRemarks?: string) => Promise<void>;
}

export const ComplaintModal: React.FC<ComplaintModalProps> = ({
  isOpen,
  onClose,
  complaint,
  onUpdate,
}) => {
  const [status, setStatus] = useState<ComplaintStatus>('In Progress');
  const [adminRemarks, setAdminRemarks] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (complaint) {
      setStatus(complaint.status);
      setAdminRemarks(complaint.adminRemarks || '');
    }
    setError('');
  }, [complaint, isOpen]);

  if (!complaint) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await onUpdate(complaint.id, status, adminRemarks);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update complaint');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Maintenance Ticket: ${complaint.title}`}
      subtitle={`Lodged by ${complaint.studentName} (Room ${complaint.roomNumber})`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 text-xs bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
            {error}
          </div>
        )}

        {/* Complaint Info Box */}
        <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-900">{complaint.category} Issue</span>
            <Badge 
              variant={complaint.priority === 'Urgent' ? 'danger' : complaint.priority === 'High' ? 'warning' : 'neutral'}
              size="sm"
            >
              {complaint.priority} Priority
            </Badge>
          </div>
          <p className="text-slate-600 leading-relaxed bg-white p-2.5 rounded-lg border border-slate-200/60">
            "{complaint.description}"
          </p>
          <div className="flex justify-between text-[11px] text-slate-400 pt-1">
            <span>Reported on: {new Date(complaint.createdAt).toLocaleDateString()}</span>
            <span>Current Status: <strong className="text-slate-700">{complaint.status}</strong></span>
          </div>
        </div>

        {/* Status Update Selector */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Update Ticket Status</label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as ComplaintStatus)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white font-semibold"
          >
            <option value="Pending">Pending Assignment</option>
            <option value="In Progress">In Progress / Technician Assigned</option>
            <option value="Resolved">Resolved & Inspected</option>
            <option value="Closed">Closed</option>
          </select>
        </div>

        {/* Admin Remarks */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Admin Action & Resolution Notes</label>
          <textarea
            rows={3}
            value={adminRemarks}
            onChange={(e) => setAdminRemarks(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="e.g. Assigned plumbing vendor. Replaced washer in showerhead; tested OK."
          />
          <p className="text-[11px] text-slate-400 mt-1">
            These notes will be immediately visible to the student in their portal.
          </p>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {submitting ? 'Updating...' : 'Save Resolution'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
