import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { useData } from '../../context/DataContext';
import type { Fee, FeeStatus } from '../../types';

interface FeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Fee, 'id' | 'invoiceNumber'>) => Promise<string>;
}

export const FeeModal: React.FC<FeeModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const { students } = useData();
  const [studentId, setStudentId] = useState('');
  const [amount, setAmount] = useState<number>(1200);
  const [semester, setSemester] = useState('Spring Semester 2025');
  const [dueDate, setDueDate] = useState('2025-02-28');
  const [status, setStatus] = useState<FeeStatus>('Pending');
  const [paymentMethod, setPaymentMethod] = useState('Online Banking / UPI');
  const [transactionId, setTransactionId] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (students.length > 0) {
      setStudentId(students[0].studentId);
    }
    setAmount(1200);
    setStatus('Pending');
    setTransactionId('');
    setError('');
  }, [isOpen, students]);

  const selectedStudent = students.find(s => s.studentId === studentId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId || !selectedStudent) {
      setError('Please select a student');
      return;
    }
    if (amount <= 0) {
      setError('Fee amount must be greater than zero');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      await onSubmit({
        studentId: selectedStudent.studentId,
        studentName: selectedStudent.fullName,
        roomNumber: selectedStudent.roomNumber || 'Unassigned',
        amount,
        semester,
        dueDate,
        status,
        paymentDate: status === 'Paid' ? new Date().toISOString().split('T')[0] : undefined,
        paymentMethod: status === 'Paid' ? paymentMethod : undefined,
        transactionId: status === 'Paid' ? (transactionId || `TXN-${Math.floor(10000000 + Math.random() * 90000000)}`) : undefined,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create fee record');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create Hostel Fee Record / Invoice"
      subtitle="Issue term charges and record student payment transactions"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 text-xs bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
            {error}
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Select Student *</label>
          <select
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
          >
            {students.map(s => (
              <option key={s.id} value={s.studentId}>
                {s.fullName} ({s.studentId}) • Room: {s.roomNumber || 'None'}
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Fee Amount (Rs.) *</label>
            <input
              type="number"
              min={50}
              step={10}
              value={amount}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Academic Term / Semester</label>
            <select
              value={semester}
              onChange={(e) => setSemester(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
            >
              <option value="Spring Semester 2025">Spring Semester 2025</option>
              <option value="Fall Semester 2024">Fall Semester 2024</option>
              <option value="Summer Term 2025">Summer Term 2025</option>
              <option value="Annual Fee 2024-2025">Annual Fee 2024-2025</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Payment Due Date</label>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Payment Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as FeeStatus)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white font-semibold"
            >
              <option value="Pending">Pending Payment</option>
              <option value="Paid">Mark as Paid</option>
              <option value="Overdue">Mark as Overdue</option>
            </select>
          </div>
        </div>

        {status === 'Paid' && (
          <div className="p-3 bg-emerald-50/70 border border-emerald-200/80 rounded-xl space-y-3 animate-in fade-in duration-150">
            <h5 className="text-xs font-bold text-emerald-900">Payment Receipt Info</h5>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-emerald-800 mb-1">Method</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-emerald-300 bg-white"
                >
                  <option value="Online Banking / UPI">Online Banking / UPI</option>
                  <option value="Credit Card">Credit Card</option>
                  <option value="Debit Card">Debit Card</option>
                  <option value="Bank Wire Transfer">Bank Wire Transfer</option>
                  <option value="Cash at Accounts Desk">Cash</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-emerald-800 mb-1">Transaction Ref #</label>
                <input
                  type="text"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  placeholder="Auto-generated if blank"
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-emerald-300 bg-white"
                />
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {submitting ? 'Generating...' : 'Issue Fee Invoice'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
