import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { useData } from '../../context/DataContext';
import { useToast } from '../common/Toast';
import type { Student } from '../../types';
import { LogOut, DoorOpen, Calendar, FileText, AlertTriangle } from 'lucide-react';

interface MarkLeftHostelModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null;
  onSuccess?: () => void;
}

const COMMON_REASONS = [
  'Course Completed / Graduated',
  'Moved to Off-Campus Housing',
  'Transferred to Another Institution',
  'Family / Personal Relocation',
  'Health / Medical Reasons',
  'Voluntary Departure',
  'Disciplinary Suspension',
  'Other'
];

export const MarkLeftHostelModal: React.FC<MarkLeftHostelModalProps> = ({
  isOpen,
  onClose,
  student,
  onSuccess
}) => {
  const { markStudentLeftHostel } = useData();
  const { success, error: toastError } = useToast();

  const [leavingDate, setLeavingDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [reasonCategory, setReasonCategory] = useState(COMMON_REASONS[0]);
  const [customRemarks, setCustomRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setLeavingDate(new Date().toISOString().split('T')[0]);
      setReasonCategory(COMMON_REASONS[0]);
      setCustomRemarks('');
      setIsSubmitting(false);
    }
  }, [isOpen, student]);

  if (!student) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leavingDate) {
      toastError('Please specify the date the student left the hostel');
      return;
    }

    setIsSubmitting(true);
    try {
      const fullReason = reasonCategory === 'Other' && customRemarks.trim()
        ? customRemarks.trim()
        : customRemarks.trim()
        ? `${reasonCategory} - ${customRemarks.trim()}`
        : reasonCategory;

      const res = await markStudentLeftHostel(student.id, leavingDate, fullReason);
      if (res.success) {
        success(
          `Student ${student.fullName} marked as Left Hostel. Room bed released into available inventory.`
        );
        onSuccess?.();
        onClose();
      } else {
        toastError(res.error || 'Failed to update student status');
      }
    } catch (err: any) {
      toastError(err.message || 'Error processing hostel departure');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Mark Student as Left Hostel"
      subtitle="Archive active resident into Former Students registry"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-slate-700">
        {/* Student Summary Card */}
        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-900 font-bold flex items-center justify-center shrink-0">
              {student.fullName.charAt(0)}
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">{student.fullName}</h4>
              <p className="text-xs text-slate-500 font-mono">
                {student.studentId} • {student.course} ({student.year})
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Hostel Joined</span>
            <span className="text-xs font-semibold text-slate-700">{student.admissionDate || 'N/A'}</span>
          </div>
        </div>

        {/* Room Deallocation Alert */}
        <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 text-amber-900 text-xs space-y-1.5">
          <div className="flex items-center gap-2 font-bold text-amber-950">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Automatic Room Deallocation</span>
          </div>
          {student.roomNumber ? (
            <p className="leading-relaxed">
              Assigned bed <strong className="font-semibold">{student.bedNumber || 'Bed 1'}</strong> in{' '}
              <strong className="font-semibold">Room {student.roomNumber}</strong> will be immediately freed and
              returned to available room inventory. Room occupancy count will be updated automatically.
            </p>
          ) : (
            <p className="leading-relaxed">
              This student does not have an active room allocation. Their status will be marked as{' '}
              <strong className="font-semibold">Left Hostel</strong> and moved to the Former Students archive.
            </p>
          )}
          <p className="text-[11px] text-amber-800">
            All historical records including fee invoices, payment receipts, complaints, and joining dates will remain
            fully preserved.
          </p>
        </div>

        {/* Departure Date */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-blue-800" />
            Hostel Leaving Date *
          </label>
          <input
            type="date"
            required
            value={leavingDate}
            onChange={(e) => setLeavingDate(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
          />
        </div>

        {/* Reason for Departure */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
            <LogOut className="w-3.5 h-3.5 text-blue-800" />
            Departure Reason *
          </label>
          <select
            value={reasonCategory}
            onChange={(e) => setReasonCategory(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
          >
            {COMMON_REASONS.map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
        </div>

        {/* Additional Remarks / Notes */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-slate-500" />
            Departure Notes & Clearance Remarks (Optional)
          </label>
          <textarea
            rows={2}
            value={customRemarks}
            onChange={(e) => setCustomRemarks(e.target.value)}
            placeholder="e.g., Gate pass verified, keys handed over, mess dues cleared..."
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-amber-700 hover:bg-amber-800 rounded-xl shadow-xs transition-all active:scale-98 disabled:opacity-50"
          >
            <DoorOpen className="w-3.5 h-3.5" />
            {isSubmitting ? 'Processing...' : 'Confirm Mark as Left Hostel'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
