import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import type { Notice, NoticeCategory, NoticePriority } from '../../types';

interface NoticeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Notice, 'id' | 'createdAt'>) => Promise<string | void>;
  initialData?: Notice | null;
}

export const NoticeModal: React.FC<NoticeModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
}) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<NoticeCategory>('General');
  const [priority, setPriority] = useState<NoticePriority>('Normal');
  const [targetAudience, setTargetAudience] = useState<Notice['targetAudience']>('All Students');
  const [publishedBy, setPublishedBy] = useState('Chief Warden Office');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (initialData) {
      setTitle(initialData.title);
      setContent(initialData.content);
      setCategory(initialData.category);
      setPriority(initialData.priority);
      setTargetAudience(initialData.targetAudience);
      setPublishedBy(initialData.publishedBy);
    } else {
      setTitle('');
      setContent('');
      setCategory('General');
      setPriority('Normal');
      setTargetAudience('All Students');
      setPublishedBy('Chief Warden Office');
    }
    setError('');
  }, [initialData, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Notice title is required');
      return;
    }
    if (!content.trim()) {
      setError('Notice content is required');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      await onSubmit({
        title,
        content,
        category,
        priority,
        targetAudience,
        publishedBy,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save notice');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={initialData ? 'Edit Hostel Notice' : 'Broadcast New Hostel Notice'}
      subtitle="Publish announcements to resident students and staff"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 text-xs bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
            {error}
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Headline / Subject *</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="e.g. Mandatory Fire Drill and Evacuation Walkthrough"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as NoticeCategory)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
            >
              <option value="General">General Notice</option>
              <option value="Maintenance">Maintenance & Works</option>
              <option value="Mess & Dining">Mess & Dining</option>
              <option value="Rules & Discipline">Rules & Discipline</option>
              <option value="Holiday / Leave">Holiday & Leave</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Priority Level</label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as NoticePriority)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white font-semibold"
            >
              <option value="Normal">Normal</option>
              <option value="Important">Important</option>
              <option value="Urgent">Urgent Alert</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Target Audience</label>
            <select
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value as any)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
            >
              <option value="All Students">All Students</option>
              <option value="Freshers">1st Year Freshers</option>
              <option value="Seniors">Graduating Seniors</option>
              <option value="Staff">Hostel Staff Only</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Notice Detailed Content *</label>
          <textarea
            rows={5}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="Type comprehensive notice details here..."
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Issuing Authority / Office</label>
          <input
            type="text"
            value={publishedBy}
            onChange={(e) => setPublishedBy(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="e.g. Chief Warden Office"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {submitting ? 'Publishing...' : initialData ? 'Update Notice' : 'Broadcast Notice'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
