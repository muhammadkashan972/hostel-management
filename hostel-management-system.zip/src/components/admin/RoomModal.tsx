import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import type { Room, RoomType, RoomStatus } from '../../types';

interface RoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Room, 'id'>) => Promise<void>;
  initialData?: Room | null;
}

const COMMON_AMENITIES = [
  'Attached Washroom',
  'Air Conditioning',
  'High-speed Wi-Fi',
  'Study Desks & Chairs',
  'Balcony / Garden View',
  'Individual Lockers',
  'Ceiling Fan',
  'Hot Water Geyser',
];

export const RoomModal: React.FC<RoomModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
}) => {
  const [formData, setFormData] = useState({
    roomNumber: '',
    floor: '1st Floor',
    block: 'Block A (Sunrise)',
    type: 'Double' as RoomType,
    capacity: 2,
    feePerSemester: 1200,
    amenities: ['Attached Washroom', 'High-speed Wi-Fi'],
    status: 'Available' as RoomStatus,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData({
        roomNumber: initialData.roomNumber || '',
        floor: initialData.floor || '1st Floor',
        block: initialData.block || 'Block A (Sunrise)',
        type: initialData.type || 'Double',
        capacity: initialData.capacity || 2,
        feePerSemester: initialData.feePerSemester || 1200,
        amenities: initialData.amenities || [],
        status: initialData.status || 'Available',
      });
    } else {
      setFormData({
        roomNumber: '',
        floor: '1st Floor',
        block: 'Block A (Sunrise)',
        type: 'Double',
        capacity: 2,
        feePerSemester: 1200,
        amenities: ['Attached Washroom', 'High-speed Wi-Fi'],
        status: 'Available',
      });
    }
    setErrors({});
  }, [initialData, isOpen]);

  // Sync capacity when room type changes
  const handleTypeChange = (type: RoomType) => {
    let cap = 2;
    let fee = 1200;
    if (type === 'Single') {
      cap = 1;
      fee = 1800;
    } else if (type === 'Double') {
      cap = 2;
      fee = 1200;
    } else if (type === 'Triple') {
      cap = 3;
      fee = 950;
    } else if (type === 'Four-Bed') {
      cap = 4;
      fee = 750;
    }
    setFormData(prev => ({ ...prev, type, capacity: cap, feePerSemester: fee }));
  };

  const toggleAmenity = (item: string) => {
    setFormData(prev => {
      const exists = prev.amenities.includes(item);
      return {
        ...prev,
        amenities: exists
          ? prev.amenities.filter(a => a !== item)
          : [...prev.amenities, item],
      };
    });
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.roomNumber.trim()) errs.roomNumber = 'Room number is required (e.g. A-105)';
    if (formData.capacity <= 0) errs.capacity = 'Capacity must be at least 1 bed';
    if (formData.feePerSemester <= 0) errs.feePerSemester = 'Fee must be greater than 0';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    try {
      await onSubmit({
        ...formData,
        currentOccupants: initialData?.currentOccupants || 0,
        availableBeds: initialData ? initialData.availableBeds : formData.capacity,
      });
      onClose();
    } catch (err: any) {
      setErrors({ form: err.message || 'Failed to save room details' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={initialData ? `Edit Room ${initialData.roomNumber}` : 'Create New Hostel Room'}
      subtitle="Define bed capacity, pricing, and room specifications"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {errors.form && (
          <div className="p-3 text-xs bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
            {errors.form}
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Room Number *</label>
            <input
              type="text"
              value={formData.roomNumber}
              onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value.toUpperCase() })}
              className={`w-full px-3 py-2 text-xs rounded-xl border ${
                errors.roomNumber ? 'border-rose-400 bg-rose-50/50' : 'border-slate-200'
              } focus:outline-hidden focus:ring-2 focus:ring-blue-900`}
              placeholder="e.g. A-105"
            />
            {errors.roomNumber && <p className="text-[11px] text-rose-500 mt-0.5">{errors.roomNumber}</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Block / Wing</label>
            <select
              value={formData.block}
              onChange={(e) => setFormData({ ...formData, block: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            >
              <option value="Block A (Sunrise)">Block A (Sunrise)</option>
              <option value="Block B (Harmony)">Block B (Harmony)</option>
              <option value="Block C (Scholars)">Block C (Scholars)</option>
              <option value="Block D (Executive)">Block D (Executive)</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Floor</label>
            <select
              value={formData.floor}
              onChange={(e) => setFormData({ ...formData, floor: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            >
              <option value="Ground Floor">Ground Floor</option>
              <option value="1st Floor">1st Floor</option>
              <option value="2nd Floor">2nd Floor</option>
              <option value="3rd Floor">3rd Floor</option>
              <option value="4th Floor">4th Floor</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Room Type</label>
            <select
              value={formData.type}
              onChange={(e) => handleTypeChange(e.target.value as RoomType)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            >
              <option value="Single">Single (1 Bed)</option>
              <option value="Double">Double (2 Beds)</option>
              <option value="Triple">Triple (3 Beds)</option>
              <option value="Four-Bed">Four-Bed (4 Beds)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Total Capacity</label>
            <input
              type="number"
              min={1}
              max={8}
              value={formData.capacity}
              onChange={(e) => setFormData({ ...formData, capacity: parseInt(e.target.value) || 1 })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Fee Per Semester (Rs.) *</label>
            <input
              type="number"
              min={100}
              step={50}
              value={formData.feePerSemester}
              onChange={(e) => setFormData({ ...formData, feePerSemester: parseFloat(e.target.value) || 0 })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Operational Status</label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as RoomStatus })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            >
              <option value="Available">Available for Allocation</option>
              <option value="Full">Full Occupancy</option>
              <option value="Maintenance">Under Maintenance / Closed</option>
            </select>
          </div>
        </div>

        {/* Amenities Selection */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1.5">Room Amenities</label>
          <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200/80">
            {COMMON_AMENITIES.map(amenity => {
              const isChecked = formData.amenities.includes(amenity);
              return (
                <label key={amenity} className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => toggleAmenity(amenity)}
                    className="rounded border-slate-300 text-blue-900 focus:ring-blue-900"
                  />
                  <span>{amenity}</span>
                </label>
              );
            })}
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {submitting ? 'Saving...' : initialData ? 'Update Room' : 'Add Room'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
