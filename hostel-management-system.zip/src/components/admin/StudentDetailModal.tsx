import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { Badge } from '../common/Badge';
import { useData } from '../../context/DataContext';
import { useToast } from '../common/Toast';
import type { Student } from '../../types';
import { 
  Mail, 
  Phone, 
  MapPin, 
  BookOpen, 
  Bed, 
  ShieldAlert, 
  CreditCard, 
  Calendar, 
  Activity,
  LogOut,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  MessageSquareWarning,
  Clock
} from 'lucide-react';

interface StudentDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null;
  onAllocate?: () => void;
  onReAdmit?: () => void;
}

export const StudentDetailModal: React.FC<StudentDetailModalProps> = ({
  isOpen,
  onClose,
  student,
  onAllocate,
  onReAdmit,
}) => {
  const { fees, complaints, reAdmitStudent } = useData();
  const { success, error: toastError } = useToast();
  const [activeTab, setActiveTab] = useState<'overview' | 'fees' | 'complaints'>('overview');
  const [isReAdmitting, setIsReAdmitting] = useState(false);

  if (!student) return null;

  const isLeftHostel = student.status === 'Left Hostel';

  const studentFees = fees.filter(f => f.studentId === student.studentId);
  const studentComplaints = complaints.filter(c => c.studentId === student.studentId);

  const pendingDues = studentFees
    .filter(f => f.status === 'Pending' || f.status === 'Overdue')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalPaid = studentFees
    .filter(f => f.status === 'Paid')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const handleReAdmit = async () => {
    setIsReAdmitting(true);
    try {
      await reAdmitStudent(student.id);
      success(`Student ${student.fullName} has been re-admitted as an active resident.`);
      onReAdmit?.();
      onClose();
    } catch (err: any) {
      toastError(err.message || 'Failed to re-admit student');
    } finally {
      setIsReAdmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isLeftHostel ? `Former Resident Dossier: ${student.fullName}` : `Student Dossier: ${student.fullName}`}
      subtitle={`Enrolled ID: ${student.studentId} • Joining Date: ${student.admissionDate}${isLeftHostel && student.leavingDate ? ` • Leaving Date: ${student.leavingDate}` : ''}`}
      maxWidth="3xl"
    >
      <div className="space-y-5 text-slate-700">
        {/* Header Profile Bar */}
        <div className={`flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl ${
          isLeftHostel 
            ? 'bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white' 
            : 'bg-gradient-to-r from-blue-900 via-blue-950 to-slate-900 text-white'
        } shadow-sm`}>
          <div className="flex items-center gap-3.5">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-extrabold ${
              isLeftHostel ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-white/10 border border-white/20 text-white'
            }`}>
              {student.fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-base font-bold">{student.fullName}</h4>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  isLeftHostel 
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30' 
                    : student.status === 'Active' 
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                    : 'bg-white/20 text-white'
                }`}>
                  {student.status}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                {student.course} • {student.branch} ({student.year})
              </p>
            </div>
          </div>

          <div className="text-right flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto">
            <span className="text-xs text-slate-300">
              {isLeftHostel ? 'Previous Room Record' : 'Current Room Status'}
            </span>
            <span className="text-sm font-bold bg-white/10 px-3 py-1 rounded-xl">
              {isLeftHostel
                ? student.previousRoomNumber 
                  ? `Room ${student.previousRoomNumber} (${student.previousBedNumber || 'Bed 1'})`
                  : 'No Prior Room'
                : student.roomNumber 
                  ? `Room ${student.roomNumber} (${student.bedNumber || 'Bed 1'})` 
                  : 'Not Allocated'
              }
            </span>
          </div>
        </div>

        {/* Departure Banner for Former Students */}
        {isLeftHostel && (
          <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <LogOut className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-amber-950">Hostel Departure Record</span>
                <p className="text-amber-800 text-[11px] mt-0.5">
                  Left on <strong className="font-semibold">{student.leavingDate || 'Recorded'}</strong>
                  {student.leavingReason ? ` • Reason: ${student.leavingReason}` : ''}
                </p>
              </div>
            </div>

            {student.previousRoomNumber && (
              <span className="px-2.5 py-1 rounded-lg bg-amber-100/80 font-medium text-amber-900 text-[11px] shrink-0">
                Vacated: Room {student.previousRoomNumber}
              </span>
            )}
          </div>
        )}

        {/* Navigation Tabs for Dossier */}
        <div className="flex items-center gap-1 border-b border-slate-200">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-2 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'overview'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Profile & History
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('fees')}
            className={`px-3.5 py-2 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'fees'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Fee Ledger ({studentFees.length})
            {pendingDues > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('complaints')}
            className={`px-3.5 py-2 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'complaints'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Complaints History ({studentComplaints.length})
          </button>
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-4">
            {/* Quick KPI stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 text-center">
                <span className="text-[11px] text-slate-500 font-medium block">Outstanding Dues</span>
                <span className={`text-base font-bold ${pendingDues > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                  Rs. {pendingDues.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-400 block">{studentFees.length} Invoices</span>
              </div>

              <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 text-center">
                <span className="text-[11px] text-slate-500 font-medium block">Total Paid Fees</span>
                <span className="text-base font-bold text-slate-900">
                  Rs. {totalPaid.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-400 block">Cleared to Date</span>
              </div>

              <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 text-center">
                <span className="text-[11px] text-slate-500 font-medium block">Hostel Joining Date</span>
                <span className="text-sm font-bold text-slate-900">{student.admissionDate || 'N/A'}</span>
                <span className="text-[10px] text-slate-400 block">Enrolled</span>
              </div>

              <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 text-center">
                <span className="text-[11px] text-slate-500 font-medium block">
                  {isLeftHostel ? 'Hostel Leaving Date' : 'Complaints Filed'}
                </span>
                <span className="text-sm font-bold text-slate-900">
                  {isLeftHostel ? (student.leavingDate || 'Recorded') : studentComplaints.length}
                </span>
                <span className="text-[10px] text-slate-400 block">
                  {isLeftHostel ? (student.leavingReason ? 'Check-out' : 'Recorded') : `${studentComplaints.filter(c => c.status === 'Resolved').length} Resolved`}
                </span>
              </div>
            </div>

            {/* Contact & Emergency Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border border-slate-200/80 bg-white space-y-2.5">
                <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-blue-700" /> Student Contact & Address
                </h5>
                <div className="text-xs space-y-1.5">
                  <p><strong className="text-slate-900">Email:</strong> {student.email}</p>
                  <p><strong className="text-slate-900">Phone:</strong> {student.phone}</p>
                  <p><strong className="text-slate-900">Blood Group:</strong> {student.bloodGroup || 'O+'}</p>
                  <p><strong className="text-slate-900">Permanent Address:</strong> {student.address || 'Not provided'}</p>
                </div>
              </div>

              <div className="p-4 rounded-xl border border-slate-200/80 bg-white space-y-2.5">
                <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-600" /> Emergency Guardian Contact
                </h5>
                <div className="text-xs space-y-1.5">
                  <p><strong className="text-slate-900">Guardian Name:</strong> {student.guardianName}</p>
                  <p><strong className="text-slate-900">Emergency Phone:</strong> {student.guardianPhone}</p>
                  <p className="text-[11px] text-slate-500 pt-1 leading-relaxed">
                    Primary family contact registered on student hostel admission dossier.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'fees' && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-slate-700" /> Fee Records & Payment History
              </h5>
              <span className="text-xs text-slate-500">
                Outstanding: <strong className={pendingDues > 0 ? 'text-rose-600' : 'text-emerald-600'}>Rs. {pendingDues.toLocaleString()}</strong>
              </span>
            </div>
            {studentFees.length > 0 ? (
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 font-bold text-slate-600">
                    <tr>
                      <th className="p-2.5">Invoice</th>
                      <th className="p-2.5">Semester</th>
                      <th className="p-2.5">Amount</th>
                      <th className="p-2.5">Due Date</th>
                      <th className="p-2.5">Paid Date</th>
                      <th className="p-2.5">Method / Txn</th>
                      <th className="p-2.5">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {studentFees.map(fee => (
                      <tr key={fee.id} className="hover:bg-slate-50/60">
                        <td className="p-2.5 font-semibold text-slate-900 font-mono">{fee.invoiceNumber}</td>
                        <td className="p-2.5">{fee.semester}</td>
                        <td className="p-2.5 font-bold text-slate-900">Rs. {fee.amount.toLocaleString()}</td>
                        <td className="p-2.5 text-slate-500">{fee.dueDate}</td>
                        <td className="p-2.5 text-slate-500">{fee.paymentDate || '—'}</td>
                        <td className="p-2.5 text-slate-500 font-mono text-[11px]">
                          {fee.transactionId || fee.paymentMethod || '—'}
                        </td>
                        <td className="p-2.5">
                          <Badge variant={fee.status === 'Paid' ? 'success' : 'danger'} size="sm">
                            {fee.status}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-6 text-center rounded-xl border border-dashed border-slate-200 text-slate-400 text-xs">
                No fee records found for this student.
              </div>
            )}
          </div>
        )}

        {activeTab === 'complaints' && (
          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1.5">
              <MessageSquareWarning className="w-3.5 h-3.5 text-slate-700" /> Maintenance & Grievances History
            </h5>
            {studentComplaints.length > 0 ? (
              <div className="space-y-2.5">
                {studentComplaints.map(comp => (
                  <div key={comp.id} className="p-3 rounded-xl border border-slate-200 bg-white space-y-1.5 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 font-semibold text-slate-700 text-[10px]">
                          {comp.category}
                        </span>
                        <h6 className="font-bold text-slate-900">{comp.title}</h6>
                      </div>
                      <Badge variant={comp.status === 'Resolved' ? 'success' : comp.status === 'In Progress' ? 'warning' : 'neutral'} size="sm">
                        {comp.status}
                      </Badge>
                    </div>
                    <p className="text-slate-600 text-xs">{comp.description}</p>
                    {comp.adminRemarks && (
                      <div className="p-2 rounded-lg bg-slate-50 border border-slate-100 text-[11px] text-slate-600">
                        <strong className="text-slate-800">Admin Resolution Remarks:</strong> {comp.adminRemarks}
                      </div>
                    )}
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                      <span>Reported: {new Date(comp.createdAt).toLocaleDateString()}</span>
                      {comp.resolvedAt && <span>Resolved: {new Date(comp.resolvedAt).toLocaleDateString()}</span>}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center rounded-xl border border-dashed border-slate-200 text-slate-400 text-xs">
                No complaints or grievances filed by this student.
              </div>
            )}
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Close Dossier
          </button>

          <div className="flex items-center gap-2">
            {isLeftHostel && (
              <button
                type="button"
                disabled={isReAdmitting}
                onClick={handleReAdmit}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl shadow-xs transition-all active:scale-98"
              >
                <RotateCcw className="w-3.5 h-3.5 text-blue-900" />
                {isReAdmitting ? 'Restoring...' : 'Re-admit Resident'}
              </button>
            )}

            {!isLeftHostel && !student.roomNumber && onAllocate && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onAllocate();
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-xs"
              >
                Allocate Room Now
              </button>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};

