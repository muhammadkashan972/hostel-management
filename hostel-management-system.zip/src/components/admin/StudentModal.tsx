import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import type { Student } from '../../types';

interface StudentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Student, 'id'>) => Promise<void>;
  initialData?: Student | null;
}

export const StudentModal: React.FC<StudentModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
}) => {
  const [formData, setFormData] = useState({
    studentId: '',
    fullName: '',
    email: '',
    phone: '',
    course: 'B.Tech',
    branch: 'Computer Science',
    year: '1st Year',
    guardianName: '',
    guardianPhone: '',
    address: '',
    bloodGroup: 'O+',
    status: 'Active' as Student['status'],
    admissionDate: new Date().toISOString().split('T')[0],
    leavingDate: '',
    leavingReason: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData({
        studentId: initialData.studentId || '',
        fullName: initialData.fullName || '',
        email: initialData.email || '',
        phone: initialData.phone || '',
        course: initialData.course || 'B.Tech',
        branch: initialData.branch || 'Computer Science',
        year: initialData.year || '1st Year',
        guardianName: initialData.guardianName || '',
        guardianPhone: initialData.guardianPhone || '',
        address: initialData.address || '',
        bloodGroup: initialData.bloodGroup || 'O+',
        status: initialData.status || 'Active',
        admissionDate: initialData.admissionDate || new Date().toISOString().split('T')[0],
        leavingDate: initialData.leavingDate || '',
        leavingReason: initialData.leavingReason || '',
      });
    } else {
      setFormData({
        studentId: `STU-2025-${Math.floor(100 + Math.random() * 900)}`,
        fullName: '',
        email: '',
        phone: '',
        course: 'B.Tech',
        branch: 'Computer Science',
        year: '1st Year',
        guardianName: '',
        guardianPhone: '',
        address: '',
        bloodGroup: 'O+',
        status: 'Active',
        admissionDate: new Date().toISOString().split('T')[0],
        leavingDate: '',
        leavingReason: '',
      });
    }
    setErrors({});
  }, [initialData, isOpen]);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.studentId.trim()) errs.studentId = 'Student ID is required';
    if (!formData.fullName.trim()) errs.fullName = 'Full name is required';
    if (!formData.email.trim() || !formData.email.includes('@')) errs.email = 'Valid email is required';
    if (!formData.phone.trim()) errs.phone = 'Phone number is required';
    if (!formData.guardianName.trim()) errs.guardianName = 'Guardian name is required';
    if (!formData.guardianPhone.trim()) errs.guardianPhone = 'Guardian phone is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    try {
      await onSubmit(formData);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrors({ form: err.message || 'Failed to save student record' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={initialData ? 'Edit Student Profile' : 'Enroll New Student'}
      subtitle="Complete student registration details for room allocation"
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {errors.form && (
          <div className="p-3 text-xs bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
            {errors.form}
          </div>
        )}

        {/* Academic Details */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Student ID *</label>
            <input
              type="text"
              value={formData.studentId}
              onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
              className={`w-full px-3 py-2 text-xs rounded-xl border ${
                errors.studentId ? 'border-rose-400 bg-rose-50/50' : 'border-slate-200'
              } focus:outline-hidden focus:ring-2 focus:ring-blue-900`}
              placeholder="e.g. STU-2025-101"
            />
            {errors.studentId && <p className="text-[11px] text-rose-500 mt-0.5">{errors.studentId}</p>}
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-bold text-slate-700 mb-1">Full Name *</label>
            <input
              type="text"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              className={`w-full px-3 py-2 text-xs rounded-xl border ${
                errors.fullName ? 'border-rose-400 bg-rose-50/50' : 'border-slate-200'
              } focus:outline-hidden focus:ring-2 focus:ring-blue-900`}
              placeholder="e.g. Sarah Connor"
            />
            {errors.fullName && <p className="text-[11px] text-rose-500 mt-0.5">{errors.fullName}</p>}
          </div>
        </div>

        {/* Contact Info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Email Address *</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className={`w-full px-3 py-2 text-xs rounded-xl border ${
                errors.email ? 'border-rose-400 bg-rose-50/50' : 'border-slate-200'
              } focus:outline-hidden focus:ring-2 focus:ring-blue-900`}
              placeholder="student@university.edu"
            />
            {errors.email && <p className="text-[11px] text-rose-500 mt-0.5">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number *</label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className={`w-full px-3 py-2 text-xs rounded-xl border ${
                errors.phone ? 'border-rose-400 bg-rose-50/50' : 'border-slate-200'
              } focus:outline-hidden focus:ring-2 focus:ring-blue-900`}
              placeholder="+1 (555) 000-0000"
            />
            {errors.phone && <p className="text-[11px] text-rose-500 mt-0.5">{errors.phone}</p>}
          </div>
        </div>

        {/* Course & Branch */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Degree Course</label>
            <select
              value={formData.course}
              onChange={(e) => setFormData({ ...formData, course: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            >
              <option value="B.Tech">B.Tech</option>
              <option value="B.Sc">B.Sc</option>
              <option value="B.Com">B.Com</option>
              <option value="M.Tech">M.Tech</option>
              <option value="M.B.A">M.B.A</option>
              <option value="Ph.D">Ph.D</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Branch / Major</label>
            <input
              type="text"
              value={formData.branch}
              onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
              placeholder="e.g. Computer Science"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Academic Year</label>
            <select
              value={formData.year}
              onChange={(e) => setFormData({ ...formData, year: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            >
              <option value="1st Year">1st Year</option>
              <option value="2nd Year">2nd Year</option>
              <option value="3rd Year">3rd Year</option>
              <option value="4th Year">4th Year</option>
            </select>
          </div>
        </div>

        {/* Guardian Information */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-100">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Guardian Name *</label>
            <input
              type="text"
              value={formData.guardianName}
              onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
              className={`w-full px-3 py-2 text-xs rounded-xl border ${
                errors.guardianName ? 'border-rose-400 bg-rose-50/50' : 'border-slate-200'
              } focus:outline-hidden focus:ring-2 focus:ring-blue-900`}
              placeholder="Parent / Guardian Name"
            />
            {errors.guardianName && <p className="text-[11px] text-rose-500 mt-0.5">{errors.guardianName}</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Guardian Emergency Phone *</label>
            <input
              type="tel"
              value={formData.guardianPhone}
              onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
              className={`w-full px-3 py-2 text-xs rounded-xl border ${
                errors.guardianPhone ? 'border-rose-400 bg-rose-50/50' : 'border-slate-200'
              } focus:outline-hidden focus:ring-2 focus:ring-blue-900`}
              placeholder="+1 (555) 999-9999"
            />
            {errors.guardianPhone && <p className="text-[11px] text-rose-500 mt-0.5">{errors.guardianPhone}</p>}
          </div>
        </div>

        {/* Address */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Permanent Residential Address</label>
          <textarea
            rows={2}
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="Street address, city, state, postal code"
          />
        </div>

        {/* Status & Admission */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Hostel Status</label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            >
              <option value="Active">Active</option>
              <option value="Left Hostel">Left Hostel</option>
              <option value="Inactive">Inactive</option>
              <option value="Vacated">Vacated</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Admission Date</label>
            <input
              type="date"
              value={formData.admissionDate}
              onChange={(e) => setFormData({ ...formData, admissionDate: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Blood Group</label>
            <select
              value={formData.bloodGroup}
              onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            >
              {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Conditional Departure Information if Left Hostel */}
        {formData.status === 'Left Hostel' && (
          <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-amber-950 mb-1">Hostel Leaving Date</label>
              <input
                type="date"
                value={formData.leavingDate || new Date().toISOString().split('T')[0]}
                onChange={(e) => setFormData({ ...formData, leavingDate: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-amber-300 focus:outline-hidden focus:ring-2 focus:ring-amber-600 bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-amber-950 mb-1">Leaving Reason</label>
              <input
                type="text"
                placeholder="e.g. Graduated, relocated, course completed"
                value={formData.leavingReason}
                onChange={(e) => setFormData({ ...formData, leavingReason: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-amber-300 focus:outline-hidden focus:ring-2 focus:ring-amber-600 bg-white"
              />
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {submitting ? 'Saving...' : initialData ? 'Save Changes' : 'Enroll Student'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
