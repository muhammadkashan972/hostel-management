import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { useData } from '../../context/DataContext';
import type { Visitor } from '../../types';

interface VisitorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Visitor, 'id' | 'status'>) => Promise<string>;
}

export const VisitorModal: React.FC<VisitorModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const { students } = useData();
  const [studentId, setStudentId] = useState('');
  const [visitorName, setVisitorName] = useState('');
  const [relationship, setRelationship] = useState('Parent');
  const [contactNumber, setContactNumber] = useState('');
  const [visitDate, setVisitDate] = useState(new Date().toISOString().split('T')[0]);
  const [entryTime, setEntryTime] = useState('');
  const [purpose, setPurpose] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (students.length > 0) {
      setStudentId(students[0].studentId);
    }
    setVisitorName('');
    setRelationship('Parent');
    setContactNumber('');
    setVisitDate(new Date().toISOString().split('T')[0]);
    setEntryTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    setPurpose('');
    setError('');
  }, [isOpen, students]);

  const selectedStudent = students.find(s => s.studentId === studentId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitorName.trim()) {
      setError('Visitor full name is required');
      return;
    }
    if (!contactNumber.trim()) {
      setError('Visitor contact number is required');
      return;
    }
    if (!studentId || !selectedStudent) {
      setError('Please select the resident student being visited');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      await onSubmit({
        studentId: selectedStudent.studentId,
        studentName: selectedStudent.fullName,
        roomNumber: selectedStudent.roomNumber || 'Unassigned',
        visitorName,
        relationship,
        contactNumber,
        visitDate,
        entryTime: entryTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        purpose: purpose || 'General visit',
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to record visitor entry');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Hostel Gate Check-In: Record Visitor"
      subtitle="Log visitor details for safety compliance and campus pass logging"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 text-xs bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
            {error}
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Resident Student to Visit *</label>
          <select
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
          >
            {students.map(s => (
              <option key={s.id} value={s.studentId}>
                {s.fullName} ({s.studentId}) • Room {s.roomNumber || 'None'}
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Visitor Full Name *</label>
            <input
              type="text"
              value={visitorName}
              onChange={(e) => setVisitorName(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
              placeholder="e.g. John Doe"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Relationship</label>
            <select
              value={relationship}
              onChange={(e) => setRelationship(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
            >
              <option value="Parent">Parent</option>
              <option value="Sibling">Sibling</option>
              <option value="Guardian">Guardian</option>
              <option value="Relative">Relative</option>
              <option value="Friend">Friend</option>
              <option value="Official / Vendor">Official / Vendor</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Contact Phone *</label>
            <input
              type="tel"
              value={contactNumber}
              onChange={(e) => setContactNumber(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
              placeholder="+1 (555) 000-0000"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Check-in Time</label>
            <input
              type="text"
              value={entryTime}
              onChange={(e) => setEntryTime(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
              placeholder="e.g. 10:30 AM"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Purpose of Visit</label>
          <input
            type="text"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="e.g. Deliver textbooks, weekend meet"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {submitting ? 'Checking In...' : 'Confirm Entry'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
