import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 
    | 'success' 
    | 'warning' 
    | 'danger' 
    | 'info' 
    | 'neutral' 
    | 'primary';
  className?: string;
  size?: 'sm' | 'md';
}

export const Badge: React.FC<BadgeProps> = ({ 
  children, 
  variant = 'neutral', 
  className = '',
  size = 'md' 
}) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs';

  const variantClasses = {
    success: 'bg-emerald-50 text-emerald-700 border-emerald-200 ring-1 ring-emerald-600/10',
    warning: 'bg-amber-50 text-amber-700 border-amber-200 ring-1 ring-amber-600/10',
    danger: 'bg-rose-50 text-rose-700 border-rose-200 ring-1 ring-rose-600/10',
    info: 'bg-sky-50 text-sky-700 border-sky-200 ring-1 ring-sky-600/10',
    neutral: 'bg-slate-100 text-slate-700 border-slate-200 ring-1 ring-slate-600/10',
    primary: 'bg-blue-50 text-blue-700 border-blue-200 ring-1 ring-blue-600/10',
  }[variant];

  return (
    <span 
      className={`inline-flex items-center gap-1.5 font-medium rounded-full border whitespace-nowrap ${sizeClasses} ${variantClasses} ${className}`}
    >
      {children}
    </span>
  );
};
