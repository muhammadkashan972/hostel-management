import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingSpinnerProps {
  label?: string;
  className?: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ 
  label = 'Loading data...', 
  className = '' 
}) => {
  return (
    <div className={`flex flex-col items-center justify-center p-12 text-center ${className}`}>
      <Loader2 className="w-8 h-8 text-blue-900 animate-spin mb-3" />
      {label && <p className="text-sm font-medium text-slate-500">{label}</p>}
    </div>
  );
};
