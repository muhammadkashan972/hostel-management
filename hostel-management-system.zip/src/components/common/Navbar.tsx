import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { 
  Menu, 
  Bell, 
  Database, 
  LogOut, 
  User as UserIcon, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  ChevronDown
} from 'lucide-react';
import { Modal } from './Modal';

interface NavbarProps {
  onToggleSidebar: () => void;
  title?: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar, title }) => {
  const { currentUser, role, logout, isFirebaseMode, loginAsDemoAdmin, loginAsDemoStudent } = useAuth();
  const { notices, complaints } = useData();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);

  const urgentNotices = notices.filter(n => n.priority === 'Urgent' || n.priority === 'Important');
  const pendingCount = role === 'admin' 
    ? complaints.filter(c => c.status === 'Pending').length 
    : complaints.filter(c => c.studentId === currentUser?.studentId && c.status === 'In Progress').length;

  const totalAlerts = urgentNotices.length + (pendingCount > 0 ? 1 : 0);

  return (
    <>
      <header 
        id="top-navbar"
        className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 sm:px-6 bg-white border-b border-slate-200/80 shadow-xs"
      >
        {/* Left: Mobile Toggle & Title */}
        <div className="flex items-center gap-3">
          <button
            id="mobile-sidebar-toggle"
            type="button"
            onClick={onToggleSidebar}
            className="lg:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div>
            <h1 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
              {title || 'Hostel Management System'}
            </h1>
            <p className="hidden sm:block text-xs text-slate-500 font-medium">
              {role === 'admin' ? 'Administrative Control Center' : 'Resident Student Portal'}
            </p>
          </div>
        </div>

        {/* Right: Mode Badge, Alerts, and User Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Database / Mode Status Badge (Only shown when Firebase Cloud is active) */}
          {isFirebaseMode && (
            <button
              id="firebase-status-badge"
              type="button"
              onClick={() => setShowConfigModal(true)}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border transition-all bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100"
              title="Click to view Firebase status and configuration info"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Firebase Cloud</span>
              <HelpCircle className="w-3 h-3 opacity-60 ml-0.5" />
            </button>
          )}

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              id="notifications-button"
              type="button"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition-colors"
              aria-label="View notifications"
            >
              <Bell className="w-5 h-5" />
              {totalAlerts > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-600 ring-2 ring-white animate-pulse" />
              )}
            </button>

            {showNotifications && (
              <div 
                id="notifications-popover"
                className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-100 p-4 z-50 animate-in fade-in zoom-in-95 duration-150"
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-2">
                  <h4 className="font-bold text-sm text-slate-900">Notifications & Alerts</h4>
                  <span className="text-xs font-medium text-slate-500">{totalAlerts} unread</span>
                </div>
                
                <div className="max-h-72 overflow-y-auto space-y-2 text-xs">
                  {urgentNotices.length > 0 ? (
                    urgentNotices.map(notice => (
                      <div key={notice.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 hover:bg-slate-100/70 transition-colors">
                        <div className="flex items-center justify-between font-semibold text-slate-900 mb-0.5">
                          <span className="truncate">{notice.title}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-100 text-rose-700 font-bold uppercase shrink-0">
                            {notice.priority}
                          </span>
                        </div>
                        <p className="text-slate-600 line-clamp-2 leading-relaxed">{notice.content}</p>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-6 text-slate-400">
                      <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-400 mb-1" />
                      No urgent alerts at this time
                    </div>
                  )}

                  {role === 'admin' && pendingCount > 0 && (
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200/60 text-amber-900">
                      <p className="font-semibold flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                        {pendingCount} Pending Complaints Require Review
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Menu */}
          <div className="relative">
            <button
              id="user-profile-menu-button"
              type="button"
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl hover:bg-slate-100 border border-transparent hover:border-slate-200 transition-all"
            >
              <div className="w-8 h-8 rounded-full bg-blue-900 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                {currentUser?.displayName ? currentUser.displayName.charAt(0).toUpperCase() : 'U'}
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-xs font-bold text-slate-900 truncate max-w-[120px]">
                  {currentUser?.displayName || 'User'}
                </p>
                <p className="text-[10px] font-semibold text-blue-800 uppercase tracking-wide">
                  {role}
                </p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            </button>

            {showUserMenu && (
              <div 
                id="user-menu-popover"
                className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 animate-in fade-in zoom-in-95 duration-150"
              >
                <div className="px-3 py-2 border-b border-slate-100 mb-1">
                  <p className="text-xs font-bold text-slate-900 truncate">{currentUser?.displayName}</p>
                  <p className="text-[11px] text-slate-500 truncate">{currentUser?.email}</p>
                  <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-100 text-blue-900">
                    Role: {role}
                  </span>
                </div>

                {/* Quick Role Switchers for testing */}
                <div className="px-2 py-1.5 bg-slate-50 rounded-xl mb-1 text-[11px] text-slate-600">
                  <p className="font-semibold text-slate-800 mb-1">Quick Switch Portal:</p>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        loginAsDemoAdmin();
                        setShowUserMenu(false);
                      }}
                      className={`px-2 py-1 rounded text-center font-medium transition-colors ${
                        role === 'admin' ? 'bg-blue-900 text-white' : 'bg-white border text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      Admin
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        loginAsDemoStudent();
                        setShowUserMenu(false);
                      }}
                      className={`px-2 py-1 rounded text-center font-medium transition-colors ${
                        role === 'student' ? 'bg-blue-900 text-white' : 'bg-white border text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      Student
                    </button>
                  </div>
                </div>

                <button
                  id="navbar-logout-button"
                  type="button"
                  onClick={() => {
                    setShowUserMenu(false);
                    logout();
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors text-left"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Firebase / Connection Info Modal */}
      <Modal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        title="Hostel Management System - Database Status"
        maxWidth="md"
      >
        <div className="space-y-4 text-sm text-slate-600 leading-relaxed">
          <div className="p-4 rounded-xl border bg-slate-50">
            <div className="flex items-center gap-2 mb-2">
              <span className={`w-3 h-3 rounded-full ${isFirebaseMode ? 'bg-emerald-500' : 'bg-blue-500'}`} />
              <strong className="text-slate-900 text-base">
                {isFirebaseMode ? 'Live Firebase Connected' : 'Running in Local Demo Storage Mode'}
              </strong>
            </div>
            <p className="text-xs text-slate-600">
              {isFirebaseMode 
                ? 'Your application is connected to live Firebase Firestore and Authentication. All updates reflect in real-time in your cloud database.' 
                : 'Your application is operating smoothly with full CRUD capabilities backed by resilient local persistence. All records (students, rooms, allocations, fees, complaints, visitors) are testable immediately.'}
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-2">
              Connecting to your own Firebase project:
            </h4>
            <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-600">
              <li>Open Firebase Console and create a project.</li>
              <li>Enable <strong>Email/Password</strong> authentication.</li>
              <li>Create a <strong>Firestore Database</strong> in production mode.</li>
              <li>Copy rules from <code className="px-1 py-0.5 bg-slate-100 rounded text-slate-800">firestore.rules</code>.</li>
              <li>Set your environment variables in <code className="px-1 py-0.5 bg-slate-100 rounded text-slate-800">.env</code> or Vercel Settings.</li>
            </ol>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={() => setShowConfigModal(false)}
              className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800"
            >
              Understood
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
};
