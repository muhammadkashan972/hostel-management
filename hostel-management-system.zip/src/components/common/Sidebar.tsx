import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { 
  LayoutDashboard, 
  Users, 
  DoorOpen, 
  KeyRound, 
  CreditCard, 
  MessageSquareWarning, 
  Megaphone, 
  UserCheck, 
  User, 
  Settings, 
  LogOut, 
  Building2, 
  X,
  Bed,
  Home,
  UserX
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { role, logout, currentUser } = useAuth();
  const { hostelSettings } = useData();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const adminNavItems = [
    { to: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/admin/students', label: 'Active Students', icon: Users },
    { to: '/admin/former-students', label: 'Former Students', icon: UserX },
    { to: '/admin/rooms', label: 'Rooms', icon: DoorOpen },
    { to: '/admin/allocations', label: 'Room Allocation', icon: KeyRound },
    { to: '/admin/fees', label: 'Fee Management', icon: CreditCard },
    { to: '/admin/complaints', label: 'Complaints', icon: MessageSquareWarning },
    { to: '/admin/notices', label: 'Notices & Circulars', icon: Megaphone },
    { to: '/admin/visitors', label: 'Visitor Logs', icon: UserCheck },
    { to: '/admin/profile', label: 'Admin Profile', icon: User },
    { to: '/admin/settings', label: 'Settings', icon: Settings },
  ];

  const studentNavItems = [
    { to: '/student/dashboard', label: 'My Dashboard', icon: LayoutDashboard },
    { to: '/student/room', label: 'My Room & Roommates', icon: Bed },
    { to: '/student/fees', label: 'My Fees & Receipts', icon: CreditCard },
    { to: '/student/complaints', label: 'My Complaints', icon: MessageSquareWarning },
    { to: '/student/notices', label: 'Hostel Notices', icon: Megaphone },
    { to: '/student/profile', label: 'My Profile & Account', icon: User },
    { to: '/student/settings', label: 'Hostel Settings', icon: Settings },
  ];

  const navItems = role === 'admin' ? adminNavItems : studentNavItems;

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          id="sidebar-backdrop"
          className="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-xs lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar Panel */}
      <aside
        id="main-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-slate-950 text-slate-300 flex flex-col transition-transform duration-200 ease-in-out border-r border-slate-800 ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Logo / Brand Header */}
        <div className="flex items-center justify-between h-16 px-5 border-b border-slate-800/80 bg-slate-950/50">
          <div className="flex items-center gap-3 overflow-hidden">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-md shrink-0 transition-colors"
              style={{ backgroundColor: hostelSettings?.primaryColor || '#1e40af' }}
            >
              <Building2 className="w-5 h-5" />
            </div>
            <div className="truncate">
              <span className="text-sm font-bold text-white tracking-tight leading-tight block truncate" title={hostelSettings?.hostelName || 'HostelSphere'}>
                {hostelSettings?.hostelName || 'HostelSphere'}
              </span>
              <span className="text-[10px] font-semibold text-slate-400 tracking-wider uppercase block">
                Management System
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Portal Indicator */}
        <div className="px-5 py-3 border-b border-slate-800/60 bg-slate-900/40">
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase font-bold tracking-wider text-slate-400">
              {role === 'admin' ? 'Warden Portal' : 'Student Portal'}
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-500/20 text-blue-300 border border-blue-500/30">
              {role}
            </span>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => {
                  if (window.innerWidth < 1024) onClose();
                }}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-150 ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </NavLink>
            );
          })}
        </nav>

        {/* User Card & Logout Footer */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-900/50 space-y-2">
          <div className="flex items-center gap-3 px-2 py-1.5">
            <div className="w-9 h-9 rounded-xl bg-slate-800 text-blue-400 flex items-center justify-center font-bold text-xs border border-slate-700">
              {currentUser?.displayName ? currentUser.displayName.charAt(0).toUpperCase() : 'U'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-white truncate">
                {currentUser?.displayName || 'User'}
              </p>
              <p className="text-[11px] text-slate-400 truncate">
                {currentUser?.email}
              </p>
            </div>
          </div>

          <button
            id="sidebar-logout-button"
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-rose-400 hover:text-white hover:bg-rose-600/20 border border-transparent hover:border-rose-500/30 transition-all"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>
    </>
  );
};
