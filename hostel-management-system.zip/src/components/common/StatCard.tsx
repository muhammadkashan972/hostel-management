import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  id?: string;
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  color?: 'blue' | 'emerald' | 'amber' | 'rose' | 'indigo' | 'slate';
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  id,
  title,
  value,
  subtitle,
  icon: Icon,
  color = 'blue',
  onClick,
}) => {
  const colorMap = {
    blue: {
      bg: 'bg-blue-50/70',
      iconColor: 'text-blue-700',
      border: 'border-blue-100/60',
      accent: 'bg-blue-600',
    },
    emerald: {
      bg: 'bg-emerald-50/70',
      iconColor: 'text-emerald-700',
      border: 'border-emerald-100/60',
      accent: 'bg-emerald-600',
    },
    amber: {
      bg: 'bg-amber-50/70',
      iconColor: 'text-amber-700',
      border: 'border-amber-100/60',
      accent: 'bg-amber-600',
    },
    rose: {
      bg: 'bg-rose-50/70',
      iconColor: 'text-rose-700',
      border: 'border-rose-100/60',
      accent: 'bg-rose-600',
    },
    indigo: {
      bg: 'bg-indigo-50/70',
      iconColor: 'text-indigo-700',
      border: 'border-indigo-100/60',
      accent: 'bg-indigo-600',
    },
    slate: {
      bg: 'bg-slate-100/80',
      iconColor: 'text-slate-700',
      border: 'border-slate-200/60',
      accent: 'bg-slate-700',
    },
  }[color];

  return (
    <div
      id={id}
      onClick={onClick}
      className={`relative bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/70 shadow-xs transition-all duration-200 ${
        onClick ? 'cursor-pointer hover:border-slate-300 hover:shadow-md active:scale-99' : ''
      }`}
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <span className="text-xs font-medium text-slate-500 tracking-wide uppercase">
            {title}
          </span>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1 tracking-tight">
            {value}
          </div>
          {subtitle && (
            <p className="text-xs text-slate-500 mt-1.5 font-medium flex items-center gap-1">
              {subtitle}
            </p>
          )}
        </div>
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${colorMap.bg} ${colorMap.iconColor} ${colorMap.border}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
};
