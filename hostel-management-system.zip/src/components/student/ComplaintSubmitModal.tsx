import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import type { ComplaintCategory, ComplaintPriority } from '../../types';

interface ComplaintSubmitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    category: ComplaintCategory;
    title: string;
    description: string;
    priority: ComplaintPriority;
  }) => Promise<void>;
}

export const ComplaintSubmitModal: React.FC<ComplaintSubmitModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const { currentUser } = useAuth();
  const { students } = useData();

  const [category, setCategory] = useState<ComplaintCategory>('Plumbing');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<ComplaintPriority>('Medium');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const studentObj = students.find(s => s.studentId === currentUser?.studentId || s.email === currentUser?.email);

  useEffect(() => {
    setTitle('');
    setDescription('');
    setCategory('Plumbing');
    setPriority('Medium');
    setError('');
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a short summary title');
      return;
    }
    if (!description.trim()) {
      setError('Please describe the problem clearly');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      await onSubmit({
        category,
        title,
        description,
        priority,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit complaint');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Submit Maintenance or Hostel Complaint"
      subtitle={`Room: ${studentObj?.roomNumber || 'Assigned Room'} • Ticket will be dispatched to Hostel Wardens`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 text-xs bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
            {error}
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Issue Category *</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as ComplaintCategory)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 bg-white"
          >
            <option value="Plumbing">Plumbing & Water Supply</option>
            <option value="Electrical">Electrical & Appliances</option>
            <option value="Carpentry">Carpentry & Furniture</option>
            <option value="Wi-Fi & Network">Wi-Fi & Internet Connectivity</option>
            <option value="Cleanliness">Room & Corridor Housekeeping</option>
            <option value="Discipline">Noise & Resident Discipline</option>
            <option value="Other">Other Grievance</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Brief Subject / Headline *</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="e.g. Study lamp plug socket sparking"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Urgency / Priority</label>
          <div className="grid grid-cols-4 gap-2">
            {(['Low', 'Medium', 'High', 'Urgent'] as ComplaintPriority[]).map(p => (
              <button
                key={p}
                type="button"
                onClick={() => setPriority(p)}
                className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                  priority === p
                    ? 'bg-blue-900 text-white border-blue-900 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Detailed Description *</label>
          <textarea
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
            placeholder="Please detail exact location in room, when the issue started, and any symptoms..."
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-900 hover:bg-blue-800 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {submitting ? 'Submitting...' : 'Lodge Complaint'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
