import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';

export const firebaseConfig = {
  apiKey: "AIzaSyDS6bzb6j6Wd4gqDYtfPYsp85WaJbvEFOw",
  authDomain: "hostelmanagement-6786f.firebaseapp.com",
  projectId: "hostelmanagement-6786f",
  storageBucket: "hostelmanagement-6786f.firebasestorage.app",
  messagingSenderId: "728200907796",
  appId: "1:728200907796:web:54aab255c4909ca0edab01",
  measurementId: "G-89KB0Y98FT"
};

export const isFirebaseConfigured = true;

let app: FirebaseApp;
let auth: Auth;
let db: Firestore;

try {
  app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
  auth = getAuth(app);
  db = getFirestore(app);
  console.info('[Firebase] Successfully initialized with project:', firebaseConfig.projectId);
} catch (error) {
  console.error('[Firebase] Initialization error:', error);
}

export { app, auth, db };