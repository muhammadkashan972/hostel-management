import React, { createContext, useContext, useState, useEffect, useTransition } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as firebaseSignOut, 
  onAuthStateChanged,
  updatePassword as firebaseUpdatePassword,
  type User as FirebaseUser
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, isFirebaseConfigured } from '../config/firebase';
import type { UserProfile, UserRole } from '../types';
import { INITIAL_USERS } from '../data/initialMockData';

interface AuthContextType {
  currentUser: UserProfile | null;
  role: UserRole | null;
  loading: boolean;
  isFirebaseMode: boolean;
  login: (email: string, password: string, selectedRole?: UserRole) => Promise<{ success: boolean; error?: string }>;
  registerStudent: (data: {
    fullName: string;
    email: string;
    password: string;
    studentId: string;
    phone: string;
    course: string;
    branch: string;
    year: string;
    guardianName: string;
    guardianPhone: string;
    address: string;
  }) => Promise<{ success: boolean; error?: string }>;
  signup: (data: {
    fullName: string;
    email: string;
    password: string;
    studentId: string;
    phone: string;
    course: string;
    branch: string;
    year: string;
    guardianName: string;
    guardianPhone: string;
    address: string;
  }) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  changePassword: (newPassword: string) => Promise<{ success: boolean; error?: string }>;
  loginAsDemoAdmin: () => void;
  loginAsDemoStudent: () => void;
  updateCurrentUserProfile: (updates: Partial<UserProfile>) => void;
  updateUserProfile: (updates: Partial<UserProfile>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_USER_KEY = 'hms_current_user';
const LOCAL_USERS_REPO_KEY = 'hms_users_repo';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [, startTransition] = useTransition();

  // Initialize and check persistent session
  useEffect(() => {
    if (isFirebaseConfigured && auth && db) {
      const firestore = db;
      const unsubscribe = onAuthStateChanged(auth, async (firebaseUser: FirebaseUser | null) => {
        if (firebaseUser) {
          try {
            const userDoc = await getDoc(doc(firestore, 'users', firebaseUser.uid));
            if (userDoc.exists()) {
              const data = userDoc.data() as UserProfile;
              setCurrentUser(data);
            } else {
              // User exists in auth but no doc yet - infer admin if specific email
              const inferredRole: UserRole = 
                firebaseUser.email === 'admin@hostel.com' || firebaseUser.email?.includes('admin') ? 'admin' : 'student';
              const newProfile: UserProfile = {
                uid: firebaseUser.uid,
                email: firebaseUser.email || '',
                displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
                role: inferredRole,
                createdAt: new Date().toISOString(),
              };
              await setDoc(doc(firestore, 'users', firebaseUser.uid), newProfile);
              setCurrentUser(newProfile);
            }
          } catch (err) {
            console.error('Error fetching user profile from Firestore:', err);
            // Fallback to basic profile
            setCurrentUser({
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || 'User',
              role: firebaseUser.email?.includes('admin') ? 'admin' : 'student',
              createdAt: new Date().toISOString(),
            });
          }
        } else {
          setCurrentUser(null);
        }
        setLoading(false);
      });

      return () => unsubscribe();
    } else {
      // Local Storage Demo Mode Session restore
      try {
        const stored = localStorage.getItem(LOCAL_USER_KEY);
        if (stored) {
          const parsed = JSON.parse(stored) as UserProfile;
          setCurrentUser(parsed);
        } else {
          // Default start with admin for easy preview exploration
          const defaultAdmin = INITIAL_USERS[0];
          setCurrentUser(defaultAdmin);
          localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(defaultAdmin));
        }
      } catch (e) {
        console.error('Failed to parse local user:', e);
        setCurrentUser(INITIAL_USERS[0]);
      }
      setLoading(false);
    }
  }, []);

  const login = async (email: string, password: string, selectedRole?: UserRole) => {
    const trimmedEmail = email.trim().toLowerCase();

    if (isFirebaseConfigured && auth && db) {
      try {
        const cred = await signInWithEmailAndPassword(auth, trimmedEmail, password);
        const userDoc = await getDoc(doc(db, 'users', cred.user.uid));
        if (userDoc.exists()) {
          const data = userDoc.data() as UserProfile;
          if (selectedRole && data.role !== selectedRole) {
            return {
              success: false,
              error: `Access Denied: This account is registered as a ${data.role.toUpperCase()}, not an ${selectedRole.toUpperCase()}.`
            };
          }
          setCurrentUser(data);
          return { success: true };
        }
        return { success: true };
      } catch (err: any) {
        return { success: false, error: err.message || 'Authentication failed' };
      }
    }

    // Local Demo Mode Authentication
    let usersList: UserProfile[] = INITIAL_USERS;
    try {
      const stored = localStorage.getItem(LOCAL_USERS_REPO_KEY);
      if (stored) {
        usersList = JSON.parse(stored);
      }
    } catch {
      // fallback
    }

    const matched = usersList.find(u => u.email.toLowerCase() === trimmedEmail);
    if (!matched) {
      // Auto-provision demo credentials if known or realistic
      if (trimmedEmail.includes('admin')) {
        const adminUser = INITIAL_USERS[0];
        setCurrentUser(adminUser);
        localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(adminUser));
        return { success: true };
      } else if (trimmedEmail.includes('student')) {
        const studentUser = INITIAL_USERS[1];
        setCurrentUser(studentUser);
        localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(studentUser));
        return { success: true };
      }
      return { success: false, error: 'User not found. Use demo buttons or register as a student.' };
    }

    if (selectedRole && matched.role !== selectedRole) {
      return {
        success: false,
        error: `Access Denied: You logged in to the ${selectedRole} portal, but this account is assigned the "${matched.role}" role.`
      };
    }

    setCurrentUser(matched);
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(matched));
    return { success: true };
  };

  const registerStudent = async (data: {
    fullName: string;
    email: string;
    password: string;
    studentId: string;
    phone: string;
    course: string;
    branch: string;
    year: string;
    guardianName: string;
    guardianPhone: string;
    address: string;
  }) => {
    const trimmedEmail = data.email.trim().toLowerCase();

    if (isFirebaseConfigured && auth && db) {
      try {
        const cred = await createUserWithEmailAndPassword(auth, trimmedEmail, data.password);
        const newProfile: UserProfile = {
          uid: cred.user.uid,
          email: trimmedEmail,
          displayName: data.fullName,
          role: 'student',
          studentId: data.studentId,
          phone: data.phone,
          createdAt: new Date().toISOString(),
        };
        await setDoc(doc(db, 'users', cred.user.uid), newProfile);
        // Also save student document in students collection
        await setDoc(doc(db, 'students', cred.user.uid), {
          id: cred.user.uid,
          uid: cred.user.uid,
          studentId: data.studentId,
          fullName: data.fullName,
          email: trimmedEmail,
          phone: data.phone,
          course: data.course,
          branch: data.branch,
          year: data.year,
          guardianName: data.guardianName,
          guardianPhone: data.guardianPhone,
          address: data.address,
          status: 'Active',
          admissionDate: new Date().toISOString().split('T')[0],
        });
        setCurrentUser(newProfile);
        return { success: true };
      } catch (err: any) {
        return { success: false, error: err.message || 'Registration failed' };
      }
    }

    // Local Demo Mode Registration
    const newUid = `student-${Date.now()}`;
    const newProfile: UserProfile = {
      uid: newUid,
      email: trimmedEmail,
      displayName: data.fullName,
      role: 'student',
      studentId: data.studentId,
      phone: data.phone,
      createdAt: new Date().toISOString(),
    };

    try {
      let usersList: UserProfile[] = [...INITIAL_USERS];
      const stored = localStorage.getItem(LOCAL_USERS_REPO_KEY);
      if (stored) usersList = JSON.parse(stored);
      usersList.push(newProfile);
      localStorage.setItem(LOCAL_USERS_REPO_KEY, JSON.stringify(usersList));
      localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(newProfile));
      setCurrentUser(newProfile);
      return { success: true };
    } catch {
      return { success: false, error: 'Could not complete registration locally' };
    }
  };

  const logout = async () => {
    if (isFirebaseConfigured && auth) {
      try {
        await firebaseSignOut(auth);
      } catch (e) {
        console.error('Firebase signout error:', e);
      }
    }
    localStorage.removeItem(LOCAL_USER_KEY);
    startTransition(() => {
      setCurrentUser(null);
    });
  };

  const changePassword = async (newPassword: string) => {
    if (isFirebaseConfigured && auth?.currentUser) {
      try {
        await firebaseUpdatePassword(auth.currentUser, newPassword);
        return { success: true };
      } catch (err: any) {
        return { success: false, error: err.message || 'Failed to update password' };
      }
    }
    // In local demo mode, simulate success
    return { success: true };
  };

  const loginAsDemoAdmin = () => {
    const adminUser = INITIAL_USERS[0];
    setCurrentUser(adminUser);
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(adminUser));
  };

  const loginAsDemoStudent = () => {
    const studentUser = INITIAL_USERS[1];
    setCurrentUser(studentUser);
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(studentUser));
  };

  const updateCurrentUserProfile = (updates: Partial<UserProfile>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...updates };
    setCurrentUser(updated);
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(updated));
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role: currentUser?.role || null,
        loading,
        isFirebaseMode: isFirebaseConfigured,
        login,
        registerStudent,
        signup: registerStudent,
        logout,
        changePassword,
        loginAsDemoAdmin,
        loginAsDemoStudent,
        updateCurrentUserProfile,
        updateUserProfile: updateCurrentUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
