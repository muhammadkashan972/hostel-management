import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc,
  setDoc
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../config/firebase';
import type { 
  Student, 
  Room, 
  Allocation, 
  Fee, 
  Complaint, 
  Notice, 
  Visitor, 
  DashboardStats,
  HostelSettings
} from '../types';
import { 
  INITIAL_STUDENTS, 
  INITIAL_ROOMS, 
  INITIAL_ALLOCATIONS, 
  INITIAL_FEES, 
  INITIAL_COMPLAINTS, 
  INITIAL_NOTICES, 
  INITIAL_VISITORS,
  DEFAULT_HOSTEL_SETTINGS
} from '../data/initialMockData';

interface DataContextType {
  students: Student[];
  rooms: Room[];
  allocations: Allocation[];
  fees: Fee[];
  complaints: Complaint[];
  notices: Notice[];
  visitors: Visitor[];
  stats: DashboardStats;
  hostelSettings: HostelSettings;
  loading: boolean;
  
  // Student Actions
  addStudent: (data: Omit<Student, 'id'>) => Promise<string>;
  updateStudent: (id: string, updates: Partial<Student>) => Promise<void>;
  deleteStudent: (id: string) => Promise<void>;
  deleteStudentPermanently: (id: string) => Promise<void>;
  markStudentLeftHostel: (studentId: string, leavingDate?: string, leavingReason?: string) => Promise<{ success: boolean; error?: string }>;
  reAdmitStudent: (id: string) => Promise<void>;
  
  // Room Actions
  addRoom: (data: Omit<Room, 'id'>) => Promise<string>;
  updateRoom: (id: string, updates: Partial<Room>) => Promise<void>;
  deleteRoom: (id: string) => Promise<void>;
  
  // Allocation Actions
  allocateRoom: (studentId: string, roomId: string, bedNumber: string, remarks?: string) => Promise<{ success: boolean; error?: string }>;
  changeRoom: (studentId: string, newRoomId: string, newBedNumber: string, remarks?: string) => Promise<{ success: boolean; error?: string }>;
  deallocateRoom: (studentId: string) => Promise<void>;
  
  // Fee Actions
  addFee: (data: Omit<Fee, 'id' | 'invoiceNumber'>) => Promise<string>;
  updateFeeStatus: (id: string, status: Fee['status'], details?: { paymentMethod?: string; transactionId?: string; paymentDate?: string }) => Promise<void>;
  deleteFee: (id: string) => Promise<void>;
  
  // Complaint Actions
  submitComplaint: (data: Omit<Complaint, 'id' | 'createdAt' | 'status'>) => Promise<string>;
  updateComplaintStatus: (id: string, status: Complaint['status'], adminRemarks?: string) => Promise<void>;
  deleteComplaint: (id: string) => Promise<void>;
  
  // Notice Actions
  addNotice: (data: Omit<Notice, 'id' | 'createdAt'>) => Promise<string>;
  updateNotice: (id: string, updates: Partial<Notice>) => Promise<void>;
  deleteNotice: (id: string) => Promise<void>;
  
  // Visitor Actions
  logVisitor: (data: Omit<Visitor, 'id' | 'status'>) => Promise<string>;
  checkoutVisitor: (id: string, exitTime?: string) => Promise<void>;
  deleteVisitor: (id: string) => Promise<void>;
  
  // Settings Actions
  updateHostelSettings: (settings: Partial<HostelSettings>) => Promise<void>;
  resetHostelSettingsToDefault: () => Promise<void>;

  // Convenient Aliases for pages
  vacateRoom: (studentId: string) => Promise<void>;
  recordPayment: (id: string, paymentMethod: string, transactionId: string) => Promise<void>;
  createNotice: (data: Omit<Notice, 'id' | 'createdAt'>) => Promise<string>;
  addComplaint: (data: Omit<Complaint, 'id' | 'createdAt' | 'status'>) => Promise<string>;
  addVisitor: (data: Omit<Visitor, 'id' | 'status'>) => Promise<string>;
  checkOutVisitor: (id: string, exitTime?: string) => Promise<void>;
  resetToMockData: () => void;

  // Reset
  resetToInitialData: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

// Storage Keys
const S_KEYS = {
  STUDENTS: 'hms_data_students',
  ROOMS: 'hms_data_rooms',
  ALLOCATIONS: 'hms_data_allocations',
  FEES: 'hms_data_fees',
  COMPLAINTS: 'hms_data_complaints',
  NOTICES: 'hms_data_notices',
  VISITORS: 'hms_data_visitors',
  SETTINGS: 'hms_data_hostel_settings',
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [allocations, setAllocations] = useState<Allocation[]>([]);
  const [fees, setFees] = useState<Fee[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [hostelSettings, setHostelSettings] = useState<HostelSettings>(() => {
    try {
      const saved = localStorage.getItem('hms_data_hostel_settings');
      return saved ? JSON.parse(saved) : DEFAULT_HOSTEL_SETTINGS;
    } catch {
      return DEFAULT_HOSTEL_SETTINGS;
    }
  });
  const [loading, setLoading] = useState(true);

  // Apply dynamic branding to document root and title
  useEffect(() => {
    if (hostelSettings?.primaryColor) {
      document.documentElement.style.setProperty('--brand-primary', hostelSettings.primaryColor);
    }
    if (hostelSettings?.hostelName) {
      document.title = `${hostelSettings.hostelName} - Hostel Portal`;
    }
  }, [hostelSettings?.primaryColor, hostelSettings?.hostelName]);

  // Initialize or Listen to Data
  useEffect(() => {
    if (isFirebaseConfigured && db) {
      // Connect to live Firestore collections with real-time listeners
      const unsubStudents = onSnapshot(collection(db, 'students'), (snap) => {
        setStudents(snap.docs.map(d => ({ id: d.id, ...d.data() } as Student)));
      });
      const unsubRooms = onSnapshot(collection(db, 'rooms'), (snap) => {
        setRooms(snap.docs.map(d => ({ id: d.id, ...d.data() } as Room)));
      });
      const unsubAlloc = onSnapshot(collection(db, 'allocations'), (snap) => {
        setAllocations(snap.docs.map(d => ({ id: d.id, ...d.data() } as Allocation)));
      });
      const unsubFees = onSnapshot(collection(db, 'fees'), (snap) => {
        setFees(snap.docs.map(d => ({ id: d.id, ...d.data() } as Fee)));
      });
      const unsubComp = onSnapshot(collection(db, 'complaints'), (snap) => {
        setComplaints(snap.docs.map(d => ({ id: d.id, ...d.data() } as Complaint)));
      });
      const unsubNot = onSnapshot(collection(db, 'notices'), (snap) => {
        setNotices(snap.docs.map(d => ({ id: d.id, ...d.data() } as Notice)));
      });
      const unsubVis = onSnapshot(collection(db, 'visitors'), (snap) => {
        setVisitors(snap.docs.map(d => ({ id: d.id, ...d.data() } as Visitor)));
      });
      const unsubSettings = onSnapshot(doc(db, 'settings', 'general'), (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data() as HostelSettings;
          setHostelSettings(data);
          saveLocal(S_KEYS.SETTINGS, data);
        }
      });

      setLoading(false);

      return () => {
        unsubStudents();
        unsubRooms();
        unsubAlloc();
        unsubFees();
        unsubComp();
        unsubNot();
        unsubVis();
        unsubSettings();
      };
    } else {
      // Local Storage Persistent Store
      const load = <T,>(key: string, fallback: T): T => {
        try {
          const item = localStorage.getItem(key);
          return item ? JSON.parse(item) : fallback;
        } catch {
          return fallback;
        }
      };

      setStudents(load(S_KEYS.STUDENTS, INITIAL_STUDENTS));
      setRooms(load(S_KEYS.ROOMS, INITIAL_ROOMS));
      setAllocations(load(S_KEYS.ALLOCATIONS, INITIAL_ALLOCATIONS));
      setFees(load(S_KEYS.FEES, INITIAL_FEES));
      setComplaints(load(S_KEYS.COMPLAINTS, INITIAL_COMPLAINTS));
      setNotices(load(S_KEYS.NOTICES, INITIAL_NOTICES));
      setVisitors(load(S_KEYS.VISITORS, INITIAL_VISITORS));
      setHostelSettings(load(S_KEYS.SETTINGS, DEFAULT_HOSTEL_SETTINGS));
      setLoading(false);
    }
  }, []);

  // Helper to persist local updates
  const saveLocal = useCallback((key: string, data: any) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error('LocalStorage write error:', e);
    }
  }, []);

  // Reset to initial mock dataset
  const resetToInitialData = () => {
    setStudents(INITIAL_STUDENTS);
    setRooms(INITIAL_ROOMS);
    setAllocations(INITIAL_ALLOCATIONS);
    setFees(INITIAL_FEES);
    setComplaints(INITIAL_COMPLAINTS);
    setNotices(INITIAL_NOTICES);
    setVisitors(INITIAL_VISITORS);
    setHostelSettings(DEFAULT_HOSTEL_SETTINGS);

    saveLocal(S_KEYS.STUDENTS, INITIAL_STUDENTS);
    saveLocal(S_KEYS.ROOMS, INITIAL_ROOMS);
    saveLocal(S_KEYS.ALLOCATIONS, INITIAL_ALLOCATIONS);
    saveLocal(S_KEYS.FEES, INITIAL_FEES);
    saveLocal(S_KEYS.COMPLAINTS, INITIAL_COMPLAINTS);
    saveLocal(S_KEYS.NOTICES, INITIAL_NOTICES);
    saveLocal(S_KEYS.VISITORS, INITIAL_VISITORS);
    saveLocal(S_KEYS.SETTINGS, DEFAULT_HOSTEL_SETTINGS);
  };

  // Student Actions
  const addStudent = async (data: Omit<Student, 'id'>): Promise<string> => {
    if (isFirebaseConfigured && db) {
      const docRef = await addDoc(collection(db, 'students'), data);
      return docRef.id;
    }
    const newId = `stu-${Date.now()}`;
    const newStudent: Student = { ...data, id: newId };
    const updated = [newStudent, ...students];
    setStudents(updated);
    saveLocal(S_KEYS.STUDENTS, updated);
    return newId;
  };

  const updateStudent = async (id: string, updates: Partial<Student>) => {
    if (isFirebaseConfigured && db) {
      await updateDoc(doc(db, 'students', id), updates);
      return;
    }
    const updated = students.map(s => (s.id === id ? { ...s, ...updates } : s));
    setStudents(updated);
    saveLocal(S_KEYS.STUDENTS, updated);
  };

  const deleteStudent = async (id: string) => {
    const studentToDelete = students.find(s => s.id === id);
    if (studentToDelete?.studentId) {
      // Deallocate room if allocated
      await deallocateRoom(studentToDelete.studentId);
    }
    if (isFirebaseConfigured && db) {
      await deleteDoc(doc(db, 'students', id));
      return;
    }
    const updated = students.filter(s => s.id !== id);
    setStudents(updated);
    saveLocal(S_KEYS.STUDENTS, updated);
  };

  // Room Actions
  const addRoom = async (data: Omit<Room, 'id'>): Promise<string> => {
    const calculatedRoom: Omit<Room, 'id'> = {
      ...data,
      currentOccupants: 0,
      availableBeds: data.capacity,
      status: 'Available',
    };
    if (isFirebaseConfigured && db) {
      const docRef = await addDoc(collection(db, 'rooms'), calculatedRoom);
      return docRef.id;
    }
    const newId = `room-${Date.now()}`;
    const newRoom: Room = { ...calculatedRoom, id: newId };
    const updated = [...rooms, newRoom];
    setRooms(updated);
    saveLocal(S_KEYS.ROOMS, updated);
    return newId;
  };

  const updateRoom = async (id: string, updates: Partial<Room>) => {
    if (isFirebaseConfigured && db) {
      await updateDoc(doc(db, 'rooms', id), updates);
      return;
    }
    const updated = rooms.map(r => (r.id === id ? { ...r, ...updates } : r));
    setRooms(updated);
    saveLocal(S_KEYS.ROOMS, updated);
  };

  const deleteRoom = async (id: string) => {
    if (isFirebaseConfigured && db) {
      await deleteDoc(doc(db, 'rooms', id));
      return;
    }
    const updated = rooms.filter(r => r.id !== id);
    setRooms(updated);
    saveLocal(S_KEYS.ROOMS, updated);
  };

  // Room Allocation Actions
  const allocateRoom = async (studentId: string, roomId: string, bedNumber: string, remarks?: string) => {
    const targetRoom = rooms.find(r => r.id === roomId);
    const targetStudent = students.find(s => s.studentId === studentId || s.id === studentId);

    if (!targetRoom) return { success: false, error: 'Room not found' };
    if (!targetStudent) return { success: false, error: 'Student not found' };
    if (targetRoom.availableBeds <= 0) return { success: false, error: 'Selected room has no available beds' };
    if (targetRoom.status === 'Maintenance') return { success: false, error: 'Room is currently under maintenance' };

    // Check if student is already allocated
    const existingAlloc = allocations.find(a => a.studentId === targetStudent.studentId && a.status === 'Active');
    if (existingAlloc) {
      return { success: false, error: `Student is already allocated to Room ${existingAlloc.roomNumber}. Use change room instead.` };
    }

    const newAlloc: Allocation = {
      id: `alloc-${Date.now()}`,
      studentId: targetStudent.studentId,
      studentName: targetStudent.fullName,
      roomId: targetRoom.id,
      roomNumber: targetRoom.roomNumber,
      bedNumber: bedNumber || `Bed ${targetRoom.currentOccupants + 1}`,
      allocatedDate: new Date().toISOString().split('T')[0],
      status: 'Active',
      remarks: remarks || 'Initial room allocation',
    };

    // Update Room occupancy
    const newOccupants = targetRoom.currentOccupants + 1;
    const newAvailable = Math.max(0, targetRoom.capacity - newOccupants);
    const updatedRoom: Room = {
      ...targetRoom,
      currentOccupants: newOccupants,
      availableBeds: newAvailable,
      status: newAvailable === 0 ? 'Full' : 'Available',
    };

    // Update Student record
    const updatedStudent: Student = {
      ...targetStudent,
      roomNumber: targetRoom.roomNumber,
      bedNumber: newAlloc.bedNumber,
    };

    if (isFirebaseConfigured && db) {
      await addDoc(collection(db, 'allocations'), newAlloc);
      await updateDoc(doc(db, 'rooms', targetRoom.id), {
        currentOccupants: newOccupants,
        availableBeds: newAvailable,
        status: updatedRoom.status,
      });
      await updateDoc(doc(db, 'students', targetStudent.id), {
        roomNumber: targetRoom.roomNumber,
        bedNumber: newAlloc.bedNumber,
      });
      return { success: true };
    }

    const nextAllocations = [newAlloc, ...allocations];
    const nextRooms = rooms.map(r => (r.id === targetRoom.id ? updatedRoom : r));
    const nextStudents = students.map(s => (s.id === targetStudent.id ? updatedStudent : s));

    setAllocations(nextAllocations);
    setRooms(nextRooms);
    setStudents(nextStudents);

    saveLocal(S_KEYS.ALLOCATIONS, nextAllocations);
    saveLocal(S_KEYS.ROOMS, nextRooms);
    saveLocal(S_KEYS.STUDENTS, nextStudents);

    return { success: true };
  };

  const changeRoom = async (studentId: string, newRoomId: string, newBedNumber: string, remarks?: string) => {
    const targetStudent = students.find(s => s.studentId === studentId || s.id === studentId);
    const newRoom = rooms.find(r => r.id === newRoomId);

    if (!targetStudent) return { success: false, error: 'Student not found' };
    if (!newRoom) return { success: false, error: 'New room not found' };
    if (newRoom.availableBeds <= 0) return { success: false, error: 'New room has no available beds' };

    // Previous allocation
    const prevAlloc = allocations.find(a => a.studentId === targetStudent.studentId && a.status === 'Active');
    const oldRoom = prevAlloc ? rooms.find(r => r.id === prevAlloc.roomId || r.roomNumber === prevAlloc.roomNumber) : null;

    // Relocate previous allocation
    const updatedAllocations = allocations.map(a => {
      if (a.studentId === targetStudent.studentId && a.status === 'Active') {
        return { ...a, status: 'Relocated' as const };
      }
      return a;
    });

    const newAlloc: Allocation = {
      id: `alloc-${Date.now()}`,
      studentId: targetStudent.studentId,
      studentName: targetStudent.fullName,
      roomId: newRoom.id,
      roomNumber: newRoom.roomNumber,
      bedNumber: newBedNumber || `Bed 1`,
      allocatedDate: new Date().toISOString().split('T')[0],
      status: 'Active',
      remarks: remarks || `Relocated from Room ${oldRoom?.roomNumber || 'unknown'}`,
    };
    updatedAllocations.unshift(newAlloc);

    // Update old room and new room
    let nextRooms = [...rooms];
    if (oldRoom) {
      const oldOccupants = Math.max(0, oldRoom.currentOccupants - 1);
      const oldAvailable = Math.min(oldRoom.capacity, oldRoom.availableBeds + 1);
      nextRooms = nextRooms.map(r => r.id === oldRoom.id ? {
        ...r,
        currentOccupants: oldOccupants,
        availableBeds: oldAvailable,
        status: 'Available' as const,
      } : r);
    }

    const newOccupants = newRoom.currentOccupants + 1;
    const newAvailable = Math.max(0, newRoom.capacity - newOccupants);
    nextRooms = nextRooms.map(r => r.id === newRoom.id ? {
      ...r,
      currentOccupants: newOccupants,
      availableBeds: newAvailable,
      status: newAvailable === 0 ? 'Full' as const : 'Available' as const,
    } : r);

    // Update student
    const nextStudents = students.map(s => s.id === targetStudent.id ? {
      ...s,
      roomNumber: newRoom.roomNumber,
      bedNumber: newAlloc.bedNumber,
    } : s);

    setAllocations(updatedAllocations);
    setRooms(nextRooms);
    setStudents(nextStudents);

    saveLocal(S_KEYS.ALLOCATIONS, updatedAllocations);
    saveLocal(S_KEYS.ROOMS, nextRooms);
    saveLocal(S_KEYS.STUDENTS, nextStudents);

    return { success: true };
  };

  const deallocateRoom = async (studentId: string) => {
    const student = students.find(s => s.studentId === studentId || s.id === studentId);
    if (!student) return;

    const activeAlloc = allocations.find(a => a.studentId === student.studentId && a.status === 'Active');
    const room = activeAlloc ? rooms.find(r => r.id === activeAlloc.roomId || r.roomNumber === activeAlloc.roomNumber) : null;

    const updatedAllocations = allocations.map(a => {
      if (a.studentId === student.studentId && a.status === 'Active') {
        return { ...a, status: 'Cancelled' as const };
      }
      return a;
    });

    let nextRooms = [...rooms];
    if (room) {
      const newOccupants = Math.max(0, room.currentOccupants - 1);
      const newAvailable = Math.min(room.capacity, room.availableBeds + 1);
      nextRooms = nextRooms.map(r => r.id === room.id ? {
        ...r,
        currentOccupants: newOccupants,
        availableBeds: newAvailable,
        status: 'Available' as const,
      } : r);
    }

    const nextStudents = students.map(s => s.id === student.id ? {
      ...s,
      roomNumber: undefined,
      bedNumber: undefined,
      previousRoomNumber: room?.roomNumber || s.roomNumber || s.previousRoomNumber,
      previousBedNumber: s.bedNumber || s.previousBedNumber,
    } : s);

    setAllocations(updatedAllocations);
    setRooms(nextRooms);
    setStudents(nextStudents);

    saveLocal(S_KEYS.ALLOCATIONS, updatedAllocations);
    saveLocal(S_KEYS.ROOMS, nextRooms);
    saveLocal(S_KEYS.STUDENTS, nextStudents);
  };

  const markStudentLeftHostel = async (
    studentIdOrId: string,
    leavingDate?: string,
    leavingReason?: string
  ): Promise<{ success: boolean; error?: string }> => {
    const student = students.find(s => s.studentId === studentIdOrId || s.id === studentIdOrId);
    if (!student) {
      return { success: false, error: 'Student record not found' };
    }

    const depDate = leavingDate || new Date().toISOString().split('T')[0];
    const depReason = leavingReason || 'Checked out / Left Hostel';

    // Active allocation if any
    const activeAlloc = allocations.find(a => a.studentId === student.studentId && a.status === 'Active');
    const roomNum = student.roomNumber || activeAlloc?.roomNumber;
    const bedNum = student.bedNumber || activeAlloc?.bedNumber;
    const room = roomNum ? rooms.find(r => r.roomNumber === roomNum || (activeAlloc && r.id === activeAlloc.roomId)) : null;

    // 1. Cancel active allocation
    const updatedAllocations = allocations.map(a => {
      if (a.studentId === student.studentId && a.status === 'Active') {
        return {
          ...a,
          status: 'Cancelled' as const,
          remarks: `Left hostel on ${depDate}. ${depReason}`,
        };
      }
      return a;
    });

    // 2. Free room if student was assigned
    let nextRooms = [...rooms];
    if (room) {
      const newOccupants = Math.max(0, room.currentOccupants - 1);
      const newAvailable = Math.min(room.capacity, room.availableBeds + 1);
      const newStatus: Room['status'] = newAvailable > 0 && room.status !== 'Maintenance' ? 'Available' : room.status;

      nextRooms = nextRooms.map(r =>
        r.id === room.id
          ? {
              ...r,
              currentOccupants: newOccupants,
              availableBeds: newAvailable,
              status: newStatus,
            }
          : r
      );

      if (isFirebaseConfigured && db) {
        try {
          await updateDoc(doc(db, 'rooms', room.id), {
            currentOccupants: newOccupants,
            availableBeds: newAvailable,
            status: newStatus,
          });
        } catch (err) {
          console.warn('[Firebase] Room update error:', err);
        }
      }
    }

    // 3. Update student record to 'Left Hostel'
    const updatedStudent: Student = {
      ...student,
      status: 'Left Hostel',
      roomNumber: undefined,
      bedNumber: undefined,
      previousRoomNumber: roomNum || student.previousRoomNumber,
      previousBedNumber: bedNum || student.previousBedNumber,
      leavingDate: depDate,
      leavingReason: depReason,
    };

    const nextStudents = students.map(s => (s.id === student.id ? updatedStudent : s));

    if (isFirebaseConfigured && db) {
      try {
        await updateDoc(doc(db, 'students', student.id), {
          status: 'Left Hostel',
          roomNumber: null,
          bedNumber: null,
          previousRoomNumber: roomNum || student.previousRoomNumber || '',
          previousBedNumber: bedNum || student.previousBedNumber || '',
          leavingDate: depDate,
          leavingReason: depReason,
        });
        if (activeAlloc) {
          await updateDoc(doc(db, 'allocations', activeAlloc.id), {
            status: 'Cancelled',
            remarks: `Left hostel on ${depDate}. ${depReason}`,
          });
        }
      } catch (err) {
        console.warn('[Firebase] Student mark left error:', err);
      }
    }

    setAllocations(updatedAllocations);
    setRooms(nextRooms);
    setStudents(nextStudents);

    saveLocal(S_KEYS.ALLOCATIONS, updatedAllocations);
    saveLocal(S_KEYS.ROOMS, nextRooms);
    saveLocal(S_KEYS.STUDENTS, nextStudents);

    return { success: true };
  };

  const reAdmitStudent = async (studentIdOrId: string) => {
    const student = students.find(s => s.studentId === studentIdOrId || s.id === studentIdOrId);
    if (!student) return;

    const updatedStudent: Student = {
      ...student,
      status: 'Active',
      roomNumber: undefined,
      bedNumber: undefined,
      admissionDate: new Date().toISOString().split('T')[0],
      leavingDate: undefined,
      leavingReason: undefined,
    };

    const nextStudents = students.map(s => (s.id === student.id ? updatedStudent : s));

    if (isFirebaseConfigured && db) {
      try {
        await updateDoc(doc(db, 'students', student.id), {
          status: 'Active',
          roomNumber: null,
          bedNumber: null,
          admissionDate: updatedStudent.admissionDate,
          leavingDate: null,
          leavingReason: null,
        });
      } catch (err) {
        console.warn('[Firebase] Student re-admit error:', err);
      }
    }

    setStudents(nextStudents);
    saveLocal(S_KEYS.STUDENTS, nextStudents);
  };

  // Fee Actions
  const addFee = async (data: Omit<Fee, 'id' | 'invoiceNumber'>): Promise<string> => {
    const invoiceNumber = `INV-${new Date().getFullYear()}-${String(Math.floor(1000 + Math.random() * 9000))}`;
    const fullFee: Fee = {
      ...data,
      id: `fee-${Date.now()}`,
      invoiceNumber,
    };
    if (isFirebaseConfigured && db) {
      const docRef = await addDoc(collection(db, 'fees'), fullFee);
      return docRef.id;
    }
    const updated = [fullFee, ...fees];
    setFees(updated);
    saveLocal(S_KEYS.FEES, updated);
    return fullFee.id;
  };

  const updateFeeStatus = async (id: string, status: Fee['status'], details?: { paymentMethod?: string; transactionId?: string; paymentDate?: string }) => {
    const updates: Partial<Fee> = {
      status,
      paymentDate: status === 'Paid' ? (details?.paymentDate || new Date().toISOString().split('T')[0]) : undefined,
      paymentMethod: details?.paymentMethod,
      transactionId: details?.transactionId || (status === 'Paid' ? `TXN-${Math.floor(10000000 + Math.random() * 90000000)}` : undefined),
    };

    if (isFirebaseConfigured && db) {
      await updateDoc(doc(db, 'fees', id), updates);
      return;
    }

    const updated = fees.map(f => f.id === id ? { ...f, ...updates } : f);
    setFees(updated);
    saveLocal(S_KEYS.FEES, updated);
  };

  const deleteFee = async (id: string) => {
    if (isFirebaseConfigured && db) {
      await deleteDoc(doc(db, 'fees', id));
      return;
    }
    const updated = fees.filter(f => f.id !== id);
    setFees(updated);
    saveLocal(S_KEYS.FEES, updated);
  };

  // Complaint Actions
  const submitComplaint = async (data: Omit<Complaint, 'id' | 'createdAt' | 'status'>): Promise<string> => {
    const newComplaint: Complaint = {
      ...data,
      id: `comp-${Date.now()}`,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };
    if (isFirebaseConfigured && db) {
      const docRef = await addDoc(collection(db, 'complaints'), newComplaint);
      return docRef.id;
    }
    const updated = [newComplaint, ...complaints];
    setComplaints(updated);
    saveLocal(S_KEYS.COMPLAINTS, updated);
    return newComplaint.id;
  };

  const updateComplaintStatus = async (id: string, status: Complaint['status'], adminRemarks?: string) => {
    const updates: Partial<Complaint> = {
      status,
      adminRemarks: adminRemarks !== undefined ? adminRemarks : undefined,
      resolvedAt: status === 'Resolved' || status === 'Closed' ? new Date().toISOString() : undefined,
    };
    if (isFirebaseConfigured && db) {
      await updateDoc(doc(db, 'complaints', id), updates);
      return;
    }
    const updated = complaints.map(c => c.id === id ? { ...c, ...updates } : c);
    setComplaints(updated);
    saveLocal(S_KEYS.COMPLAINTS, updated);
  };

  const deleteComplaint = async (id: string) => {
    if (isFirebaseConfigured && db) {
      await deleteDoc(doc(db, 'complaints', id));
      return;
    }
    const updated = complaints.filter(c => c.id !== id);
    setComplaints(updated);
    saveLocal(S_KEYS.COMPLAINTS, updated);
  };

  // Notice Actions
  const addNotice = async (data: Omit<Notice, 'id' | 'createdAt'>): Promise<string> => {
    const newNotice: Notice = {
      ...data,
      id: `not-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    if (isFirebaseConfigured && db) {
      const docRef = await addDoc(collection(db, 'notices'), newNotice);
      return docRef.id;
    }
    const updated = [newNotice, ...notices];
    setNotices(updated);
    saveLocal(S_KEYS.NOTICES, updated);
    return newNotice.id;
  };

  const updateNotice = async (id: string, updates: Partial<Notice>) => {
    if (isFirebaseConfigured && db) {
      await updateDoc(doc(db, 'notices', id), updates);
      return;
    }
    const updated = notices.map(n => n.id === id ? { ...n, ...updates } : n);
    setNotices(updated);
    saveLocal(S_KEYS.NOTICES, updated);
  };

  const deleteNotice = async (id: string) => {
    if (isFirebaseConfigured && db) {
      await deleteDoc(doc(db, 'notices', id));
      return;
    }
    const updated = notices.filter(n => n.id !== id);
    setNotices(updated);
    saveLocal(S_KEYS.NOTICES, updated);
  };

  // Visitor Actions
  const logVisitor = async (data: Omit<Visitor, 'id' | 'status'>): Promise<string> => {
    const newVisitor: Visitor = {
      ...data,
      id: `vis-${Date.now()}`,
      status: 'In Campus',
    };
    if (isFirebaseConfigured && db) {
      const docRef = await addDoc(collection(db, 'visitors'), newVisitor);
      return docRef.id;
    }
    const updated = [newVisitor, ...visitors];
    setVisitors(updated);
    saveLocal(S_KEYS.VISITORS, updated);
    return newVisitor.id;
  };

  const checkoutVisitor = async (id: string, exitTime?: string) => {
    const nowTime = exitTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const updates: Partial<Visitor> = {
      status: 'Checked Out',
      exitTime: nowTime,
    };
    if (isFirebaseConfigured && db) {
      await updateDoc(doc(db, 'visitors', id), updates);
      return;
    }
    const updated = visitors.map(v => v.id === id ? { ...v, ...updates } : v);
    setVisitors(updated);
    saveLocal(S_KEYS.VISITORS, updated);
  };

  const deleteVisitor = async (id: string) => {
    if (isFirebaseConfigured && db) {
      await deleteDoc(doc(db, 'visitors', id));
      return;
    }
    const updated = visitors.filter(v => v.id !== id);
    setVisitors(updated);
    saveLocal(S_KEYS.VISITORS, updated);
  };

  // Hostel Settings Actions (Firebase Cloud + Local Persistence)
  const updateHostelSettings = async (updates: Partial<HostelSettings>): Promise<void> => {
    const updated: HostelSettings = {
      ...hostelSettings,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    setHostelSettings(updated);
    saveLocal(S_KEYS.SETTINGS, updated);

    if (isFirebaseConfigured && db) {
      try {
        await setDoc(doc(db, 'settings', 'general'), updated, { merge: true });
      } catch (err) {
        console.warn('[Firebase] Settings save error:', err);
      }
    }
  };

  const resetHostelSettingsToDefault = async (): Promise<void> => {
    setHostelSettings(DEFAULT_HOSTEL_SETTINGS);
    saveLocal(S_KEYS.SETTINGS, DEFAULT_HOSTEL_SETTINGS);

    if (isFirebaseConfigured && db) {
      try {
        await setDoc(doc(db, 'settings', 'general'), DEFAULT_HOSTEL_SETTINGS);
      } catch (err) {
        console.warn('[Firebase] Settings reset error:', err);
      }
    }
  };

  // Real-time Computed Dashboard Statistics
  const stats: DashboardStats = useMemo(() => {
    const activeStudents = students.filter(s => s.status !== 'Left Hostel');
    const formerStudents = students.filter(s => s.status === 'Left Hostel');
    const totalStudents = activeStudents.length;
    const formerStudentsCount = formerStudents.length;
    const totalRooms = rooms.length;
    const occupiedRooms = rooms.filter(r => r.currentOccupants > 0).length;
    const availableRooms = rooms.filter(r => r.status === 'Available').length;

    const pendingFeesList = fees.filter(f => f.status === 'Pending' || f.status === 'Overdue');
    const pendingFeesCount = pendingFeesList.length;
    const totalPendingAmount = pendingFeesList.reduce((acc, curr) => acc + (curr.amount || 0), 0);

    const totalComplaints = complaints.length;
    const pendingComplaints = complaints.filter(c => c.status === 'Pending' || c.status === 'In Progress').length;
    const activeVisitors = visitors.filter(v => v.status === 'In Campus').length;

    const totalBeds = rooms.reduce((acc, curr) => acc + (curr.capacity || 0), 0);
    const occupiedBeds = rooms.reduce((acc, curr) => acc + (curr.currentOccupants || 0), 0);
    const availableBeds = rooms.reduce((acc, curr) => acc + (curr.availableBeds || 0), 0);
    const occupancyRate = totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0;
    const pendingFees = pendingFeesCount;

    return {
      totalStudents,
      formerStudentsCount,
      totalRooms,
      occupiedRooms,
      availableRooms,
      totalBeds,
      occupiedBeds,
      availableBeds,
      occupancyRate,
      pendingFees,
      pendingFeesCount,
      totalPendingAmount,
      totalComplaints,
      pendingComplaints,
      activeVisitors,
    };
  }, [students, rooms, fees, complaints, visitors]);

  return (
    <DataContext.Provider
      value={{
        students,
        rooms,
        allocations,
        fees,
        complaints,
        notices,
        visitors,
        stats,
        hostelSettings,
        loading,
        addStudent,
        updateStudent,
        deleteStudent,
        deleteStudentPermanently: deleteStudent,
        markStudentLeftHostel,
        reAdmitStudent,
        addRoom,
        updateRoom,
        deleteRoom,
        allocateRoom,
        changeRoom,
        deallocateRoom,
        vacateRoom: deallocateRoom,
        addFee,
        updateFeeStatus,
        recordPayment: async (id: string, method: string, txnId: string) => {
          await updateFeeStatus(id, 'Paid', {
            paymentMethod: method,
            transactionId: txnId,
            paymentDate: new Date().toISOString().split('T')[0],
          });
        },
        deleteFee,
        submitComplaint,
        addComplaint: submitComplaint,
        updateComplaintStatus,
        deleteComplaint,
        addNotice,
        createNotice: addNotice,
        updateNotice,
        deleteNotice,
        logVisitor,
        addVisitor: logVisitor,
        checkoutVisitor,
        checkOutVisitor: checkoutVisitor,
        deleteVisitor,
        updateHostelSettings,
        resetHostelSettingsToDefault,
        resetToInitialData,
        resetToMockData: resetToInitialData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
