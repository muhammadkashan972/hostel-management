import React, { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from '../components/common/Sidebar';
import { Navbar } from '../components/common/Navbar';

export const DashboardLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  // Dynamic header title helper based on route
  const getPageTitle = () => {
    const path = location.pathname;
    if (path.includes('/admin/dashboard')) return 'Hostel Overview & Analytics';
    if (path.includes('/admin/former-students')) return 'Former & Inactive Students Archive';
    if (path.includes('/admin/students')) return 'Active Students Directory & Admissions';
    if (path.includes('/admin/rooms')) return 'Room & Inventory Management';
    if (path.includes('/admin/allocations')) return 'Room & Bed Allocations';
    if (path.includes('/admin/fees')) return 'Fee Records & Invoices';
    if (path.includes('/admin/complaints')) return 'Hostel Complaints Desk';
    if (path.includes('/admin/notices')) return 'Notices & Announcements';
    if (path.includes('/admin/visitors')) return 'Security Gate & Visitor Logs';
    if (path.includes('/admin/profile')) return 'Administrator Profile';
    if (path.includes('/admin/settings')) return 'Hostel System Settings';

    if (path.includes('/student/dashboard')) return 'Student Portal Dashboard';
    if (path.includes('/student/room')) return 'My Room & Roommates';
    if (path.includes('/student/fees')) return 'My Hostel Fees & Invoices';
    if (path.includes('/student/complaints')) return 'My Grievances & Complaints';
    if (path.includes('/student/notices')) return 'Hostel Notice Board';
    if (path.includes('/student/profile')) return 'My Profile & Security';
    if (path.includes('/student/settings')) return 'Hostel Information & Settings';

    return 'Hostel Management System';
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-64">
        <Navbar 
          onToggleSidebar={() => setSidebarOpen(prev => !prev)} 
          title={getPageTitle()}
        />
        
        <main id="main-page-content" className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
