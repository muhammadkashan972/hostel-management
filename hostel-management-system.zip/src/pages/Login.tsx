import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Building2, Shield, User, Lock, Mail, ArrowRight, CheckCircle2, Sparkles } from 'lucide-react';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, registerStudent, loginAsDemoAdmin, loginAsDemoStudent, isFirebaseMode } = useAuth();

  const [activeTab, setActiveTab] = useState<'admin' | 'student'>('admin');
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('admin@hostel.edu');
  const [password, setPassword] = useState('admin123');
  const [fullName, setFullName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const from = (location.state as any)?.from?.pathname;

  const handleTabSwitch = (tab: 'admin' | 'student') => {
    setActiveTab(tab);
    setError('');
    if (tab === 'admin') {
      setEmail('admin@hostel.edu');
      setPassword('admin123');
    } else {
      setEmail('alex.johnson@student.edu');
      setPassword('student123');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignUp) {
        const res = await registerStudent({
          fullName: fullName || (activeTab === 'admin' ? 'Hostel Warden' : 'Resident Student'),
          email,
          password,
          studentId: studentId || `STU-${Math.floor(1000 + Math.random() * 9000)}`,
          phone: '+1 (555) 012-3456',
          course: 'B.Tech',
          branch: 'Engineering',
          year: '1st Year',
          guardianName: 'Guardian',
          guardianPhone: '+1 (555) 999-0000',
          address: 'Campus Hostel',
        });
        if (!res.success) {
          setError(res.error || 'Failed to register account');
          setLoading(false);
          return;
        }
      } else {
        const res = await login(email, password, activeTab);
        if (!res.success) {
          setError(res.error || 'Failed to authenticate. Check your credentials.');
          setLoading(false);
          return;
        }
      }
      
      const destination = from || (activeTab === 'admin' ? '/admin/dashboard' : '/student/dashboard');
      navigate(destination, { replace: true });
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to authenticate. Check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoAdmin = async () => {
    setError('');
    setLoading(true);
    try {
      await loginAsDemoAdmin();
      navigate('/admin/dashboard', { replace: true });
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoStudent = async () => {
    setError('');
    setLoading(true);
    try {
      await loginAsDemoStudent();
      navigate('/student/dashboard', { replace: true });
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background visual accents */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center z-10 px-4">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-600 shadow-xl shadow-blue-600/30 mb-4 border border-blue-400/30">
          <Building2 className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
          Hostel<span className="text-blue-400">Sphere</span>
        </h2>
        <p className="mt-1 text-xs sm:text-sm text-slate-400">
          Enterprise Hostel & Resident Campus Management System
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10 px-4">
        <div className="bg-slate-950/80 backdrop-blur-md py-8 px-6 sm:px-8 shadow-2xl rounded-3xl border border-slate-800">
          {/* Role Tabs */}
          <div className="flex p-1 bg-slate-900 rounded-2xl mb-6 border border-slate-800">
            <button
              id="tab-admin"
              type="button"
              onClick={() => handleTabSwitch('admin')}
              className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                activeTab === 'admin'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Shield className="w-4 h-4" />
              Admin Warden
            </button>
            <button
              id="tab-student"
              type="button"
              onClick={() => handleTabSwitch('student')}
              className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                activeTab === 'student'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="w-4 h-4" />
              Resident Student
            </button>
          </div>

          {/* Quick Demo Access banner */}
          <div className="mb-6 p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Instant Demo Access
              </span>
              <span className="text-[10px] text-slate-400">1-Click Launch</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                id="quick-demo-admin"
                onClick={handleDemoAdmin}
                className="px-3 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 text-xs font-semibold text-center transition-all"
              >
                Enter as Admin
              </button>
              <button
                type="button"
                id="quick-demo-student"
                onClick={handleDemoStudent}
                className="px-3 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 text-xs font-semibold text-center transition-all"
              >
                Enter as Student
              </button>
            </div>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Full Name</label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>
            )}

            {isSignUp && activeTab === 'student' && (
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Student Roll / Registration ID</label>
                <input
                  type="text"
                  required
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  placeholder="e.g. STU-2025-101"
                  className="w-full px-3 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@hostel.edu"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>
            </div>

            <button
              id="login-submit-button"
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                'Processing...'
              ) : isSignUp ? (
                `Create ${activeTab === 'admin' ? 'Admin' : 'Student'} Account`
              ) : (
                <>
                  Sign In to {activeTab === 'admin' ? 'Warden Portal' : 'Student Portal'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Toggle between Sign In and Sign Up */}
          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-xs text-slate-400 hover:text-blue-400 transition-colors"
            >
              {isSignUp
                ? 'Already have an account? Sign in here'
                : "Don't have an account? Register new user"}
            </button>
          </div>
        </div>

        {/* Footnote */}
        <p className="mt-6 text-center text-[11px] text-slate-500">
          Vercel-ready & Firebase Firestore cloud sync • Protected by Role-based Access Control
        </p>
      </div>
    </div>
  );
};
