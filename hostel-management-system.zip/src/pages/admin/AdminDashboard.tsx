import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../context/DataContext';
import { StatCard } from '../../components/common/StatCard';
import { Badge } from '../../components/common/Badge';
import { StudentModal } from '../../components/admin/StudentModal';
import { RoomModal } from '../../components/admin/RoomModal';
import { AllocationModal } from '../../components/admin/AllocationModal';
import { NoticeModal } from '../../components/admin/NoticeModal';
import { FeeModal } from '../../components/admin/FeeModal';
import { ComplaintModal } from '../../components/admin/ComplaintModal';
import { useToast } from '../../components/common/Toast';
import type { Complaint } from '../../types';
import {
  Users,
  DoorOpen,
  CheckCircle,
  Clock,
  AlertCircle,
  CreditCard,
  Plus,
  KeyRound,
  Megaphone,
  ArrowRight,
  TrendingUp,
  UserCheck
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { stats, complaints, notices, visitors, addStudent, addRoom, createNotice, addFee, updateComplaintStatus } = useData();
  const { success } = useToast();

  // Modals state
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [showRoomModal, setShowRoomModal] = useState(false);
  const [showAllocationModal, setShowAllocationModal] = useState(false);
  const [showNoticeModal, setShowNoticeModal] = useState(false);
  const [showFeeModal, setShowFeeModal] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  const pendingComplaints = complaints.filter(c => c.status === 'Pending' || c.status === 'In Progress');
  const recentComplaints = complaints.slice(0, 5);
  const recentNotices = notices.slice(0, 4);

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 sm:p-6 bg-gradient-to-r from-blue-900 via-blue-950 to-slate-900 rounded-3xl text-white shadow-md">
        <div>
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-500/20 text-blue-300 border border-blue-400/20">
            Hostel Operations Center
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold mt-1 tracking-tight">
            Administrative Management Overview
          </h2>
          <p className="text-xs sm:text-sm text-blue-200 mt-1 max-w-xl">
            Live overview of student occupancy, fee receivables, maintenance resolution desk, and residential security.
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            id="quick-add-student-btn"
            type="button"
            onClick={() => setShowStudentModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-all active:scale-98"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Student
          </button>
          <button
            id="quick-allocate-btn"
            type="button"
            onClick={() => setShowAllocationModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20 transition-all active:scale-98"
          >
            <KeyRound className="w-3.5 h-3.5" />
            Allocate Bed
          </button>
          <button
            id="quick-notice-btn"
            type="button"
            onClick={() => setShowNoticeModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20 transition-all active:scale-98"
          >
            <Megaphone className="w-3.5 h-3.5" />
            Broadcast
          </button>
        </div>
      </div>

      {/* Primary 6 Statistics Metrics Cards as specified by User */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <StatCard
          id="stat-total-students"
          title="Total Students"
          value={stats.totalStudents}
          subtitle="Enrolled Residents"
          icon={Users}
          color="blue"
          onClick={() => navigate('/admin/students')}
        />
        <StatCard
          id="stat-total-rooms"
          title="Total Rooms"
          value={stats.totalRooms}
          subtitle={`${stats.totalBeds} Total Beds`}
          icon={DoorOpen}
          color="slate"
          onClick={() => navigate('/admin/rooms')}
        />
        <StatCard
          id="stat-occupied-rooms"
          title="Occupied Rooms"
          value={stats.occupiedRooms}
          subtitle={`${stats.occupancyRate}% Bed Capacity`}
          icon={CheckCircle}
          color="indigo"
          onClick={() => navigate('/admin/rooms')}
        />
        <StatCard
          id="stat-available-rooms"
          title="Available Rooms"
          value={stats.availableRooms}
          subtitle={`${stats.availableBeds} Vacant Beds`}
          icon={Clock}
          color="emerald"
          onClick={() => navigate('/admin/allocations')}
        />
        <StatCard
          id="stat-pending-fees"
          title="Pending Fees"
          value={`Rs. ${(stats.totalPendingAmount || 0).toLocaleString()}`}
          subtitle={`${stats.pendingFeesCount} Unpaid Invoices`}
          icon={CreditCard}
          color="amber"
          onClick={() => navigate('/admin/fees')}
        />
        <StatCard
          id="stat-total-complaints"
          title="Total Complaints"
          value={stats.totalComplaints}
          subtitle={`${stats.pendingComplaints} Pending Review`}
          icon={AlertCircle}
          color="rose"
          onClick={() => navigate('/admin/complaints')}
        />
      </div>

      {/* Occupancy and Capacity Progress Bar Widget */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Hostel Bed Capacity & Occupancy Distribution</h3>
            <p className="text-xs text-slate-500">
              Real-time synchronization across Block A, Block B, and Block C residential wings
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-blue-900">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-900" />
              Occupied: {stats.occupiedBeds} Beds ({stats.occupancyRate}%)
            </span>
            <span className="flex items-center gap-1.5 text-emerald-600">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              Available: {stats.availableBeds} Beds
            </span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full h-3.5 bg-slate-100 rounded-full overflow-hidden flex">
          <div
            className="bg-blue-900 transition-all duration-500"
            style={{ width: `${Math.min(stats.occupancyRate, 100)}%` }}
          />
          <div
            className="bg-emerald-500 transition-all duration-500"
            style={{ width: `${Math.max(0, 100 - stats.occupancyRate)}%` }}
          />
        </div>
      </div>

      {/* Two Column Layout: Maintenance Desk & Broadcast Notices */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Complaints Table */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Maintenance & Complaints Desk</h3>
                <p className="text-xs text-slate-500">{pendingComplaints.length} tickets require action</p>
              </div>
              <button
                type="button"
                onClick={() => navigate('/admin/complaints')}
                className="text-xs font-bold text-blue-900 hover:text-blue-800 flex items-center gap-1"
              >
                View All <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {recentComplaints.length > 0 ? (
                recentComplaints.map(c => (
                  <div
                    key={c.id}
                    onClick={() => setSelectedComplaint(c)}
                    className="py-3 flex items-start justify-between gap-3 hover:bg-slate-50/80 p-2 rounded-xl transition-colors cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-slate-900">{c.title}</span>
                        <Badge 
                          variant={c.priority === 'Urgent' ? 'danger' : c.priority === 'High' ? 'warning' : 'neutral'}
                          size="sm"
                        >
                          {c.priority}
                        </Badge>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {c.studentName} (Room {c.roomNumber}) • {c.category}
                      </p>
                    </div>

                    <Badge
                      variant={
                        c.status === 'Resolved' ? 'success' : c.status === 'In Progress' ? 'warning' : 'danger'
                      }
                      size="sm"
                    >
                      {c.status}
                    </Badge>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400 py-6 text-center">No maintenance complaints registered</p>
              )}
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-100 flex justify-end">
            <span className="text-[11px] text-slate-400">Click any ticket to inspect & update status</span>
          </div>
        </div>

        {/* Recent Notices & Gate Logs */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Official Notices & Bulletins</h3>
                <p className="text-xs text-slate-500">Live communication with resident students</p>
              </div>
              <button
                type="button"
                onClick={() => navigate('/admin/notices')}
                className="text-xs font-bold text-blue-900 hover:text-blue-800 flex items-center gap-1"
              >
                Notice Board <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {recentNotices.length > 0 ? (
                recentNotices.map(notice => (
                  <div
                    key={notice.id}
                    className="p-3 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-all"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-slate-900 truncate">{notice.title}</span>
                      <Badge
                        variant={notice.priority === 'Urgent' ? 'danger' : notice.priority === 'Important' ? 'warning' : 'primary'}
                        size="sm"
                      >
                        {notice.priority}
                      </Badge>
                    </div>
                    <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                      {notice.content}
                    </p>
                    <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1.5">
                      <span>{notice.category} • For: {notice.targetAudience}</span>
                      <span>{new Date(notice.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400 py-6 text-center">No notices published yet</p>
              )}
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Need to inform all residents?</span>
            <button
              type="button"
              onClick={() => setShowNoticeModal(true)}
              className="text-blue-900 font-bold hover:underline"
            >
              + Create Announcement
            </button>
          </div>
        </div>
      </div>

      {/* Quick Launch Operations Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          type="button"
          onClick={() => setShowRoomModal(true)}
          className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-slate-300 shadow-xs flex items-center gap-3 text-left transition-all hover:bg-slate-50"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center shrink-0">
            <DoorOpen className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-900">Add New Room</p>
            <p className="text-[11px] text-slate-500">Create room & beds</p>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setShowFeeModal(true)}
          className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-slate-300 shadow-xs flex items-center gap-3 text-left transition-all hover:bg-slate-50"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <CreditCard className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-900">Generate Invoice</p>
            <p className="text-[11px] text-slate-500">Issue semester fee</p>
          </div>
        </button>

        <button
          type="button"
          onClick={() => navigate('/admin/visitors')}
          className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-slate-300 shadow-xs flex items-center gap-3 text-left transition-all hover:bg-slate-50"
        >
          <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <UserCheck className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-900">Gate Visitors</p>
            <p className="text-[11px] text-slate-500">{visitors.filter(v => v.status === 'In Campus').length} on campus</p>
          </div>
        </button>
      </div>

      {/* Modals */}
      <StudentModal
        isOpen={showStudentModal}
        onClose={() => setShowStudentModal(false)}
        onSubmit={async (data) => {
          await addStudent(data);
          success(`Student ${data.fullName} enrolled successfully!`);
        }}
      />

      <RoomModal
        isOpen={showRoomModal}
        onClose={() => setShowRoomModal(false)}
        onSubmit={async (data) => {
          await addRoom(data);
          success(`Room ${data.roomNumber} created successfully!`);
        }}
      />

      <AllocationModal
        isOpen={showAllocationModal}
        onClose={() => setShowAllocationModal(false)}
      />

      <NoticeModal
        isOpen={showNoticeModal}
        onClose={() => setShowNoticeModal(false)}
        onSubmit={async (data) => {
          await createNotice(data);
          success('Notice broadcasted to all residents!');
        }}
      />

      <FeeModal
        isOpen={showFeeModal}
        onClose={() => setShowFeeModal(false)}
        onSubmit={async (data) => {
          const id = await addFee(data);
          success('Fee record generated successfully!');
          return id;
        }}
      />

      <ComplaintModal
        isOpen={Boolean(selectedComplaint)}
        onClose={() => setSelectedComplaint(null)}
        complaint={selectedComplaint}
        onUpdate={async (id, status, remarks) => {
          await updateComplaintStatus(id, status, remarks);
          success(`Complaint status updated to ${status}`);
        }}
      />
    </div>
  );
};
