import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { AllocationModal } from '../../components/admin/AllocationModal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import type { Student } from '../../types';
import {
  KeyRound,
  ArrowLeftRight,
  UserMinus,
  CheckCircle2,
  Clock,
  Search,
  Bed,
  DoorOpen,
  UserCheck
} from 'lucide-react';

export const AllocationManagement: React.FC = () => {
  const { students, rooms, vacateRoom } = useData();
  const { success, error: toastError } = useToast();

  const [searchTerm, setSearchTerm] = useState('');
  const [allocationModalMode, setAllocationModalMode] = useState<'allocate' | 'change'>('allocate');
  const [showAllocationModal, setShowAllocationModal] = useState(false);
  const [selectedStudentForAction, setSelectedStudentForAction] = useState<Student | null>(null);

  const [vacatingStudent, setVacatingStudent] = useState<Student | null>(null);
  const [isVacating, setIsVacating] = useState(false);

  // Group students
  const allocatedStudents = students.filter(s => s.roomNumber && s.roomNumber !== '');
  const unallocatedStudents = students.filter(s => !s.roomNumber || s.roomNumber === '');

  const filteredAllocated = allocatedStudents.filter(s =>
    s.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.roomNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.course.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleVacateConfirm = async () => {
    if (!vacatingStudent) return;
    setIsVacating(true);
    try {
      await vacateRoom(vacatingStudent.studentId);
      success(`Vacated Room for ${vacatingStudent.fullName}. Bed released back into inventory.`);
      setVacatingStudent(null);
    } catch (err: any) {
      toastError(err.message || 'Failed to vacate room');
    } finally {
      setIsVacating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Room & Bed Allocation Management
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Assign incoming residents to available rooms, handle inter-room transfers, and process checkout vacations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-allocate-student-modal"
            type="button"
            onClick={() => {
              setSelectedStudentForAction(null);
              setAllocationModalMode('allocate');
              setShowAllocationModal(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all active:scale-98"
          >
            <KeyRound className="w-4 h-4" />
            Assign Bed to Student
          </button>
          <button
            id="btn-transfer-student-modal"
            type="button"
            onClick={() => {
              setSelectedStudentForAction(null);
              setAllocationModalMode('change');
              setShowAllocationModal(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs sm:text-sm font-bold shadow-xs transition-all active:scale-98"
          >
            <ArrowLeftRight className="w-4 h-4 text-blue-900" />
            Transfer Room
          </button>
        </div>
      </div>

      {/* Unallocated Waiting Queue Banner */}
      {unallocatedStudents.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wide">
                Waiting List: {unallocatedStudents.length} Students Pending Room Allocation
              </h4>
              <p className="text-xs text-amber-800 mt-0.5">
                {unallocatedStudents.map(s => s.fullName).slice(0, 3).join(', ')}
                {unallocatedStudents.length > 3 ? ` and ${unallocatedStudents.length - 3} more` : ''}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setSelectedStudentForAction(unallocatedStudents[0]);
              setAllocationModalMode('allocate');
              setShowAllocationModal(true);
            }}
            className="px-3.5 py-1.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold shadow-xs shrink-0"
          >
            Allocate Next
          </button>
        </div>
      )}

      {/* Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search allocated students by name, ID, or room..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <span className="text-xs font-semibold text-slate-500 hidden sm:inline">
          Total Assigned: {allocatedStudents.length} / {students.length} students
        </span>
      </div>

      {/* Allocation Table */}
      {filteredAllocated.length > 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Resident Student</th>
                  <th className="p-4">Assigned Room</th>
                  <th className="p-4">Bed Designation</th>
                  <th className="p-4">Academic Details</th>
                  <th className="p-4">Allocation Status</th>
                  <th className="p-4 text-right">Allocation Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAllocated.map((student) => {
                  const room = rooms.find(r => r.roomNumber === student.roomNumber);

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/60">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-blue-900 text-white flex items-center justify-center font-bold text-xs">
                            {student.fullName.charAt(0)}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900">{student.fullName}</p>
                            <p className="text-[11px] text-slate-400">{student.studentId} • {student.phone}</p>
                          </div>
                        </div>
                      </td>

                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-xs text-blue-900 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                            Room {student.roomNumber}
                          </span>
                          {room && (
                            <span className="text-[11px] text-slate-500">
                              {room.type} ({room.block})
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="p-4">
                        <span className="inline-flex items-center gap-1 font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-xs">
                          <Bed className="w-3.5 h-3.5 text-slate-500" />
                          {student.bedNumber || 'Bed 1'}
                        </span>
                      </td>

                      <td className="p-4">
                        <p className="font-medium text-slate-800">{student.course} ({student.year})</p>
                        <p className="text-[11px] text-slate-400">{student.branch}</p>
                      </td>

                      <td className="p-4">
                        <Badge variant="success" size="sm">
                          Occupying Bed
                        </Badge>
                      </td>

                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedStudentForAction(student);
                              setAllocationModalMode('change');
                              setShowAllocationModal(true);
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-[11px]"
                            title="Change Room"
                          >
                            <ArrowLeftRight className="w-3 h-3 text-blue-900" />
                            Transfer
                          </button>
                          <button
                            type="button"
                            onClick={() => setVacatingStudent(student)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold text-[11px]"
                            title="Vacate Bed"
                          >
                            <UserMinus className="w-3 h-3" />
                            Vacate
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <EmptyState
          icon={KeyRound}
          title="No Allocations Found"
          description="There are currently no students matching this criteria."
          actionLabel="Assign Student Room"
          onAction={() => {
            setSelectedStudentForAction(null);
            setAllocationModalMode('allocate');
            setShowAllocationModal(true);
          }}
        />
      )}

      {/* Allocation / Transfer Modal */}
      <AllocationModal
        isOpen={showAllocationModal}
        onClose={() => setShowAllocationModal(false)}
        mode={allocationModalMode}
        preSelectedStudent={selectedStudentForAction}
      />

      {/* Confirm Vacate Dialog */}
      <ConfirmDialog
        isOpen={Boolean(vacatingStudent)}
        onClose={() => setVacatingStudent(null)}
        onConfirm={handleVacateConfirm}
        title="Confirm Room Checkout / Vacating"
        message={`Are you sure you want to vacate Room ${vacatingStudent?.roomNumber} for ${vacatingStudent?.fullName}? The bed capacity will instantly increment, allowing re-allocation.`}
        confirmLabel="Confirm Vacation"
        isLoading={isVacating}
      />
    </div>
  );
};
