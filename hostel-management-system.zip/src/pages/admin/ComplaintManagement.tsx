import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { ComplaintModal } from '../../components/admin/ComplaintModal';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import type { Complaint, ComplaintStatus, ComplaintCategory } from '../../types';
import {
  MessageSquareWarning,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  Wrench,
  UserCheck
} from 'lucide-react';

export const ComplaintManagement: React.FC = () => {
  const { complaints, updateComplaintStatus } = useData();
  const { success } = useToast();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  const filteredComplaints = useMemo(() => {
    return complaints.filter(c => {
      const matchesSearch =
        c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.roomNumber.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === 'All' || c.status === statusFilter;
      const matchesCategory = categoryFilter === 'All' || c.category === categoryFilter;

      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [complaints, searchTerm, statusFilter, categoryFilter]);

  const pendingCount = complaints.filter(c => c.status === 'Pending').length;
  const inProgressCount = complaints.filter(c => c.status === 'In Progress').length;
  const resolvedCount = complaints.filter(c => c.status === 'Resolved').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Hostel Complaints & Maintenance Desk
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Review resident student grievances, assign maintenance technicians, and log repair resolutions.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Pending Triage
            </span>
            <div className="text-2xl font-black text-rose-600 mt-1">
              {pendingCount}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">Awaiting initial inspection</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100">
            <AlertCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Work In Progress
            </span>
            <div className="text-2xl font-black text-amber-600 mt-1">
              {inProgressCount}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">Technicians dispatched</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100">
            <Wrench className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Resolved Tickets
            </span>
            <div className="text-2xl font-black text-emerald-600 mt-1">
              {resolvedCount}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">Repaired & verified</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search tickets by subject, description, student, room..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
            <option value="Closed">Closed</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Categories</option>
            <option value="Plumbing">Plumbing</option>
            <option value="Electrical">Electrical</option>
            <option value="Carpentry">Carpentry</option>
            <option value="Wi-Fi & Network">Wi-Fi & Network</option>
            <option value="Cleanliness">Cleanliness</option>
            <option value="Discipline">Discipline</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      {/* Complaints List Table */}
      {filteredComplaints.length > 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Complaint / Grievance</th>
                  <th className="p-4">Resident & Room</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Priority</th>
                  <th className="p-4">Date Filed</th>
                  <th className="p-4">Resolution Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredComplaints.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/60">
                    <td className="p-4 max-w-xs">
                      <p className="font-bold text-slate-900 text-xs">{c.title}</p>
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{c.description}</p>
                      {c.adminRemarks && (
                        <p className="text-[10px] text-blue-900 mt-1 bg-blue-50/80 px-2 py-0.5 rounded border border-blue-100 inline-block font-medium">
                          Note: {c.adminRemarks}
                        </p>
                      )}
                    </td>

                    <td className="p-4">
                      <p className="font-bold text-slate-900">{c.studentName}</p>
                      <span className="inline-block mt-0.5 text-[10px] font-bold text-blue-900 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">
                        Room {c.roomNumber}
                      </span>
                    </td>

                    <td className="p-4">
                      <span className="font-semibold text-slate-700">{c.category}</span>
                    </td>

                    <td className="p-4">
                      <Badge
                        variant={c.priority === 'Urgent' ? 'danger' : c.priority === 'High' ? 'warning' : 'neutral'}
                        size="sm"
                      >
                        {c.priority}
                      </Badge>
                    </td>

                    <td className="p-4 text-slate-500">
                      {new Date(c.createdAt).toLocaleDateString()}
                    </td>

                    <td className="p-4">
                      <Badge
                        variant={
                          c.status === 'Resolved' ? 'success' : c.status === 'In Progress' ? 'warning' : 'danger'
                        }
                        size="sm"
                      >
                        {c.status}
                      </Badge>
                    </td>

                    <td className="p-4 text-right">
                      <button
                        type="button"
                        onClick={() => setSelectedComplaint(c)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-900 hover:bg-blue-800 text-white font-bold text-[11px] shadow-xs"
                      >
                        Inspect & Resolve
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <EmptyState
          icon={MessageSquareWarning}
          title="No Complaints Found"
          description="All caught up! No maintenance grievances match your current filters."
        />
      )}

      {/* Resolution Modal */}
      <ComplaintModal
        isOpen={Boolean(selectedComplaint)}
        onClose={() => setSelectedComplaint(null)}
        complaint={selectedComplaint}
        onUpdate={async (id, status, remarks) => {
          await updateComplaintStatus(id, status, remarks);
          success(`Ticket status updated to ${status}`);
        }}
      />
    </div>
  );
};
