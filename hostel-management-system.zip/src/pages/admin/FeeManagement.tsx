import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { FeeModal } from '../../components/admin/FeeModal';
import { Modal } from '../../components/common/Modal';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import type { Fee } from '../../types';
import {
  CreditCard,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  Clock,
  Printer,
  FileText,
  DollarSign,
  Download
} from 'lucide-react';

export const FeeManagement: React.FC = () => {
  const { fees, addFee, recordPayment } = useData();
  const { success, error: toastError } = useToast();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  // Modals
  const [showFeeModal, setShowFeeModal] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<Fee | null>(null);
  const [payingFee, setPayingFee] = useState<Fee | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('Online Banking / UPI');
  const [isProcessingPay, setIsProcessingPay] = useState(false);

  // Financial summary metrics
  const totalRevenue = useMemo(() => {
    return fees
      .filter(f => f.status === 'Paid')
      .reduce((acc, curr) => acc + curr.amount, 0);
  }, [fees]);

  const totalOutstanding = useMemo(() => {
    return fees
      .filter(f => f.status === 'Pending' || f.status === 'Overdue')
      .reduce((acc, curr) => acc + curr.amount, 0);
  }, [fees]);

  // Filtered list
  const filteredFees = useMemo(() => {
    return fees.filter(f => {
      const matchesSearch =
        f.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.roomNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.semester.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === 'All' || f.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [fees, searchTerm, statusFilter]);

  const handlePayConfirm = async () => {
    if (!payingFee) return;
    setIsProcessingPay(true);
    try {
      const txnId = `TXN-${Math.floor(10000000 + Math.random() * 90000000)}`;
      await recordPayment(payingFee.id, paymentMethod, txnId);
      success(`Payment recorded for Invoice ${payingFee.invoiceNumber}`);
      setPayingFee(null);
    } catch (err: any) {
      toastError(err.message || 'Payment recording failed');
    } finally {
      setIsProcessingPay(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Fee & Invoice Management
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Track term fees, hostel room charges, payment status, and verify generated payment receipts.
          </p>
        </div>

        <button
          id="btn-issue-invoice"
          type="button"
          onClick={() => setShowFeeModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all active:scale-98"
        >
          <Plus className="w-4 h-4" />
          Issue Fee Invoice
        </button>
      </div>

      {/* Financial KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Collected Payments
            </span>
            <div className="text-2xl font-black text-emerald-700 mt-1">
              Rs. {totalRevenue.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {fees.filter(f => f.status === 'Paid').length} paid invoices
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Outstanding Receivables
            </span>
            <div className="text-2xl font-black text-rose-600 mt-1">
              Rs. {totalOutstanding.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {fees.filter(f => f.status === 'Pending' || f.status === 'Overdue').length} pending collection
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100">
            <AlertCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Total Invoiced
            </span>
            <div className="text-2xl font-black text-slate-900 mt-1">
              Rs. {(totalRevenue + totalOutstanding).toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">{fees.length} total fee invoices</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center border border-blue-100">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by student name, ID, invoice #, room..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <span className="text-xs text-slate-500 font-medium">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Invoices</option>
            <option value="Paid">Paid in Full</option>
            <option value="Pending">Pending Payment</option>
            <option value="Overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {filteredFees.length > 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Invoice #</th>
                  <th className="p-4">Student</th>
                  <th className="p-4">Term / Semester</th>
                  <th className="p-4">Amount</th>
                  <th className="p-4">Due Date</th>
                  <th className="p-4">Payment Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredFees.map((fee) => (
                  <tr key={fee.id} className="hover:bg-slate-50/60">
                    <td className="p-4">
                      <span className="font-mono font-bold text-slate-900 text-xs">{fee.invoiceNumber}</span>
                      <p className="text-[10px] text-slate-400">Room {fee.roomNumber}</p>
                    </td>

                    <td className="p-4">
                      <p className="font-bold text-slate-900">{fee.studentName}</p>
                      <p className="text-[11px] text-slate-400">{fee.studentId}</p>
                    </td>

                    <td className="p-4">
                      <p className="font-medium text-slate-800">{fee.semester}</p>
                    </td>

                    <td className="p-4">
                      <span className="font-extrabold text-sm text-slate-900">Rs. {fee.amount.toLocaleString()}</span>
                    </td>

                    <td className="p-4 text-slate-500">
                      {fee.dueDate}
                    </td>

                    <td className="p-4">
                      <Badge
                        variant={fee.status === 'Paid' ? 'success' : fee.status === 'Pending' ? 'warning' : 'danger'}
                        size="sm"
                      >
                        {fee.status}
                      </Badge>
                      {fee.paymentDate && (
                        <span className="block text-[10px] text-emerald-700 mt-0.5">
                          Paid on {fee.paymentDate}
                        </span>
                      )}
                    </td>

                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {fee.status !== 'Paid' ? (
                          <button
                            type="button"
                            onClick={() => setPayingFee(fee)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-xs"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Record Pay
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setSelectedReceipt(fee)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px]"
                          >
                            <FileText className="w-3.5 h-3.5 text-blue-900" />
                            View Receipt
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <EmptyState
          icon={CreditCard}
          title="No Invoices Found"
          description="No fee records match the selected criteria."
          actionLabel="Create Invoice"
          onAction={() => setShowFeeModal(true)}
        />
      )}

      {/* Record Payment Modal */}
      {payingFee && (
        <Modal
          isOpen={Boolean(payingFee)}
          onClose={() => setPayingFee(null)}
          title={`Record Payment for ${payingFee.studentName}`}
          subtitle={`Invoice: ${payingFee.invoiceNumber} • Amount Due: Rs. ${payingFee.amount.toLocaleString()}`}
          maxWidth="sm"
        >
          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Select Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
              >
                <option value="Online Banking / UPI">Online Banking / UPI</option>
                <option value="Credit / Debit Card">Credit / Debit Card</option>
                <option value="Hostel Accounts Cash Desk">Hostel Accounts Cash Desk</option>
                <option value="Bank Direct Deposit">Bank Direct Deposit</option>
              </select>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-600">
              <p>Amount: <strong>Rs. {payingFee.amount.toLocaleString()}</strong></p>
              <p className="mt-0.5">Term: {payingFee.semester}</p>
              <p className="mt-0.5">Room: {payingFee.roomNumber}</p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPayingFee(null)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-medium"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handlePayConfirm}
                disabled={isProcessingPay}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
              >
                {isProcessingPay ? 'Recording...' : 'Confirm Receipt'}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Receipt Modal */}
      {selectedReceipt && (
        <Modal
          isOpen={Boolean(selectedReceipt)}
          onClose={() => setSelectedReceipt(null)}
          title="Official Hostel Fee Receipt"
          subtitle={`Receipt Reference: ${selectedReceipt.invoiceNumber}`}
          maxWidth="md"
        >
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl space-y-4 text-xs">
            <div className="flex justify-between border-b pb-3">
              <div>
                <h4 className="font-black text-slate-900 text-sm">Hostel Management System</h4>
                <p className="text-slate-500">Student Residence Accounts Division</p>
              </div>
              <div className="text-right">
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold uppercase text-[10px]">
                  PAID IN FULL
                </span>
                <p className="text-[10px] text-slate-400 mt-1">{selectedReceipt.paymentDate}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-slate-700">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Billed To</span>
                <strong className="text-slate-900">{selectedReceipt.studentName}</strong>
                <p className="text-[11px] text-slate-500">ID: {selectedReceipt.studentId}</p>
                <p className="text-[11px] text-slate-500">Room: {selectedReceipt.roomNumber}</p>
              </div>
              <div className="text-right">
                <span className="text-slate-400 block text-[10px] uppercase">Transaction Info</span>
                <p className="font-mono text-[11px] text-slate-800">{selectedReceipt.transactionId || 'TXN-ONLINE-CONFIRMED'}</p>
                <p className="text-[11px] text-slate-500">{selectedReceipt.paymentMethod || 'Online Payment'}</p>
              </div>
            </div>

            <div className="border-t border-b py-2 flex justify-between font-bold text-slate-900">
              <span>{selectedReceipt.semester} Charge</span>
              <span>Rs. {selectedReceipt.amount.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center text-slate-500 text-[11px] pt-1">
              <span>Authorized Signature: Chief Warden</span>
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="inline-flex items-center gap-1 text-blue-900 hover:underline font-bold"
              >
                <Printer className="w-3.5 h-3.5" />
                Print / Save PDF
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Add Fee Modal */}
      <FeeModal
        isOpen={showFeeModal}
        onClose={() => setShowFeeModal(false)}
        onSubmit={async (data) => {
          const id = await addFee(data);
          success('Fee record generated successfully!');
          return id;
        }}
      />
    </div>
  );
};
