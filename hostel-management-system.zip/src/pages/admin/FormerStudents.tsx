import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { useToast } from '../../components/common/Toast';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { StudentDetailModal } from '../../components/admin/StudentDetailModal';
import type { Student } from '../../types';
import { 
  UserX, 
  Search, 
  Filter, 
  Eye, 
  Trash2, 
  RotateCcw, 
  Calendar, 
  DoorClosed, 
  CreditCard, 
  MessageSquareWarning, 
  Mail, 
  Phone,
  ShieldAlert,
  ArrowRight,
  Download,
  AlertOctagon
} from 'lucide-react';

export const FormerStudents: React.FC = () => {
  const { students, fees, complaints, reAdmitStudent, deleteStudentPermanently } = useData();
  const { success, error: toastError } = useToast();

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [reasonFilter, setReasonFilter] = useState('All');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [reAdmittingStudent, setReAdmittingStudent] = useState<Student | null>(null);
  const [permanentlyDeletingStudent, setPermanentlyDeletingStudent] = useState<Student | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // All Former Students (status === 'Left Hostel')
  const formerStudents = useMemo(() => {
    return students.filter(s => s.status === 'Left Hostel');
  }, [students]);

  // Distinct Departure Reasons
  const reasonsList = useMemo(() => {
    const set = new Set<string>();
    formerStudents.forEach(s => {
      if (s.leavingReason) set.add(s.leavingReason);
    });
    return Array.from(set);
  }, [formerStudents]);

  // Filtered List
  const filteredFormerStudents = useMemo(() => {
    return formerStudents.filter(student => {
      const matchesSearch =
        student.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (student.previousRoomNumber && student.previousRoomNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        student.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (student.leavingReason && student.leavingReason.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesReason = reasonFilter === 'All' || student.leavingReason === reasonFilter;

      return matchesSearch && matchesReason;
    });
  }, [formerStudents, searchTerm, reasonFilter]);

  // Aggregate Stats for Former Students
  const formerStats = useMemo(() => {
    const formerIds = new Set(formerStudents.map(s => s.studentId));
    const relatedFees = fees.filter(f => formerIds.has(f.studentId));
    const relatedComplaints = complaints.filter(c => formerIds.has(c.studentId));

    const totalCleared = relatedFees
      .filter(f => f.status === 'Paid')
      .reduce((acc, curr) => acc + curr.amount, 0);

    const totalOutstanding = relatedFees
      .filter(f => f.status === 'Pending' || f.status === 'Overdue')
      .reduce((acc, curr) => acc + curr.amount, 0);

    return {
      count: formerStudents.length,
      totalCleared,
      totalOutstanding,
      totalComplaints: relatedComplaints.length,
      resolvedComplaints: relatedComplaints.filter(c => c.status === 'Resolved').length
    };
  }, [formerStudents, fees, complaints]);

  // Re-admit Student Handler
  const handleReAdmitConfirm = async () => {
    if (!reAdmittingStudent) return;
    setIsProcessing(true);
    try {
      const res = await reAdmitStudent(reAdmittingStudent.id);
      if (res.success) {
        success(`Student ${reAdmittingStudent.fullName} re-admitted to Active Students registry.`);
        setReAdmittingStudent(null);
      } else {
        toastError(res.error || 'Failed to re-admit student');
      }
    } catch (err: any) {
      toastError(err.message || 'Error re-admitting student');
    } finally {
      setIsProcessing(false);
    }
  };

  // Permanent Deletion Handler
  const handlePermanentDeleteConfirm = async () => {
    if (!permanentlyDeletingStudent) return;
    setIsProcessing(true);
    try {
      await deleteStudentPermanently(permanentlyDeletingStudent.id);
      success(`Permanently deleted records for ${permanentlyDeletingStudent.fullName}`);
      setPermanentlyDeletingStudent(null);
    } catch (err: any) {
      toastError(err.message || 'Failed to permanently delete student records');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
              Former & Inactive Students
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200">
              {formerStudents.length} Archived
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Archived student records, historical room tenure, completed ledger statements, and clearance logs.
          </p>
        </div>
      </div>

      {/* Metric Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Former Residents</span>
            <UserX className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">{formerStats.count}</div>
          <p className="text-[11px] text-slate-500 mt-0.5">Vacated from hostel</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Cleared Fees</span>
            <CreditCard className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-700">
            Rs. {formerStats.totalCleared.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Total lifetime fees paid</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Unsettled Dues</span>
            <AlertOctagon className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-rose-600">
            Rs. {formerStats.totalOutstanding.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Pending dues at departure</p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Complaints Logged</span>
            <MessageSquareWarning className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">{formerStats.totalComplaints}</div>
          <p className="text-[11px] text-slate-500 mt-0.5">{formerStats.resolvedComplaints} Resolved historical</p>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            id="former-student-search-input"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by student name, ID, former room, email, reason..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span>Departure Reason:</span>
          </div>
          <select
            value={reasonFilter}
            onChange={(e) => setReasonFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Reasons</option>
            {reasonsList.map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>

          <div className="text-xs text-slate-400 font-semibold ml-auto md:ml-2">
            Showing {filteredFormerStudents.length} of {formerStudents.length}
          </div>
        </div>
      </div>

      {/* Former Students Table */}
      {filteredFormerStudents.length > 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Former Resident</th>
                  <th className="p-4">Tenure & Dates</th>
                  <th className="p-4">Previous Room</th>
                  <th className="p-4">Departure Reason</th>
                  <th className="p-4">Financial Records</th>
                  <th className="p-4">Grievances</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredFormerStudents.map((student) => {
                  const studentFees = fees.filter(f => f.studentId === student.studentId);
                  const unpaidAmount = studentFees
                    .filter(f => f.status === 'Pending' || f.status === 'Overdue')
                    .reduce((acc, curr) => acc + curr.amount, 0);

                  const studentComplaints = complaints.filter(c => c.studentId === student.studentId);

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/60 transition-colors">
                      {/* Student Profile */}
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center font-bold text-xs shrink-0">
                            {student.fullName.charAt(0)}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 text-xs sm:text-sm">
                              {student.fullName}
                            </p>
                            <span className="font-mono text-[11px] text-slate-500">
                              {student.studentId} • {student.course}
                            </span>
                            <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400">
                              <span className="flex items-center gap-1">
                                <Mail className="w-3 h-3 text-slate-300" />
                                {student.email}
                              </span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Tenure & Dates */}
                      <td className="p-4 space-y-1">
                        <div className="flex items-center gap-1 text-[11px] font-medium text-slate-700">
                          <span className="text-slate-400">Joined:</span>
                          <strong>{student.admissionDate || 'N/A'}</strong>
                        </div>
                        <div className="flex items-center gap-1 text-[11px] font-medium text-amber-900">
                          <span className="text-amber-600">Left:</span>
                          <strong>{student.leavingDate || 'Recorded'}</strong>
                        </div>
                      </td>

                      {/* Previous Room */}
                      <td className="p-4">
                        {student.previousRoomNumber ? (
                          <div className="inline-flex flex-col">
                            <span className="inline-flex items-center gap-1 font-bold text-slate-800 bg-slate-100 px-2 py-1 rounded-lg text-xs border border-slate-200">
                              <DoorClosed className="w-3 h-3 text-slate-500" />
                              Room {student.previousRoomNumber}
                            </span>
                            <span className="text-[10px] text-slate-400 mt-0.5 font-medium">
                              {student.previousBedNumber || 'Bed 1'} (Vacated)
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic text-[11px]">Unassigned</span>
                        )}
                      </td>

                      {/* Departure Reason */}
                      <td className="p-4">
                        <div className="max-w-xs">
                          <span className="inline-block px-2 py-0.5 rounded text-[11px] bg-amber-50 text-amber-900 font-semibold border border-amber-200">
                            {student.leavingReason || 'Hostel Departure'}
                          </span>
                        </div>
                      </td>

                      {/* Financial Records */}
                      <td className="p-4">
                        <div className="space-y-0.5">
                          {unpaidAmount > 0 ? (
                            <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                              Dues: Rs. {unpaidAmount.toLocaleString()}
                            </span>
                          ) : (
                            <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              All Fees Cleared
                            </span>
                          )}
                          <p className="text-[10px] text-slate-400 font-medium">
                            {studentFees.length} historical invoice{studentFees.length !== 1 ? 's' : ''}
                          </p>
                        </div>
                      </td>

                      {/* Grievances */}
                      <td className="p-4">
                        <span className="font-semibold text-slate-700">
                          {studentComplaints.length} Logged
                        </span>
                        <p className="text-[10px] text-slate-400">
                          {studentComplaints.filter(c => c.status === 'Resolved').length} resolved
                        </p>
                      </td>

                      {/* Actions */}
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            id={`view-former-${student.studentId}`}
                            type="button"
                            onClick={() => setSelectedStudent(student)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-blue-900 hover:bg-slate-100 transition-colors"
                            title="View Complete Historical Dossier"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            id={`readmit-${student.studentId}`}
                            type="button"
                            onClick={() => setReAdmittingStudent(student)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                            title="Re-admit Student to Active Registry"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>

                          <button
                            id={`delete-permanent-${student.studentId}`}
                            type="button"
                            onClick={() => setPermanentlyDeletingStudent(student)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Permanently Delete All Records"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <EmptyState
          icon={UserX}
          title="No Former Students Found"
          description={
            searchTerm || reasonFilter !== 'All'
              ? `No former student records matching "${searchTerm}". Try resetting search filter.`
              : 'When residents leave the hostel, their historical records, room tenure, fees, and complaints are preserved here.'
          }
        />
      )}

      {/* Student Dossier Modal */}
      <StudentDetailModal
        isOpen={Boolean(selectedStudent)}
        onClose={() => setSelectedStudent(null)}
        student={selectedStudent}
        onReAdmit={() => {
          setSelectedStudent(null);
        }}
      />

      {/* Re-admit Confirmation Dialog */}
      <ConfirmDialog
        isOpen={Boolean(reAdmittingStudent)}
        onClose={() => setReAdmittingStudent(null)}
        onConfirm={handleReAdmitConfirm}
        title="Re-admit Student as Active Resident"
        message={`Are you sure you want to restore ${reAdmittingStudent?.fullName} (${reAdmittingStudent?.studentId}) back to the Active Students list? You can allocate a new room bed afterwards.`}
        confirmLabel="Confirm Re-admission"
        isLoading={isProcessing}
      />

      {/* Permanent Deletion Dialog */}
      <ConfirmDialog
        isOpen={Boolean(permanentlyDeletingStudent)}
        onClose={() => setPermanentlyDeletingStudent(null)}
        onConfirm={handlePermanentDeleteConfirm}
        title="Permanently Delete Student Records"
        message={`WARNING: This will permanently delete ALL data for ${permanentlyDeletingStudent?.fullName} (${permanentlyDeletingStudent?.studentId}) including their contact dossier and historical records. This action cannot be undone.`}
        confirmLabel="Permanently Delete"
        isLoading={isProcessing}
      />
    </div>
  );
};
