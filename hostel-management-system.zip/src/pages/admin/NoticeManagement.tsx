import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { NoticeModal } from '../../components/admin/NoticeModal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import type { Notice } from '../../types';
import {
  Megaphone,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  Calendar,
  Building,
  AlertTriangle
} from 'lucide-react';

export const NoticeManagement: React.FC = () => {
  const { notices, createNotice, updateNotice, deleteNotice } = useData();
  const { success, error: toastError } = useToast();

  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingNotice, setEditingNotice] = useState<Notice | null>(null);
  const [deletingNotice, setDeletingNotice] = useState<Notice | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const filteredNotices = useMemo(() => {
    return notices.filter(n => {
      const matchesSearch =
        n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        n.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        n.publishedBy.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCategory = categoryFilter === 'All' || n.category === categoryFilter;
      const matchesPriority = priorityFilter === 'All' || n.priority === priorityFilter;

      return matchesSearch && matchesCategory && matchesPriority;
    });
  }, [notices, searchTerm, categoryFilter, priorityFilter]);

  const handleDeleteConfirm = async () => {
    if (!deletingNotice) return;
    setIsDeleting(true);
    try {
      await deleteNotice(deletingNotice.id);
      success('Notice deleted successfully');
      setDeletingNotice(null);
    } catch (err: any) {
      toastError(err.message || 'Failed to delete notice');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Hostel Circulars & Notice Broadcasts
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Publish official announcements, maintenance schedules, mess menus, and hostel rule updates.
          </p>
        </div>

        <button
          id="btn-broadcast-notice"
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all active:scale-98"
        >
          <Plus className="w-4 h-4" />
          Broadcast New Notice
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search notice titles, content, authority..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Priorities</option>
            <option value="Urgent">Urgent Only</option>
            <option value="Important">Important</option>
            <option value="Normal">Normal</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Categories</option>
            <option value="General">General</option>
            <option value="Maintenance">Maintenance</option>
            <option value="Mess & Dining">Mess & Dining</option>
            <option value="Rules & Discipline">Rules & Discipline</option>
            <option value="Holiday / Leave">Holiday / Leave</option>
          </select>
        </div>
      </div>

      {/* Notice Cards Grid */}
      {filteredNotices.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredNotices.map((notice) => (
            <div
              key={notice.id}
              className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <Badge
                    variant={
                      notice.priority === 'Urgent'
                        ? 'danger'
                        : notice.priority === 'Important'
                        ? 'warning'
                        : 'primary'
                    }
                    size="sm"
                  >
                    {notice.priority} Alert
                  </Badge>

                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(notice.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 mb-2 leading-snug">
                  {notice.title}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line mb-4">
                  {notice.content}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block">ISSUED BY</span>
                  <span className="font-semibold text-slate-700 text-[11px]">{notice.publishedBy}</span>
                  <span className="text-[10px] text-blue-900 bg-blue-50 px-1.5 py-0.5 rounded ml-1 font-medium">
                    {notice.category} • {notice.targetAudience}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setEditingNotice(notice)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                    title="Edit Notice"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeletingNotice(notice)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Delete Notice"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Megaphone}
          title="No Notices Found"
          description="No published circulars match your current filter settings."
          actionLabel="Create Announcement"
          onAction={() => setShowAddModal(true)}
        />
      )}

      {/* Modals */}
      <NoticeModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={async (data) => {
          await createNotice(data);
          success('Notice broadcasted successfully!');
        }}
      />

      <NoticeModal
        isOpen={Boolean(editingNotice)}
        onClose={() => setEditingNotice(null)}
        initialData={editingNotice}
        onSubmit={async (data) => {
          if (editingNotice) {
            await updateNotice(editingNotice.id, data);
            success('Notice updated successfully!');
            setEditingNotice(null);
          }
        }}
      />

      <ConfirmDialog
        isOpen={Boolean(deletingNotice)}
        onClose={() => setDeletingNotice(null)}
        onConfirm={handleDeleteConfirm}
        title="Delete Announcement"
        message={`Are you sure you want to delete notice "${deletingNotice?.title}"? It will no longer be visible on student portals.`}
        confirmLabel="Delete Notice"
        isLoading={isDeleting}
      />
    </div>
  );
};
