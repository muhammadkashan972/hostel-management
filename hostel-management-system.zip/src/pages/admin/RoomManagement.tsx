import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { RoomModal } from '../../components/admin/RoomModal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import type { Room, RoomStatus } from '../../types';
import {
  DoorOpen,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  Users,
  Wifi,
  Sparkles,
  Bed,
  CheckCircle2,
  AlertTriangle,
  Layers,
  LayoutGrid,
  List
} from 'lucide-react';

export const RoomManagement: React.FC = () => {
  const { rooms, students, addRoom, updateRoom, deleteRoom } = useData();
  const { success, error: toastError } = useToast();

  const [searchTerm, setSearchTerm] = useState('');
  const [blockFilter, setBlockFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Modal states
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [deletingRoom, setDeletingRoom] = useState<Room | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Filtered rooms
  const filteredRooms = useMemo(() => {
    return rooms.filter(room => {
      const matchesSearch =
        room.roomNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        room.block.toLowerCase().includes(searchTerm.toLowerCase()) ||
        room.floor.toLowerCase().includes(searchTerm.toLowerCase()) ||
        room.type.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesBlock = blockFilter === 'All' || room.block === blockFilter;
      const matchesStatus = statusFilter === 'All' || room.status === statusFilter;

      return matchesSearch && matchesBlock && matchesStatus;
    });
  }, [rooms, searchTerm, blockFilter, statusFilter]);

  const handleDeleteConfirm = async () => {
    if (!deletingRoom) return;
    setIsDeleting(true);
    try {
      await deleteRoom(deletingRoom.id);
      success(`Room ${deletingRoom.roomNumber} deleted successfully`);
      setDeletingRoom(null);
    } catch (err: any) {
      toastError(err.message || 'Failed to delete room');
    } finally {
      setIsDeleting(false);
    }
  };

  const getOccupantsForRoom = (roomNumber: string) => {
    return students.filter(s => s.roomNumber === roomNumber);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Room & Inventory Management
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Define hostel wings, room types, bed capacities, semester fees, and maintenance status.
          </p>
        </div>

        <button
          id="btn-add-new-room"
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all active:scale-98"
        >
          <Plus className="w-4 h-4" />
          Add New Room
        </button>
      </div>

      {/* Filter and View Toggle Controls */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-xs">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search room # or block..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <select
            value={blockFilter}
            onChange={(e) => setBlockFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Blocks</option>
            <option value="Block A (Sunrise)">Block A (Sunrise)</option>
            <option value="Block B (Harmony)">Block B (Harmony)</option>
            <option value="Block C (Scholars)">Block C (Scholars)</option>
            <option value="Block D (Executive)">Block D (Executive)</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Operational Statuses</option>
            <option value="Available">Available for Allocation</option>
            <option value="Full">Full Occupancy</option>
            <option value="Maintenance">Under Maintenance</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex p-1 bg-slate-100 rounded-xl border border-slate-200 ml-auto md:ml-2">
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-white shadow-xs text-blue-900' : 'text-slate-500'}`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-colors ${viewMode === 'table' ? 'bg-white shadow-xs text-blue-900' : 'text-slate-500'}`}
              title="Table View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Room Display */}
      {filteredRooms.length > 0 ? (
        viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredRooms.map(room => {
              const occupants = getOccupantsForRoom(room.roomNumber);
              const isFull = room.availableBeds === 0;

              return (
                <div
                  key={room.id}
                  className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Room Header */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-bold text-slate-900">Room {room.roomNumber}</h3>
                          <Badge
                            variant={
                              room.status === 'Available'
                                ? 'success'
                                : room.status === 'Full'
                                ? 'neutral'
                                : 'warning'
                            }
                            size="sm"
                          >
                            {room.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-500 font-medium mt-0.5">
                          {room.block} • {room.floor}
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="text-sm font-extrabold text-blue-900">Rs. {room.feePerSemester.toLocaleString()}</span>
                        <span className="text-[10px] text-slate-400 block">/ semester</span>
                      </div>
                    </div>

                    {/* Bed Capacity Bar */}
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 mb-3 space-y-1.5">
                      <div className="flex justify-between text-xs font-semibold">
                        <span className="text-slate-700 flex items-center gap-1.5">
                          <Bed className="w-3.5 h-3.5 text-blue-900" />
                          {room.type} Room
                        </span>
                        <span className={room.availableBeds > 0 ? 'text-emerald-600 font-bold' : 'text-slate-500'}>
                          {room.availableBeds} of {room.capacity} beds vacant
                        </span>
                      </div>

                      {/* Visual bed slot dots */}
                      <div className="grid grid-cols-4 gap-1.5 pt-1">
                        {Array.from({ length: room.capacity }).map((_, idx) => {
                          const isOccupied = idx < room.currentOccupants;
                          return (
                            <div
                              key={idx}
                              className={`py-1 text-center rounded text-[10px] font-bold ${
                                isOccupied
                                  ? 'bg-blue-900 text-white'
                                  : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              }`}
                            >
                              Bed {idx + 1}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Occupants list preview */}
                    {occupants.length > 0 && (
                      <div className="mb-3">
                        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-1">
                          Current Occupants ({occupants.length})
                        </span>
                        <div className="space-y-1 text-xs">
                          {occupants.map(stu => (
                            <div key={stu.id} className="flex items-center justify-between text-slate-700 py-0.5">
                              <span className="truncate">{stu.fullName}</span>
                              <span className="text-[10px] text-slate-400 font-mono">{stu.bedNumber}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Amenities tags */}
                    <div className="flex flex-wrap gap-1 mb-4">
                      {room.amenities.map(a => (
                        <span
                          key={a}
                          className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-medium"
                        >
                          {a}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => {
                        const newStatus: RoomStatus = room.status === 'Maintenance' ? 'Available' : 'Maintenance';
                        updateRoom(room.id, { status: newStatus });
                        success(`Room ${room.roomNumber} status toggled to ${newStatus}`);
                      }}
                      className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 underline"
                    >
                      {room.status === 'Maintenance' ? 'Restore Active' : 'Set Maintenance'}
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setEditingRoom(room)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                        title="Edit Room Details"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeletingRoom(room)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        title="Delete Room"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="p-4">Room #</th>
                    <th className="p-4">Location / Wing</th>
                    <th className="p-4">Type & Capacity</th>
                    <th className="p-4">Occupancy</th>
                    <th className="p-4">Fee / Semester</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredRooms.map(room => (
                    <tr key={room.id} className="hover:bg-slate-50/60">
                      <td className="p-4 font-bold text-slate-900 text-sm">Room {room.roomNumber}</td>
                      <td className="p-4">
                        <p className="font-semibold text-slate-800">{room.block}</p>
                        <p className="text-slate-400 text-[11px]">{room.floor}</p>
                      </td>
                      <td className="p-4">
                        <p className="font-semibold text-slate-800">{room.type}</p>
                        <p className="text-slate-400 text-[11px]">{room.capacity} Bed Capacity</p>
                      </td>
                      <td className="p-4">
                        <span className="font-bold text-slate-900">{room.currentOccupants}</span> / {room.capacity} filled
                        <span className="block text-[11px] text-emerald-600 font-medium">
                          {room.availableBeds} beds available
                        </span>
                      </td>
                      <td className="p-4 font-bold text-slate-900">Rs. {room.feePerSemester.toLocaleString()}</td>
                      <td className="p-4">
                        <Badge
                          variant={room.status === 'Available' ? 'success' : room.status === 'Full' ? 'neutral' : 'warning'}
                          size="sm"
                        >
                          {room.status}
                        </Badge>
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setEditingRoom(room)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeletingRoom(room)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      ) : (
        <EmptyState
          icon={DoorOpen}
          title="No Rooms Found"
          description="No rooms match your filter criteria or none have been added yet."
          actionLabel="Create Room"
          onAction={() => setShowAddModal(true)}
        />
      )}

      {/* Modals */}
      <RoomModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={async (data) => {
          await addRoom(data);
          success(`Room ${data.roomNumber} added!`);
        }}
      />

      <RoomModal
        isOpen={Boolean(editingRoom)}
        onClose={() => setEditingRoom(null)}
        initialData={editingRoom}
        onSubmit={async (data) => {
          if (editingRoom) {
            await updateRoom(editingRoom.id, data);
            success(`Room ${data.roomNumber} updated!`);
            setEditingRoom(null);
          }
        }}
      />

      <ConfirmDialog
        isOpen={Boolean(deletingRoom)}
        onClose={() => setDeletingRoom(null)}
        onConfirm={handleDeleteConfirm}
        title="Delete Hostel Room"
        message={`Are you sure you want to remove Room ${deletingRoom?.roomNumber}? Any currently assigned students will have their room unallocated.`}
        confirmLabel="Delete Room"
        isLoading={isDeleting}
      />
    </div>
  );
};
