import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../components/common/Toast';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { DEFAULT_HOSTEL_SETTINGS } from '../../data/initialMockData';
import {
  Building2,
  Palette,
  Clock,
  Wifi,
  RotateCcw,
  Save,
  Phone,
  Database,
  Check,
  ShieldAlert,
  ShieldCheck,
  Eye,
  Sparkles,
  Bed,
  Layers,
  HelpCircle,
  ExternalLink
} from 'lucide-react';

const COLOR_PRESETS = [
  { name: 'Classic Navy', hex: '#1e3a8a' },
  { name: 'Royal Indigo', hex: '#4338ca' },
  { name: 'Deep Slate', hex: '#0f172a' },
  { name: 'Forest Emerald', hex: '#065f46' },
  { name: 'Dark Teal', hex: '#115e59' },
  { name: 'Crimson Wine', hex: '#991b1b' },
  { name: 'Royal Purple', hex: '#581c87' },
  { name: 'Burnt Amber', hex: '#b45309' },
];

export const SettingsPage: React.FC = () => {
  const { hostelSettings, updateHostelSettings, resetHostelSettingsToDefault, resetToMockData } = useData();
  const { role, isFirebaseMode } = useAuth();
  const { success } = useToast();

  const isAdmin = role === 'admin';

  // Local form state initialized from active hostelSettings
  const [hostelName, setHostelName] = useState(hostelSettings?.hostelName || DEFAULT_HOSTEL_SETTINGS.hostelName);
  const [primaryColor, setPrimaryColor] = useState(hostelSettings?.primaryColor || DEFAULT_HOSTEL_SETTINGS.primaryColor);
  const [curfewTime, setCurfewTime] = useState(hostelSettings?.curfewTime || DEFAULT_HOSTEL_SETTINGS.curfewTime);
  const [gateOpenTime, setGateOpenTime] = useState(hostelSettings?.gateOpenTime || DEFAULT_HOSTEL_SETTINGS.gateOpenTime);
  const [messBreakfast, setMessBreakfast] = useState(hostelSettings?.messBreakfast || DEFAULT_HOSTEL_SETTINGS.messBreakfast);
  const [messDinner, setMessDinner] = useState(hostelSettings?.messDinner || DEFAULT_HOSTEL_SETTINGS.messDinner);
  const [wifiNetwork, setWifiNetwork] = useState(hostelSettings?.wifiNetwork || DEFAULT_HOSTEL_SETTINGS.wifiNetwork);
  const [emergencyHotline, setEmergencyHotline] = useState(hostelSettings?.emergencyHotline || DEFAULT_HOSTEL_SETTINGS.emergencyHotline);

  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showDefaultsConfirm, setShowDefaultsConfirm] = useState(false);
  const [saving, setSaving] = useState(false);

  // Keep form in sync if global settings change from cloud or storage
  useEffect(() => {
    if (hostelSettings) {
      setHostelName(hostelSettings.hostelName || DEFAULT_HOSTEL_SETTINGS.hostelName);
      setPrimaryColor(hostelSettings.primaryColor || DEFAULT_HOSTEL_SETTINGS.primaryColor);
      setCurfewTime(hostelSettings.curfewTime || DEFAULT_HOSTEL_SETTINGS.curfewTime);
      setGateOpenTime(hostelSettings.gateOpenTime || DEFAULT_HOSTEL_SETTINGS.gateOpenTime);
      setMessBreakfast(hostelSettings.messBreakfast || DEFAULT_HOSTEL_SETTINGS.messBreakfast);
      setMessDinner(hostelSettings.messDinner || DEFAULT_HOSTEL_SETTINGS.messDinner);
      setWifiNetwork(hostelSettings.wifiNetwork || DEFAULT_HOSTEL_SETTINGS.wifiNetwork);
      setEmergencyHotline(hostelSettings.emergencyHotline || DEFAULT_HOSTEL_SETTINGS.emergencyHotline);
    }
  }, [hostelSettings]);

  // Handle Saving to Firebase Cloud and Local Persistence
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;

    setSaving(true);
    try {
      await updateHostelSettings({
        hostelName: hostelName.trim() || DEFAULT_HOSTEL_SETTINGS.hostelName,
        primaryColor,
        curfewTime,
        gateOpenTime,
        messBreakfast,
        messDinner,
        wifiNetwork,
        emergencyHotline,
      });
      success(
        isFirebaseMode
          ? 'Hostel branding & policies saved to Firebase Cloud and local storage!'
          : 'Hostel branding & policies saved successfully to storage!'
      );
    } catch (err) {
      console.error('Failed to save settings:', err);
    } finally {
      setSaving(false);
    }
  };

  // Restore Default Values
  const handleRestoreDefaults = async () => {
    if (!isAdmin) return;
    setHostelName(DEFAULT_HOSTEL_SETTINGS.hostelName);
    setPrimaryColor(DEFAULT_HOSTEL_SETTINGS.primaryColor);
    setCurfewTime(DEFAULT_HOSTEL_SETTINGS.curfewTime);
    setGateOpenTime(DEFAULT_HOSTEL_SETTINGS.gateOpenTime);
    setMessBreakfast(DEFAULT_HOSTEL_SETTINGS.messBreakfast);
    setMessDinner(DEFAULT_HOSTEL_SETTINGS.messDinner);
    setWifiNetwork(DEFAULT_HOSTEL_SETTINGS.wifiNetwork);
    setEmergencyHotline(DEFAULT_HOSTEL_SETTINGS.emergencyHotline);

    await resetHostelSettingsToDefault();
    setShowDefaultsConfirm(false);
    success('Hostel name, primary color, and policies restored to default values!');
  };

  const handleResetData = () => {
    if (!isAdmin) return;
    resetToMockData();
    setShowResetConfirm(false);
    success('Database reset to fresh factory mock records!');
  };

  return (
    <div className="space-y-6 max-w-5xl pb-10">
      {/* Top Header & Role Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200/80">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Building2 className="w-6 h-6" style={{ color: primaryColor }} />
            Hostel System Settings & Branding
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Configure residence branding, theme primary color, operating curfew rules, and database parameters.
          </p>
        </div>

        <div>
          {isAdmin ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5" />
              Administrator: Full Edit Access
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              <Eye className="w-3.5 h-3.5" />
              Student: View-Only Mode
            </span>
          )}
        </div>
      </div>

      {/* Role Permission Notice for Students */}
      {!isAdmin && (
        <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 flex items-start gap-3 text-xs text-amber-900 shadow-xs">
          <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">Student View-Only Mode</p>
            <p className="text-amber-800 leading-relaxed">
              You are signed in as a resident student. Only hostel administrators have permission to edit the hostel name,
              branding color palette, and facility policies. You can view the live configuration and policies below.
            </p>
          </div>
        </div>
      )}

      {/* SECTION 1: Hostel Identity & Visual Branding (with Live Preview) */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div 
              className="w-8 h-8 rounded-lg flex items-center justify-center text-white shadow-xs"
              style={{ backgroundColor: primaryColor }}
            >
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Hostel Identity & Visual Branding</h3>
              <p className="text-[11px] text-slate-500">
                Custom entity name and primary accent color reflected across headers, sidebars, and badges.
              </p>
            </div>
          </div>

          {isAdmin && (
            <button
              type="button"
              onClick={() => setShowDefaultsConfirm(true)}
              className="text-xs text-slate-500 hover:text-slate-900 font-semibold inline-flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Restore Default Branding
            </button>
          )}
        </div>

        <form onSubmit={handleSaveSettings} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Form Controls (7 cols) */}
            <div className="lg:col-span-7 space-y-5">
              {/* Hostel Name Option */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center justify-between">
                  <span>Hostel Name</span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    {isAdmin ? 'Updates live in sidebar & headers' : 'Official Registered Name'}
                  </span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={hostelName}
                    onChange={(e) => setHostelName(e.target.value)}
                    disabled={!isAdmin}
                    placeholder="e.g. HostelSphere University Residences"
                    className={`w-full pl-9 pr-3 py-2.5 text-xs font-medium rounded-xl border transition-all ${
                      isAdmin
                        ? 'border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900 focus:border-transparent bg-white'
                        : 'border-slate-200 bg-slate-50 text-slate-700 cursor-not-allowed'
                    }`}
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Default: <span className="font-semibold">{DEFAULT_HOSTEL_SETTINGS.hostelName}</span>
                </p>
              </div>

              {/* Primary Color Picker */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center justify-between">
                  <span>Primary Theme Color</span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    {isAdmin ? 'Choose a preset or pick custom hex' : 'Active Brand Palette'}
                  </span>
                </label>

                {/* Preset Color Swatches */}
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 mb-3">
                  {COLOR_PRESETS.map((preset) => {
                    const isSelected = primaryColor.toLowerCase() === preset.hex.toLowerCase();
                    return (
                      <button
                        key={preset.hex}
                        type="button"
                        onClick={() => isAdmin && setPrimaryColor(preset.hex)}
                        disabled={!isAdmin}
                        title={`${preset.name} (${preset.hex})`}
                        className={`group relative flex flex-col items-center p-1.5 rounded-xl border transition-all ${
                          isSelected
                            ? 'border-slate-900 ring-2 ring-slate-900/20 bg-slate-50'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        } ${!isAdmin ? 'cursor-not-allowed opacity-80' : 'cursor-pointer'}`}
                      >
                        <span
                          className="w-6 h-6 rounded-lg flex items-center justify-center shadow-xs transition-transform group-hover:scale-105"
                          style={{ backgroundColor: preset.hex }}
                        >
                          {isSelected && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                        </span>
                        <span className="text-[9px] font-medium text-slate-600 truncate w-full text-center mt-1">
                          {preset.name.split(' ')[0]}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Custom Color Input and Hex Display */}
                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={primaryColor}
                      onChange={(e) => setPrimaryColor(e.target.value)}
                      disabled={!isAdmin}
                      className={`w-9 h-9 rounded-lg border border-slate-300 p-0.5 shadow-xs ${
                        isAdmin ? 'cursor-pointer' : 'cursor-not-allowed opacity-70'
                      }`}
                      title="Click to open color palette"
                    />
                    <div className="text-left">
                      <span className="text-[10px] font-bold text-slate-500 block uppercase tracking-wider">
                        Custom Hex
                      </span>
                      <input
                        type="text"
                        value={primaryColor}
                        onChange={(e) => setPrimaryColor(e.target.value)}
                        disabled={!isAdmin}
                        className={`w-24 px-2 py-0.5 text-xs font-mono font-bold rounded border uppercase ${
                          isAdmin
                            ? 'border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-blue-900 bg-white'
                            : 'border-slate-200 bg-slate-100 cursor-not-allowed text-slate-700'
                        }`}
                        placeholder="#1e3a8a"
                      />
                    </div>
                  </div>

                  <div className="h-8 w-px bg-slate-200" />

                  <div className="flex-1 text-right">
                    <span className="text-[10px] text-slate-500 block font-medium">Default Color</span>
                    <span className="text-xs font-mono font-bold text-slate-800">{DEFAULT_HOSTEL_SETTINGS.primaryColor} (Navy)</span>
                  </div>
                </div>
              </div>

              {/* Operating Curfew & Mess Policies */}
              <div className="pt-2 border-t border-slate-100 space-y-4">
                <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-600" />
                  Campus Timings & Access Policies
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Night Gate Curfew</label>
                    <input
                      type="text"
                      value={curfewTime}
                      onChange={(e) => setCurfewTime(e.target.value)}
                      disabled={!isAdmin}
                      className={`w-full px-3 py-2 text-xs rounded-xl border ${
                        isAdmin
                          ? 'border-slate-200 focus:ring-2 focus:ring-blue-900 bg-white'
                          : 'border-slate-200 bg-slate-50 text-slate-700 cursor-not-allowed'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Morning Gate Opening</label>
                    <input
                      type="text"
                      value={gateOpenTime}
                      onChange={(e) => setGateOpenTime(e.target.value)}
                      disabled={!isAdmin}
                      className={`w-full px-3 py-2 text-xs rounded-xl border ${
                        isAdmin
                          ? 'border-slate-200 focus:ring-2 focus:ring-blue-900 bg-white'
                          : 'border-slate-200 bg-slate-50 text-slate-700 cursor-not-allowed'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Mess Breakfast Hours</label>
                    <input
                      type="text"
                      value={messBreakfast}
                      onChange={(e) => setMessBreakfast(e.target.value)}
                      disabled={!isAdmin}
                      className={`w-full px-3 py-2 text-xs rounded-xl border ${
                        isAdmin
                          ? 'border-slate-200 focus:ring-2 focus:ring-blue-900 bg-white'
                          : 'border-slate-200 bg-slate-50 text-slate-700 cursor-not-allowed'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Mess Dinner Hours</label>
                    <input
                      type="text"
                      value={messDinner}
                      onChange={(e) => setMessDinner(e.target.value)}
                      disabled={!isAdmin}
                      className={`w-full px-3 py-2 text-xs rounded-xl border ${
                        isAdmin
                          ? 'border-slate-200 focus:ring-2 focus:ring-blue-900 bg-white'
                          : 'border-slate-200 bg-slate-50 text-slate-700 cursor-not-allowed'
                      }`}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Resident Wi-Fi Network</label>
                    <input
                      type="text"
                      value={wifiNetwork}
                      onChange={(e) => setWifiNetwork(e.target.value)}
                      disabled={!isAdmin}
                      className={`w-full px-3 py-2 text-xs rounded-xl border ${
                        isAdmin
                          ? 'border-slate-200 focus:ring-2 focus:ring-blue-900 bg-white'
                          : 'border-slate-200 bg-slate-50 text-slate-700 cursor-not-allowed'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Emergency Security Hotline</label>
                    <input
                      type="text"
                      value={emergencyHotline}
                      onChange={(e) => setEmergencyHotline(e.target.value)}
                      disabled={!isAdmin}
                      className={`w-full px-3 py-2 text-xs rounded-xl border ${
                        isAdmin
                          ? 'border-slate-200 focus:ring-2 focus:ring-blue-900 bg-white'
                          : 'border-slate-200 bg-slate-50 text-slate-700 cursor-not-allowed'
                      }`}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Interactive LIVE PREVIEW Card (5 cols) */}
            <div className="lg:col-span-5 flex flex-col">
              <div className="sticky top-20 p-4 rounded-2xl bg-slate-900 text-white shadow-lg space-y-4 border border-slate-800">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Live Preview</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Real-time Sync
                  </span>
                </div>

                {/* Mini Mockup 1: Top Brand Bar */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Sidebar / Brand Header
                  </span>
                  <div className="flex items-center gap-2.5">
                    <div 
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-md shrink-0 transition-colors"
                      style={{ backgroundColor: primaryColor }}
                    >
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-xs font-bold text-white truncate" title={hostelName || 'HostelSphere'}>
                        {hostelName || 'HostelSphere Residences'}
                      </p>
                      <p className="text-[10px] text-slate-400 uppercase tracking-wider">
                        Management System
                      </p>
                    </div>
                  </div>
                </div>

                {/* Mini Mockup 2: UI Buttons & Badges */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Component Theming Preview
                  </span>

                  <div className="flex flex-wrap items-center gap-2">
                    {/* Primary Button */}
                    <button
                      type="button"
                      tabIndex={-1}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold text-white shadow-sm transition-all flex items-center gap-1.5"
                      style={{ backgroundColor: primaryColor }}
                    >
                      <Check className="w-3 h-3" />
                      Primary Button
                    </button>

                    {/* Outlined Button */}
                    <button
                      type="button"
                      tabIndex={-1}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold border transition-all"
                      style={{ borderColor: primaryColor, color: primaryColor }}
                    >
                      Outline Action
                    </button>
                  </div>

                  {/* Badges / Chips */}
                  <div className="flex items-center gap-2 pt-1">
                    <span 
                      className="px-2.5 py-0.5 rounded-full text-[10px] font-bold"
                      style={{ 
                        backgroundColor: `${primaryColor}30`, 
                        color: '#93c5fd',
                        border: `1px solid ${primaryColor}60`
                      }}
                    >
                      Active Resident
                    </span>
                    <span 
                      className="px-2.5 py-0.5 rounded-full text-[10px] font-bold"
                      style={{ 
                        backgroundColor: `${primaryColor}20`, 
                        color: '#cbd5e1'
                      }}
                    >
                      Hostel Allocation
                    </span>
                  </div>
                </div>

                {/* Mini Mockup 3: Sample Student Room Info */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Sample Room Tile</span>
                    <span className="text-[10px] font-bold" style={{ color: primaryColor === '#0f172a' ? '#93c5fd' : primaryColor }}>
                      Occupied (2/2)
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-200">
                    <Bed className="w-4 h-4 text-slate-400" />
                    <span className="font-bold">Room A-101 • Deluxe Double</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: '100%', backgroundColor: primaryColor }} />
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 leading-relaxed italic">
                  {isAdmin 
                    ? 'Preview updates instantly. Click "Save Parameters" to sync across all student & admin sessions.' 
                    : 'This live preview shows the active styling chosen by your hostel warden.'}
                </p>
              </div>
            </div>
          </div>

          {/* Form Actions (Only for Admin) */}
          {isAdmin ? (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-100">
              <div className="text-[11px] text-slate-500">
                {isFirebaseMode ? (
                  <span className="text-emerald-700 font-medium flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    Saves directly to Firebase Firestore & local persistence
                  </span>
                ) : (
                  <span className="text-blue-900 font-medium">
                    Saves to browser persistent storage with instant live reactivity
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setShowDefaultsConfirm(true)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 text-xs font-bold transition-colors"
                >
                  Reset Defaults
                </button>

                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl text-white text-xs font-bold shadow-md transition-all hover:opacity-90 disabled:opacity-50"
                  style={{ backgroundColor: primaryColor }}
                >
                  <Save className="w-4 h-4" />
                  {saving ? 'Saving to Cloud...' : 'Save Parameters'}
                </button>
              </div>
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-slate-100 text-slate-500 text-xs text-center font-medium">
              Editing is locked for students. Contact your Hostel Administrator or Chief Warden for branding or curfew adjustments.
            </div>
          )}
        </form>
      </div>

      {/* SECTION 2: Database State & Maintenance (Admin Only for Factory Reset) */}
      {isAdmin && (
        <div className="p-6 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Database className="w-4 h-4 text-blue-900" />
            <h3 className="text-sm font-bold text-slate-900">Database State & Factory Reset</h3>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
            <p className="font-semibold text-slate-800">
              Active Environment:{' '}
              <span className="text-blue-900 font-bold">
                {isFirebaseMode ? 'Live Firebase Cloud' : 'Local Storage Mode'}
              </span>
            </p>
            <p className="text-slate-500">
              All student records, rooms, fees, visitor logs, and maintenance complaints are preserved safely across sessions.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-1">
            <div>
              <h4 className="text-xs font-bold text-slate-900">Reset Demo Data</h4>
              <p className="text-xs text-slate-500">
                Reload factory pre-seeded students, rooms, invoices, and visitor logs.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 text-xs font-bold transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Demo Records
            </button>
          </div>
        </div>
      )}

      {/* Confirm Dialog: Reset Demo Data */}
      <ConfirmDialog
        isOpen={showResetConfirm}
        onClose={() => setShowResetConfirm(false)}
        onConfirm={handleResetData}
        title="Reset to Factory Mock Records?"
        message="This will re-initialize your database with default sample students, rooms, complaints, notices, and fee invoices. Any newly typed records will be replaced."
        confirmLabel="Reset Everything"
      />

      {/* Confirm Dialog: Restore Default Branding Values */}
      <ConfirmDialog
        isOpen={showDefaultsConfirm}
        onClose={() => setShowDefaultsConfirm(false)}
        onConfirm={handleRestoreDefaults}
        title="Restore Default Branding Values?"
        message={`This will reset the Hostel Name to "${DEFAULT_HOSTEL_SETTINGS.hostelName}" and the primary color to ${DEFAULT_HOSTEL_SETTINGS.primaryColor} (Navy Blue).`}
        confirmLabel="Restore Defaults"
      />
    </div>
  );
};
