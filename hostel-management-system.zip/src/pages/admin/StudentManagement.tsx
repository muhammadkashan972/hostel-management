import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { StudentModal } from '../../components/admin/StudentModal';
import { StudentDetailModal } from '../../components/admin/StudentDetailModal';
import { AllocationModal } from '../../components/admin/AllocationModal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import type { Student } from '../../types';
import {
  Users,
  Plus,
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  KeyRound,
  Mail,
  Phone,
  BookOpen,
  UserCheck
} from 'lucide-react';

export const StudentManagement: React.FC = () => {
  const { students, addStudent, updateStudent, deleteStudent } = useData();
  const { success, error: toastError } = useToast();

  // Search and Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [allocationFilter, setAllocationFilter] = useState('All');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null);
  const [allocatingStudent, setAllocatingStudent] = useState<Student | null>(null);
  const [deletingStudent, setDeletingStudent] = useState<Student | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Filtered Students
  const filteredStudents = useMemo(() => {
    return students.filter(student => {
      const matchesSearch =
        student.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (student.roomNumber && student.roomNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        student.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.email.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === 'All' || student.status === statusFilter;

      const matchesAllocation =
        allocationFilter === 'All' ||
        (allocationFilter === 'Allocated' && Boolean(student.roomNumber)) ||
        (allocationFilter === 'Unallocated' && !student.roomNumber);

      return matchesSearch && matchesStatus && matchesAllocation;
    });
  }, [students, searchTerm, statusFilter, allocationFilter]);

  const handleDeleteConfirm = async () => {
    if (!deletingStudent) return;
    setIsDeleting(true);
    try {
      await deleteStudent(deletingStudent.id);
      success(`Student ${deletingStudent.fullName} removed successfully`);
      setDeletingStudent(null);
    } catch (err: any) {
      toastError(err.message || 'Failed to delete student');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Add Student Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Student Management
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Manage student registrations, academic information, contact records, and room allocations.
          </p>
        </div>

        <button
          id="btn-add-new-student"
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all active:scale-98"
        >
          <Plus className="w-4 h-4" />
          Enroll New Student
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        {/* Search input */}
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            id="student-search-input"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by name, student ID, room, email, or course..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span>Status:</span>
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Statuses</option>
            <option value="Active">Active Resident</option>
            <option value="Inactive">Inactive</option>
            <option value="Vacated">Vacated</option>
          </select>

          <select
            value={allocationFilter}
            onChange={(e) => setAllocationFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Allocations</option>
            <option value="Allocated">Room Allocated</option>
            <option value="Unallocated">Pending Allocation</option>
          </select>

          <div className="text-xs text-slate-400 font-semibold ml-auto md:ml-2">
            Showing {filteredStudents.length} of {students.length}
          </div>
        </div>
      </div>

      {/* Students Data Table */}
      {filteredStudents.length > 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Student</th>
                  <th className="p-4">ID & Contact</th>
                  <th className="p-4">Academic Course</th>
                  <th className="p-4">Room & Bed</th>
                  <th className="p-4">Guardian Emergency</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudents.map((student) => (
                  <tr key={student.id} className="hover:bg-slate-50/60 transition-colors">
                    {/* Student Name and Avatar */}
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-900 flex items-center justify-center font-bold text-xs shrink-0">
                          {student.fullName.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900 text-xs sm:text-sm">
                            {student.fullName}
                          </p>
                          <span className="text-[11px] text-slate-400">
                            Admitted: {student.admissionDate || '2024'}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* ID & Contact */}
                    <td className="p-4 space-y-0.5">
                      <p className="font-semibold text-slate-900 font-mono text-[11px]">
                        {student.studentId}
                      </p>
                      <p className="text-slate-500 flex items-center gap-1 text-[11px]">
                        <Mail className="w-3 h-3 text-slate-400" />
                        {student.email}
                      </p>
                      <p className="text-slate-500 flex items-center gap-1 text-[11px]">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {student.phone}
                      </p>
                    </td>

                    {/* Academic Course */}
                    <td className="p-4">
                      <p className="font-semibold text-slate-900">{student.course}</p>
                      <p className="text-slate-500 text-[11px]">{student.branch}</p>
                      <span className="inline-block mt-0.5 px-1.5 py-0.2 rounded text-[10px] bg-slate-100 text-slate-600 font-medium">
                        {student.year}
                      </span>
                    </td>

                    {/* Room & Bed */}
                    <td className="p-4">
                      {student.roomNumber ? (
                        <div>
                          <span className="inline-flex items-center gap-1 font-bold text-slate-900 bg-blue-50 px-2 py-1 rounded-lg text-xs border border-blue-100">
                            Room {student.roomNumber}
                          </span>
                          <p className="text-[11px] text-slate-500 mt-1 font-medium">
                            {student.bedNumber || 'Bed 1'}
                          </p>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setAllocatingStudent(student)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 text-[11px] font-bold border border-amber-200 hover:bg-amber-100 transition-colors"
                        >
                          <KeyRound className="w-3 h-3" />
                          Assign Room
                        </button>
                      )}
                    </td>

                    {/* Guardian Emergency */}
                    <td className="p-4">
                      <p className="font-medium text-slate-900">{student.guardianName}</p>
                      <p className="text-slate-500 text-[11px] flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {student.guardianPhone}
                      </p>
                    </td>

                    {/* Status */}
                    <td className="p-4">
                      <Badge
                        variant={student.status === 'Active' ? 'success' : student.status === 'Inactive' ? 'danger' : 'neutral'}
                        size="sm"
                      >
                        {student.status}
                      </Badge>
                    </td>

                    {/* Actions */}
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          id={`view-student-${student.studentId}`}
                          type="button"
                          onClick={() => setViewingStudent(student)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-blue-900 hover:bg-slate-100 transition-colors"
                          title="View Student Dossier"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          id={`edit-student-${student.studentId}`}
                          type="button"
                          onClick={() => setEditingStudent(student)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                          title="Edit Student Details"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          id={`delete-student-${student.studentId}`}
                          type="button"
                          onClick={() => setDeletingStudent(student)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Delete Student"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <EmptyState
          icon={Users}
          title="No Students Found"
          description={
            searchTerm
              ? `No students matching "${searchTerm}". Try resetting search or filters.`
              : 'Start by enrolling your first resident student to begin room allocations.'
          }
          actionLabel="Enroll Student"
          onAction={() => setShowAddModal(true)}
        />
      )}

      {/* Modals */}
      <StudentModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={async (data) => {
          await addStudent(data);
          success(`Student ${data.fullName} enrolled successfully!`);
        }}
      />

      <StudentModal
        isOpen={Boolean(editingStudent)}
        onClose={() => setEditingStudent(null)}
        initialData={editingStudent}
        onSubmit={async (data) => {
          if (editingStudent) {
            await updateStudent(editingStudent.id, data);
            success(`Student ${data.fullName} profile updated!`);
            setEditingStudent(null);
          }
        }}
      />

      <StudentDetailModal
        isOpen={Boolean(viewingStudent)}
        onClose={() => setViewingStudent(null)}
        student={viewingStudent}
        onAllocate={() => {
          setAllocatingStudent(viewingStudent);
        }}
      />

      <AllocationModal
        isOpen={Boolean(allocatingStudent)}
        onClose={() => setAllocatingStudent(null)}
        preSelectedStudent={allocatingStudent}
      />

      <ConfirmDialog
        isOpen={Boolean(deletingStudent)}
        onClose={() => setDeletingStudent(null)}
        onConfirm={handleDeleteConfirm}
        title="Remove Student Record"
        message={`Are you sure you want to remove ${deletingStudent?.fullName} (${deletingStudent?.studentId})? This will automatically vacate their allocated room bed.`}
        confirmLabel="Remove Student"
        isLoading={isDeleting}
      />
    </div>
  );
};
