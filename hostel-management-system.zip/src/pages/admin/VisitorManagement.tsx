import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { VisitorModal } from '../../components/admin/VisitorModal';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import {
  UserCheck,
  Plus,
  Search,
  Filter,
  Clock,
  LogOut,
  Phone,
  User,
  ShieldCheck
} from 'lucide-react';

export const VisitorManagement: React.FC = () => {
  const { visitors, addVisitor, checkOutVisitor } = useData();
  const { success, error: toastError } = useToast();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredVisitors = useMemo(() => {
    return visitors.filter(v => {
      const matchesSearch =
        v.visitorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.roomNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.relationship.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === 'All' || v.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [visitors, searchTerm, statusFilter]);

  const currentlyOnCampus = visitors.filter(v => v.status === 'In Campus').length;

  const handleCheckout = async (visitorId: string, visitorName: string) => {
    try {
      await checkOutVisitor(visitorId);
      success(`${visitorName} checkout logged successfully`);
    } catch (err: any) {
      toastError(err.message || 'Checkout failed');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Security Gate & Visitor Logs
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Enforce hostel campus safety, monitor visitor check-ins, and record gate departure timestamps.
          </p>
        </div>

        <button
          id="btn-log-visitor"
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all active:scale-98"
        >
          <Plus className="w-4 h-4" />
          Log Gate Visitor
        </button>
      </div>

      {/* Campus Security Metric Banner */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Active Visitors on Premises
            </span>
            <div className="text-xl font-extrabold text-slate-900">
              {currentlyOnCampus} Guest{currentlyOnCampus === 1 ? '' : 's'} Currently in Hostel
            </div>
          </div>
        </div>

        <span className="text-xs font-medium text-slate-400 hidden sm:inline">
          Hostel visiting hours: 09:00 AM – 07:30 PM
        </span>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search visitor, resident visited, room number..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <span className="text-xs text-slate-500 font-medium">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Visitors</option>
            <option value="In Campus">In Campus (Active)</option>
            <option value="Checked Out">Checked Out</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {filteredVisitors.length > 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Visitor Name</th>
                  <th className="p-4">Visiting Resident</th>
                  <th className="p-4">Relationship</th>
                  <th className="p-4">Date & Check-in</th>
                  <th className="p-4">Check-out Time</th>
                  <th className="p-4">Purpose</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Gate Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredVisitors.map((visitor) => (
                  <tr key={visitor.id} className="hover:bg-slate-50/60">
                    <td className="p-4">
                      <p className="font-bold text-slate-900">{visitor.visitorName}</p>
                      <p className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {visitor.contactNumber}
                      </p>
                    </td>

                    <td className="p-4">
                      <p className="font-semibold text-slate-800">{visitor.studentName}</p>
                      <span className="inline-block text-[10px] text-blue-900 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">
                        Room {visitor.roomNumber}
                      </span>
                    </td>

                    <td className="p-4">
                      <span className="font-medium text-slate-700">{visitor.relationship}</span>
                    </td>

                    <td className="p-4">
                      <p className="font-medium text-slate-800">{visitor.visitDate}</p>
                      <p className="text-[11px] text-emerald-700 font-bold">In: {visitor.entryTime}</p>
                    </td>

                    <td className="p-4">
                      {visitor.exitTime ? (
                        <span className="font-medium text-slate-600">Out: {visitor.exitTime}</span>
                      ) : (
                        <span className="text-amber-600 font-bold text-[11px]">Still on campus</span>
                      )}
                    </td>

                    <td className="p-4 text-slate-600 max-w-xs truncate">
                      {visitor.purpose || 'General meeting'}
                    </td>

                    <td className="p-4">
                      <Badge
                        variant={visitor.status === 'In Campus' ? 'warning' : 'neutral'}
                        size="sm"
                      >
                        {visitor.status}
                      </Badge>
                    </td>

                    <td className="p-4 text-right">
                      {visitor.status === 'In Campus' ? (
                        <button
                          type="button"
                          onClick={() => handleCheckout(visitor.id, visitor.visitorName)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] shadow-xs"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          Log Departure
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">Logged</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <EmptyState
          icon={UserCheck}
          title="No Visitor Records"
          description="No guest visits recorded for this criteria."
          actionLabel="Log New Visitor"
          onAction={() => setShowAddModal(true)}
        />
      )}

      {/* Visitor Modal */}
      <VisitorModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={async (data) => {
          const id = await addVisitor(data);
          success(`Visitor ${data.visitorName} checked in successfully!`);
          return id;
        }}
      />
    </div>
  );
};
