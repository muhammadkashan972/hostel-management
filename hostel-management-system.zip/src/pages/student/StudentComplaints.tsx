import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { ComplaintSubmitModal } from '../../components/student/ComplaintSubmitModal';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import {
  MessageSquareWarning,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  Wrench
} from 'lucide-react';

export const StudentComplaints: React.FC = () => {
  const { currentUser } = useAuth();
  const { complaints, students, addComplaint } = useData();
  const { success } = useToast();

  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const currentStudent = students.find(
    s => s.studentId === currentUser?.studentId || s.email === currentUser?.email
  ) || {
    id: 'temp',
    studentId: currentUser?.studentId || 'STU-2025-101',
    fullName: currentUser?.displayName || 'Resident Student',
    roomNumber: 'A-101',
  };

  const studentComplaints = useMemo(() => {
    return complaints.filter(c => c.studentId === currentStudent.studentId);
  }, [complaints, currentStudent.studentId]);

  const filteredComplaints = studentComplaints.filter(c => {
    const matchesSearch =
      c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.category.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || c.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Maintenance Requests & Complaints Desk
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Submit room repairs, report electrical/plumbing issues, and track warden resolution progress.
          </p>
        </div>

        <button
          id="btn-lodge-complaint"
          type="button"
          onClick={() => setShowSubmitModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-sm transition-all active:scale-98"
        >
          <Plus className="w-4 h-4" />
          Lodge New Request
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search my tickets by subject or description..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <span className="text-xs text-slate-500 font-medium">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Statuses</option>
            <option value="Pending">Pending Triage</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
      </div>

      {/* Tickets List */}
      {filteredComplaints.length > 0 ? (
        <div className="space-y-3">
          {filteredComplaints.map((c) => (
            <div
              key={c.id}
              className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm sm:text-base font-bold text-slate-900">{c.title}</h3>
                    <Badge
                      variant={
                        c.priority === 'Urgent'
                          ? 'danger'
                          : c.priority === 'High'
                          ? 'warning'
                          : 'neutral'
                      }
                      size="sm"
                    >
                      {c.priority}
                    </Badge>
                  </div>

                  <Badge
                    variant={
                      c.status === 'Resolved'
                        ? 'success'
                        : c.status === 'In Progress'
                        ? 'warning'
                        : 'neutral'
                    }
                    size="sm"
                  >
                    {c.status}
                  </Badge>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  {c.description}
                </p>

                {c.adminRemarks && (
                  <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl text-xs text-blue-900 mb-3">
                    <strong className="block text-[11px] uppercase tracking-wider text-blue-800 mb-0.5">
                      Warden & Maintenance Resolution Note:
                    </strong>
                    {c.adminRemarks}
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-500 gap-2">
                <div className="flex items-center gap-3">
                  <span><strong>Category:</strong> {c.category}</span>
                  <span><strong>Room:</strong> {c.roomNumber}</span>
                </div>
                <span>Filed: {new Date(c.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={MessageSquareWarning}
          title="No Complaints Logged"
          description="You currently have no active or historical maintenance complaints."
          actionLabel="Submit Request"
          onAction={() => setShowSubmitModal(true)}
        />
      )}

      {/* Submit Modal */}
      <ComplaintSubmitModal
        isOpen={showSubmitModal}
        onClose={() => setShowSubmitModal(false)}
        onSubmit={async (data) => {
          await addComplaint({
            studentId: currentStudent.studentId,
            studentName: currentStudent.fullName,
            roomNumber: currentStudent.roomNumber || 'None',
            ...data,
          });
          success('Maintenance complaint submitted to the hostel warden desk!');
        }}
      />
    </div>
  );
};
