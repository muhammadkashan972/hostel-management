import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { StatCard } from '../../components/common/StatCard';
import { Badge } from '../../components/common/Badge';
import { ComplaintSubmitModal } from '../../components/student/ComplaintSubmitModal';
import { useToast } from '../../components/common/Toast';
import {
  Bed,
  CreditCard,
  MessageSquareWarning,
  Megaphone,
  Plus,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Users
} from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const { students, rooms, fees, complaints, notices, addComplaint } = useData();
  const { success } = useToast();

  const [showComplaintModal, setShowComplaintModal] = useState(false);

  // Match student object
  const currentStudent = students.find(
    s => s.studentId === currentUser?.studentId || s.email === currentUser?.email
  ) || {
    id: 'temp-student',
    studentId: currentUser?.studentId || 'STU-2025-101',
    fullName: currentUser?.displayName || 'Resident Student',
    email: currentUser?.email || 'student@university.edu',
    phone: '+1 (555) 123-4567',
    course: 'B.Tech',
    branch: 'Computer Science',
    year: '2nd Year',
    roomNumber: 'A-101',
    bedNumber: 'Bed 1',
    status: 'Active' as const,
    guardianName: 'Guardian Contact',
    guardianPhone: '+1 (555) 999-8888',
    admissionDate: '2024-08-15',
  };

  const studentRoom = rooms.find(r => r.roomNumber === currentStudent.roomNumber);

  // Student specific data
  const studentFees = fees.filter(f => f.studentId === currentStudent.studentId);
  const pendingFees = studentFees.filter(f => f.status === 'Pending' || f.status === 'Overdue');
  const totalPendingAmount = pendingFees.reduce((acc, curr) => acc + curr.amount, 0);

  const studentComplaints = complaints.filter(c => c.studentId === currentStudent.studentId);
  const activeComplaints = studentComplaints.filter(c => c.status === 'Pending' || c.status === 'In Progress');

  const recentNotices = notices.slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="p-6 bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 rounded-3xl text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-blue-500/20 text-blue-300 border border-blue-400/20">
            Resident Student Portal
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold mt-1 tracking-tight">
            Welcome back, {currentStudent.fullName}!
          </h2>
          <p className="text-xs sm:text-sm text-blue-200 mt-1">
            Student ID: <strong className="text-white">{currentStudent.studentId}</strong> • {currentStudent.course} ({currentStudent.branch})
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            id="btn-student-quick-complaint"
            type="button"
            onClick={() => setShowComplaintModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-all active:scale-98"
          >
            <Plus className="w-4 h-4" />
            Lodge Complaint
          </button>
          <button
            type="button"
            onClick={() => navigate('/student/room')}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20 transition-all active:scale-98"
          >
            <Bed className="w-4 h-4" />
            My Room Details
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
        <StatCard
          title="My Room"
          value={currentStudent.roomNumber ? `Room ${currentStudent.roomNumber}` : 'Unallocated'}
          subtitle={currentStudent.bedNumber || 'Bed Assigned'}
          icon={Bed}
          color="blue"
          onClick={() => navigate('/student/room')}
        />
        <StatCard
          title="Outstanding Fees"
          value={`Rs. ${totalPendingAmount.toLocaleString()}`}
          subtitle={pendingFees.length > 0 ? `${pendingFees.length} invoice pending` : 'All dues clear'}
          icon={CreditCard}
          color={totalPendingAmount > 0 ? 'rose' : 'slate'}
          onClick={() => navigate('/student/fees')}
        />
        <StatCard
          title="My Complaints"
          value={studentComplaints.length}
          subtitle={`${activeComplaints.length} in progress`}
          icon={MessageSquareWarning}
          color="amber"
          onClick={() => navigate('/student/complaints')}
        />
      </div>

      {/* Two Column Layout: Room & Roommates + Notice Board */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Room & Roommates Snapshot */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Residential Room Overview</h3>
                <p className="text-xs text-slate-500">
                  {studentRoom ? `${studentRoom.type} Room • ${studentRoom.block}` : 'Allocation details'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => navigate('/student/room')}
                className="text-xs font-bold text-blue-900 hover:text-blue-800 flex items-center gap-1"
              >
                Roommates <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {currentStudent.roomNumber ? (
              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-100 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-blue-800 font-semibold block">Designated Bed</span>
                    <strong className="text-base text-blue-950 font-black">{currentStudent.bedNumber || 'Bed 1'}</strong>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-blue-800 font-semibold block">Room Status</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800">
                      Active Occupancy
                    </span>
                  </div>
                </div>

                <div className="text-xs space-y-1 text-slate-600">
                  <p><strong>Wing:</strong> {studentRoom?.block || 'Block A'}</p>
                  <p><strong>Floor:</strong> {studentRoom?.floor || '1st Floor'}</p>
                  <p><strong>Semester Fee:</strong> Rs. {(studentRoom?.feePerSemester || 1200).toLocaleString()} / term</p>
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-slate-400">
                <AlertTriangle className="w-8 h-8 mx-auto text-amber-500 mb-1" />
                <p className="text-xs font-semibold text-slate-700">No Room Allocated</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Please contact the Chief Warden office for bed assignment.</p>
              </div>
            )}
          </div>

          <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Need repair or fixture fixed?</span>
            <button
              type="button"
              onClick={() => setShowComplaintModal(true)}
              className="text-blue-900 font-bold hover:underline"
            >
              + Submit Maintenance Request
            </button>
          </div>
        </div>

        {/* Notices Snapshot */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Latest Hostel Notices</h3>
                <p className="text-xs text-slate-500">Campus circulars & important advisories</p>
              </div>
              <button
                type="button"
                onClick={() => navigate('/student/notices')}
                className="text-xs font-bold text-blue-900 hover:text-blue-800 flex items-center gap-1"
              >
                All Notices <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {recentNotices.map((notice) => (
                <div key={notice.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900 truncate">{notice.title}</span>
                    <Badge
                      variant={notice.priority === 'Urgent' ? 'danger' : notice.priority === 'Important' ? 'warning' : 'primary'}
                      size="sm"
                    >
                      {notice.priority}
                    </Badge>
                  </div>
                  <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                    {notice.content}
                  </p>
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Issued by: {notice.publishedBy} • {new Date(notice.createdAt).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-100 text-[11px] text-slate-400 text-right">
            Verified official hostel communications
          </div>
        </div>
      </div>

      {/* Active Maintenance Requests Progress Tracker */}
      {studentComplaints.length > 0 && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900">My Maintenance Tickets</h3>
            <button
              type="button"
              onClick={() => navigate('/student/complaints')}
              className="text-xs font-bold text-blue-900 hover:underline"
            >
              View Full History
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {studentComplaints.slice(0, 3).map((comp) => (
              <div key={comp.id} className="py-3 flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{comp.title}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                      {comp.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">{comp.description}</p>
                  {comp.adminRemarks && (
                    <p className="text-[10px] text-blue-900 font-semibold mt-1">
                      Warden Update: {comp.adminRemarks}
                    </p>
                  )}
                </div>

                <Badge
                  variant={comp.status === 'Resolved' ? 'success' : comp.status === 'In Progress' ? 'warning' : 'neutral'}
                  size="sm"
                >
                  {comp.status}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Complaint Submit Modal */}
      <ComplaintSubmitModal
        isOpen={showComplaintModal}
        onClose={() => setShowComplaintModal(false)}
        onSubmit={async (data) => {
          await addComplaint({
            studentId: currentStudent.studentId,
            studentName: currentStudent.fullName,
            roomNumber: currentStudent.roomNumber || 'None',
            ...data,
          });
          success('Maintenance request submitted to warden desk!');
        }}
      />
    </div>
  );
};
