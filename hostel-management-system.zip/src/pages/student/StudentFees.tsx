import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Modal } from '../../components/common/Modal';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { useToast } from '../../components/common/Toast';
import type { Fee } from '../../types';
import {
  CreditCard,
  CheckCircle2,
  AlertCircle,
  FileText,
  Printer,
  DollarSign,
  ShieldCheck,
  Building,
  ArrowRight
} from 'lucide-react';

export const StudentFees: React.FC = () => {
  const { currentUser } = useAuth();
  const { fees, students, recordPayment } = useData();
  const { success, error: toastError } = useToast();

  const currentStudent = students.find(
    s => s.studentId === currentUser?.studentId || s.email === currentUser?.email
  ) || {
    id: 'temp',
    studentId: currentUser?.studentId || 'STU-2025-101',
    fullName: currentUser?.displayName || 'Resident Student',
    roomNumber: 'A-101',
  };

  const studentFees = fees.filter(f => f.studentId === currentStudent.studentId);

  const [payingFee, setPayingFee] = useState<Fee | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<Fee | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('Online Card Payment');
  const [processing, setProcessing] = useState(false);

  const handlePay = async () => {
    if (!payingFee) return;
    setProcessing(true);
    try {
      const txnId = `TXN-STU-${Math.floor(100000 + Math.random() * 900000)}`;
      await recordPayment(payingFee.id, paymentMethod, txnId);
      success(`Payment for ${payingFee.semester} fee processed successfully!`);
      setPayingFee(null);
    } catch (err: any) {
      toastError(err.message || 'Payment simulation failed');
    } finally {
      setProcessing(false);
    }
  };

  const totalPaid = studentFees
    .filter(f => f.status === 'Paid')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalOutstanding = studentFees
    .filter(f => f.status === 'Pending' || f.status === 'Overdue')
    .reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Hostel Fee Payments & Invoices
        </h2>
        <p className="text-xs sm:text-sm text-slate-500">
          Review semester room rent invoices, execute instant fee clearances, and download receipts.
        </p>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Outstanding Dues
            </span>
            <div className="text-2xl font-black text-rose-600 mt-1">
              Rs. {totalOutstanding.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {totalOutstanding > 0 ? 'Action required prior to deadline' : 'No overdue accounts'}
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100">
            <AlertCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              Total Paid to Date
            </span>
            <div className="text-2xl font-black text-emerald-700 mt-1">
              Rs. {totalPaid.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">Cleared with authorized receipts</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Fee Table */}
      {studentFees.length > 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Hostel Accommodation Invoices
            </h3>
            <span className="text-xs text-slate-400">{studentFees.length} Records</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Invoice #</th>
                  <th className="p-4">Term Description</th>
                  <th className="p-4">Billed Amount</th>
                  <th className="p-4">Payment Due Date</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {studentFees.map((fee) => (
                  <tr key={fee.id} className="hover:bg-slate-50/60">
                    <td className="p-4 font-mono font-bold text-slate-900 text-xs">
                      {fee.invoiceNumber}
                    </td>

                    <td className="p-4">
                      <p className="font-bold text-slate-900">{fee.semester}</p>
                      <p className="text-[11px] text-slate-400">Room {fee.roomNumber}</p>
                    </td>

                    <td className="p-4 font-extrabold text-sm text-slate-900">
                      Rs. {fee.amount.toLocaleString()}
                    </td>

                    <td className="p-4 text-slate-600">
                      {fee.dueDate}
                    </td>

                    <td className="p-4">
                      <Badge
                        variant={fee.status === 'Paid' ? 'success' : fee.status === 'Pending' ? 'warning' : 'danger'}
                        size="sm"
                      >
                        {fee.status}
                      </Badge>
                      {fee.paymentDate && (
                        <span className="block text-[10px] text-emerald-700 mt-0.5">
                          Paid: {fee.paymentDate}
                        </span>
                      )}
                    </td>

                    <td className="p-4 text-right">
                      {fee.status !== 'Paid' ? (
                        <button
                          type="button"
                          onClick={() => setPayingFee(fee)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-xs"
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                          Pay Online Now
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setSelectedReceipt(fee)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px]"
                        >
                          <FileText className="w-3.5 h-3.5 text-blue-900" />
                          Receipt
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <EmptyState
          icon={CreditCard}
          title="No Invoices Issued"
          description="You currently have no hostel fee invoices logged."
        />
      )}

      {/* Pay Modal */}
      {payingFee && (
        <Modal
          isOpen={Boolean(payingFee)}
          onClose={() => setPayingFee(null)}
          title={`Clear Fee: ${payingFee.semester}`}
          subtitle={`Invoice Reference: ${payingFee.invoiceNumber}`}
          maxWidth="sm"
        >
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-100 flex items-center justify-between">
              <div>
                <span className="text-slate-500 block text-[11px]">Total Amount Payable</span>
                <strong className="text-xl font-black text-blue-900">Rs. {payingFee.amount.toLocaleString()}</strong>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-100 text-amber-800">
                Pending
              </span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Choose Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
              >
                <option value="Online Card Payment">Debit / Credit Card (Visa, Mastercard)</option>
                <option value="UPI / Instant Mobile Banking">UPI / Instant QR Payment</option>
                <option value="Campus Student Wallet">Campus Student Account Wallet</option>
              </select>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-500 text-[11px] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>256-bit SSL secured campus payment gateway. Instant receipt issued upon confirmation.</span>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPayingFee(null)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-medium"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handlePay}
                disabled={processing}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-sm"
              >
                {processing ? 'Processing Payment...' : `Authorize Rs. ${payingFee.amount.toLocaleString()}`}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Official Receipt Modal */}
      {selectedReceipt && (
        <Modal
          isOpen={Boolean(selectedReceipt)}
          onClose={() => setSelectedReceipt(null)}
          title="Official Hostel Fee Receipt"
          subtitle={`Receipt: ${selectedReceipt.invoiceNumber}`}
          maxWidth="md"
        >
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl space-y-4 text-xs">
            <div className="flex justify-between border-b pb-3">
              <div>
                <h4 className="font-black text-slate-900 text-sm">Hostel Management System</h4>
                <p className="text-slate-500">Official Student Residence Account</p>
              </div>
              <div className="text-right">
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold uppercase text-[10px]">
                  PAID IN FULL
                </span>
                <p className="text-[10px] text-slate-400 mt-1">{selectedReceipt.paymentDate}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-slate-700">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Resident Info</span>
                <strong className="text-slate-900">{selectedReceipt.studentName}</strong>
                <p className="text-[11px] text-slate-500">ID: {selectedReceipt.studentId}</p>
                <p className="text-[11px] text-slate-500">Room: {selectedReceipt.roomNumber}</p>
              </div>
              <div className="text-right">
                <span className="text-slate-400 block text-[10px] uppercase">Receipt Reference</span>
                <p className="font-mono text-[11px] text-slate-800">{selectedReceipt.transactionId || 'TXN-ONLINE-9281'}</p>
                <p className="text-[11px] text-slate-500">{selectedReceipt.paymentMethod || 'Online Gateway'}</p>
              </div>
            </div>

            <div className="border-t border-b py-2.5 flex justify-between font-bold text-slate-900 text-sm">
              <span>{selectedReceipt.semester} Room Fee</span>
              <span>Rs. {selectedReceipt.amount.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center text-slate-500 text-[11px] pt-1">
              <span>Status: Electronically Confirmed</span>
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1 text-blue-900 hover:underline font-bold"
              >
                <Printer className="w-3.5 h-3.5" />
                Print / Download Receipt
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
