import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import {
  Megaphone,
  Search,
  Filter,
  Calendar,
  Building,
  Pin
} from 'lucide-react';

export const StudentNotices: React.FC = () => {
  const { notices } = useData();

  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');

  const filteredNotices = useMemo(() => {
    return notices.filter(n => {
      const matchesSearch =
        n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        n.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        n.publishedBy.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCategory = categoryFilter === 'All' || n.category === categoryFilter;
      const matchesPriority = priorityFilter === 'All' || n.priority === priorityFilter;

      return matchesSearch && matchesCategory && matchesPriority;
    });
  }, [notices, searchTerm, categoryFilter, priorityFilter]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Hostel Notice Board & Official Broadcasts
        </h2>
        <p className="text-xs sm:text-sm text-slate-500">
          Official hostel circulars, mess schedules, maintenance downtimes, and administrative advisories.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search circulars by subject, keyword, authority..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Priorities</option>
            <option value="Urgent">Urgent Notices</option>
            <option value="Important">Important</option>
            <option value="Normal">Normal</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="All">All Categories</option>
            <option value="General">General</option>
            <option value="Maintenance">Maintenance</option>
            <option value="Mess & Dining">Mess & Dining</option>
            <option value="Rules & Discipline">Rules & Discipline</option>
            <option value="Holiday / Leave">Holiday / Leave</option>
          </select>
        </div>
      </div>

      {/* Notices Grid */}
      {filteredNotices.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredNotices.map((notice) => (
            <div
              key={notice.id}
              className={`bg-white rounded-2xl p-6 border shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between ${
                notice.priority === 'Urgent' ? 'border-rose-200 ring-1 ring-rose-100' : 'border-slate-200/80'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <Badge
                    variant={
                      notice.priority === 'Urgent'
                        ? 'danger'
                        : notice.priority === 'Important'
                        ? 'warning'
                        : 'primary'
                    }
                    size="sm"
                  >
                    {notice.priority} Alert
                  </Badge>

                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {new Date(notice.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 mb-2 leading-snug">
                  {notice.title}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line mb-4">
                  {notice.content}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <div>
                  <span className="text-slate-400 text-[10px] block">ISSUED BY</span>
                  <span className="font-semibold text-slate-800 text-[11px]">{notice.publishedBy}</span>
                </div>
                <span className="text-[10px] text-blue-900 bg-blue-50 px-2 py-0.5 rounded font-medium">
                  {notice.category}
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Megaphone}
          title="No Notices Match"
          description="There are currently no circulars matching your search query or filters."
        />
      )}
    </div>
  );
};
