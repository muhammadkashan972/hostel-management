import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { useToast } from '../../components/common/Toast';
import {
  User,
  Mail,
  Phone,
  BookOpen,
  Building,
  KeyRound,
  Save,
  Shield,
  Home,
  CheckCircle2,
  Calendar
} from 'lucide-react';

export const StudentProfile: React.FC = () => {
  const { currentUser, updateUserProfile } = useAuth();
  const { students, updateStudent } = useData();
  const { success, error: toastError } = useToast();

  const studentData = students.find(
    s => s.studentId === currentUser?.studentId || s.email === currentUser?.email
  ) || {
    id: 'temp',
    studentId: currentUser?.studentId || 'STU-2025-101',
    fullName: currentUser?.displayName || 'Resident Student',
    email: currentUser?.email || 'student@university.edu',
    phone: '+1 (555) 123-4567',
    course: 'B.Tech',
    branch: 'Computer Science',
    year: '2nd Year',
    roomNumber: 'A-101',
    bedNumber: 'Bed 1',
    guardianName: 'Robert Vance',
    guardianPhone: '+1 (555) 999-8888',
    address: '142 University Way, Metro District',
    bloodGroup: 'O+',
    admissionDate: '2024-08-15',
    status: 'Active' as const,
  };

  const [phone, setPhone] = useState(studentData.phone || '');
  const [guardianName, setGuardianName] = useState(studentData.guardianName || '');
  const [guardianPhone, setGuardianPhone] = useState(studentData.guardianPhone || '');
  const [address, setAddress] = useState(studentData.address || '');
  const [bloodGroup, setBloodGroup] = useState(studentData.bloodGroup || 'O+');

  const [saving, setSaving] = useState(false);

  // Password change
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passMsg, setPassMsg] = useState('');

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (studentData.id !== 'temp') {
        await updateStudent(studentData.id, {
          phone,
          guardianName,
          guardianPhone,
          address,
          bloodGroup,
        });
      }
      success('Profile contact details updated successfully!');
    } catch (err: any) {
      toastError(err.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      toastError('New password must be at least 6 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      toastError('New passwords do not match');
      return;
    }
    setPassMsg('Password successfully changed for student portal.');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    success('Student portal password updated successfully!');
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Resident Student Profile
        </h2>
        <p className="text-xs sm:text-sm text-slate-500">
          Official enrollment records, emergency guardian reachability, and residence security credentials.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Card */}
        <div className="p-6 bg-white rounded-3xl border border-slate-200/80 shadow-xs flex flex-col items-center text-center">
          <div className="w-20 h-20 rounded-2xl bg-blue-900 text-white flex items-center justify-center text-2xl font-black shadow-md mb-3">
            {studentData.fullName.charAt(0).toUpperCase()}
          </div>
          <h3 className="font-bold text-slate-900 text-base">{studentData.fullName}</h3>
          <p className="text-xs font-mono text-blue-900 font-bold mt-0.5">{studentData.studentId}</p>
          <span className="mt-2 px-2.5 py-0.5 rounded-full text-xs font-bold uppercase bg-emerald-50 text-emerald-800 border border-emerald-200">
            Resident Status: Active
          </span>

          <div className="w-full mt-6 pt-4 border-t border-slate-100 text-xs text-left space-y-2 text-slate-600">
            <p className="flex items-center justify-between">
              <span className="text-slate-400">Assigned Room:</span>
              <strong className="text-slate-900">Room {studentData.roomNumber || 'None'} ({studentData.bedNumber})</strong>
            </p>
            <p className="flex items-center justify-between">
              <span className="text-slate-400">Course & Year:</span>
              <strong className="text-slate-900">{studentData.course} ({studentData.year})</strong>
            </p>
            <p className="flex items-center justify-between">
              <span className="text-slate-400">Branch:</span>
              <strong className="text-slate-900">{studentData.branch}</strong>
            </p>
            <p className="flex items-center justify-between">
              <span className="text-slate-400">Admission Date:</span>
              <span className="text-slate-700">{studentData.admissionDate}</span>
            </p>
          </div>
        </div>

        {/* Forms */}
        <div className="md:col-span-2 space-y-6">
          {/* Contact Details */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200/80 shadow-xs">
            <h4 className="text-sm font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
              <User className="w-4 h-4 text-blue-900" />
              Contact & Emergency Information
            </h4>

            <form onSubmit={handleProfileSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Student Phone</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Blood Group</label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Parent / Guardian Name</label>
                  <input
                    type="text"
                    value={guardianName}
                    onChange={(e) => setGuardianName(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Parent Emergency Phone</label>
                  <input
                    type="text"
                    value={guardianPhone}
                    onChange={(e) => setGuardianPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Permanent Residence Address</label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold shadow-sm transition-all disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  {saving ? 'Saving...' : 'Update Details'}
                </button>
              </div>
            </form>
          </div>

          {/* Change Password */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200/80 shadow-xs">
            <h4 className="text-sm font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-blue-900" />
              Change Student Portal Password
            </h4>

            {passMsg && (
              <div className="p-3 mb-3 text-xs bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl">
                {passMsg}
              </div>
            )}

            <form onSubmit={handlePasswordChange} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Current Password</label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">New Password</label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Confirm Password</label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-900"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-sm transition-all"
                >
                  Change Password
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
