import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import {
  Bed,
  DoorOpen,
  Users,
  CheckCircle2,
  Mail,
  Phone,
  Shield,
  Clock,
  Sparkles,
  Wifi,
  Wind,
  Home
} from 'lucide-react';

export const StudentRoom: React.FC = () => {
  const { currentUser } = useAuth();
  const { students, rooms } = useData();

  const currentStudent = students.find(
    s => s.studentId === currentUser?.studentId || s.email === currentUser?.email
  ) || {
    id: 'temp',
    studentId: currentUser?.studentId || 'STU-2025-101',
    fullName: currentUser?.displayName || 'Resident Student',
    roomNumber: 'A-101',
    bedNumber: 'Bed 1',
    course: 'B.Tech',
    branch: 'Computer Science',
    year: '2nd Year',
  };

  const room = rooms.find(r => r.roomNumber === currentStudent.roomNumber);
  const roommates = students.filter(s => s.roomNumber === currentStudent.roomNumber);

  if (!currentStudent.roomNumber) {
    return (
      <EmptyState
        icon={DoorOpen}
        title="No Room Allocated"
        description="You do not currently have an assigned hostel room. Please consult the Warden Office."
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          My Room & Resident Roommates
        </h2>
        <p className="text-xs sm:text-sm text-slate-500">
          Room specifications, included amenities, roommate profiles, and residential code of conduct.
        </p>
      </div>

      {/* Main Room Card */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-blue-900 text-white flex items-center justify-center font-black text-xl shadow-md">
              {currentStudent.roomNumber}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-bold text-slate-900">
                  Room {currentStudent.roomNumber}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase bg-blue-50 text-blue-900 border border-blue-200">
                  {room?.type || 'Double'} Room
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {room?.block || 'Block A (Sunrise)'} • {room?.floor || '1st Floor'}
              </p>
            </div>
          </div>

          <div className="text-right flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto">
            <span className="text-xs text-slate-400 font-medium">My Assigned Bed</span>
            <span className="text-base font-extrabold text-blue-900 bg-blue-50 px-3 py-1 rounded-xl border border-blue-200">
              {currentStudent.bedNumber || 'Bed 1'}
            </span>
          </div>
        </div>

        {/* Room Specs Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-b border-slate-100">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Total Bed Capacity</span>
            <p className="text-sm font-extrabold text-slate-900 mt-0.5">{room?.capacity || 2} Residents</p>
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Occupancy State</span>
            <p className="text-sm font-extrabold text-slate-900 mt-0.5">
              {room?.currentOccupants || roommates.length} of {room?.capacity || 2} Beds Occupied
            </p>
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Term Rental Fee</span>
            <p className="text-sm font-extrabold text-emerald-700 mt-0.5">Rs. {(room?.feePerSemester || 1200).toLocaleString()} / semester</p>
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Maintenance State</span>
            <p className="text-sm font-extrabold text-blue-900 mt-0.5">{room?.status || 'Active'}</p>
          </div>
        </div>

        {/* Amenities */}
        <div className="pt-5">
          <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
            Room Amenities & Inclusions
          </h4>
          <div className="flex flex-wrap gap-2">
            {(room?.amenities || [
              'Attached Washroom',
              'High-speed Wi-Fi',
              'Air Conditioning',
              'Individual Study Desks',
              'Wardrobe & Lockers'
            ]).map(amenity => (
              <span
                key={amenity}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 text-xs font-medium"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-900" />
                {amenity}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Roommates Card Section */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">Assigned Roommates</h3>
            <p className="text-xs text-slate-500">Other students sharing Room {currentStudent.roomNumber}</p>
          </div>
          <span className="text-xs font-semibold text-blue-900 bg-blue-50 px-2.5 py-1 rounded-xl">
            {roommates.length} Registered
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {roommates.map((mate) => {
            const isMe = mate.studentId === currentStudent.studentId;

            return (
              <div
                key={mate.id}
                className={`p-4 rounded-2xl border transition-all ${
                  isMe
                    ? 'bg-blue-50/50 border-blue-200 ring-1 ring-blue-200'
                    : 'bg-slate-50/70 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-blue-900 text-white flex items-center justify-center font-bold text-sm">
                      {mate.fullName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <strong className="text-xs sm:text-sm text-slate-900">{mate.fullName}</strong>
                        {isMe && (
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-blue-600 text-white">
                            You
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">{mate.course} • {mate.branch}</p>
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded-lg text-xs font-bold text-slate-700 bg-white border border-slate-200">
                    {mate.bedNumber || 'Bed 1'}
                  </span>
                </div>

                <div className="text-xs space-y-1 text-slate-600 pt-2 border-t border-slate-200/60">
                  <p className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span>{mate.email}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{mate.phone}</span>
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rules Banner */}
      <div className="p-5 rounded-2xl bg-amber-50/80 border border-amber-200/80 text-xs text-amber-900 space-y-1.5">
        <h4 className="font-bold flex items-center gap-1.5 uppercase tracking-wide text-amber-950">
          <Shield className="w-4 h-4 text-amber-700" />
          Resident Hostel Community Conduct & Quiet Hours
        </h4>
        <p className="text-amber-900/90 leading-relaxed">
          Night curfew is strictly enforced at 10:00 PM. Quiet study hours are observed from 10:30 PM to 06:00 AM. 
          Please keep shared spaces clean and respect your roommates' privacy and academic schedule.
        </p>
      </div>
    </div>
  );
};
