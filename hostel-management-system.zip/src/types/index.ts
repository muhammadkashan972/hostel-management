export type UserRole = 'admin' | 'student';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  studentId?: string;
  photoURL?: string;
  phone?: string;
  createdAt: string;
}

export type StudentStatus = 'Active' | 'Left Hostel' | 'Inactive' | 'Vacated';

export interface Student {
  id: string;
  uid?: string;
  studentId: string;
  fullName: string;
  email: string;
  phone: string;
  course: string;
  branch: string;
  year: string;
  roomNumber?: string;
  bedNumber?: string;
  guardianName: string;
  guardianPhone: string;
  address: string;
  status: StudentStatus;
  admissionDate: string;
  leavingDate?: string;
  leavingReason?: string;
  previousRoomNumber?: string;
  previousBedNumber?: string;
  bloodGroup?: string;
}

export type RoomType = 'Single' | 'Double' | 'Triple' | 'Four-Bed';
export type RoomStatus = 'Available' | 'Full' | 'Maintenance';

export interface Room {
  id: string;
  roomNumber: string;
  floor: string;
  block: string;
  type: RoomType;
  capacity: number;
  currentOccupants: number;
  availableBeds: number;
  feePerSemester: number;
  amenities: string[];
  status: RoomStatus;
}

export interface Allocation {
  id: string;
  studentId: string;
  studentName: string;
  roomId: string;
  roomNumber: string;
  bedNumber: string;
  allocatedDate: string;
  status: 'Active' | 'Relocated' | 'Cancelled';
  remarks?: string;
}

export type FeeStatus = 'Paid' | 'Pending' | 'Overdue';

export interface Fee {
  id: string;
  studentId: string;
  studentName: string;
  roomNumber: string;
  amount: number;
  semester: string;
  dueDate: string;
  paymentDate?: string;
  paymentMethod?: string;
  transactionId?: string;
  status: FeeStatus;
  invoiceNumber: string;
}

export type ComplaintCategory = 'Plumbing' | 'Electrical' | 'Carpentry' | 'Wi-Fi & Network' | 'Cleanliness' | 'Discipline' | 'Other';
export type ComplaintPriority = 'Low' | 'Medium' | 'High' | 'Urgent';
export type ComplaintStatus = 'Pending' | 'In Progress' | 'Resolved' | 'Closed';

export interface Complaint {
  id: string;
  studentId: string;
  studentName: string;
  roomNumber: string;
  category: ComplaintCategory;
  title: string;
  description: string;
  priority: ComplaintPriority;
  status: ComplaintStatus;
  adminRemarks?: string;
  createdAt: string;
  resolvedAt?: string;
}

export type NoticePriority = 'Normal' | 'Important' | 'Urgent';
export type NoticeCategory = 'Maintenance' | 'Mess & Dining' | 'Rules & Discipline' | 'Holiday / Leave' | 'General';

export interface Notice {
  id: string;
  title: string;
  content: string;
  category: NoticeCategory;
  priority: NoticePriority;
  publishedBy: string;
  createdAt: string;
  targetAudience: 'All Students' | 'Freshers' | 'Seniors' | 'Staff';
}

export interface Visitor {
  id: string;
  studentId: string;
  studentName: string;
  roomNumber: string;
  visitorName: string;
  relationship: string;
  contactNumber: string;
  visitDate: string;
  entryTime: string;
  exitTime?: string;
  status: 'In Campus' | 'Checked Out';
  purpose: string;
}

export interface DashboardStats {
  totalStudents: number;
  formerStudentsCount: number;
  totalRooms: number;
  occupiedRooms: number;
  availableRooms: number;
  totalBeds: number;
  occupiedBeds: number;
  availableBeds: number;
  occupancyRate: number;
  pendingFees: number;
  pendingFeesCount: number;
  totalPendingAmount: number;
  totalComplaints: number;
  pendingComplaints: number;
  activeVisitors: number;
}

export interface HostelSettings {
  hostelName: string;
  primaryColor: string;
  curfewTime: string;
  gateOpenTime: string;
  messBreakfast: string;
  messDinner: string;
  wifiNetwork: string;
  emergencyHotline: string;
  updatedAt?: string;
  updatedBy?: string;
}
