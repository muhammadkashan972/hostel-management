/**
 * Currency utility for formatting amounts in Pakistani Rupees (PKR)
 * Format: Rs. 5,000
 */
export const formatCurrency = (amount: number | string | undefined | null): string => {
  if (amount === undefined || amount === null || isNaN(Number(amount))) {
    return 'Rs. 0';
  }
  const num = typeof amount === 'number' ? amount : Number(amount);
  return `Rs. ${num.toLocaleString()}`;
};
